define(
    //-------------------------------------------------------------------
    // DEPENDENCIES
    //-------------------------------------------------------------------
    ['knockout', 'viewModels/paymentsViewModel', 'pubsub', 'navigation', 'notifier', 'ccConstants', 'ccRestClient', 'CCi18n', 'viewModels/delegatedAdminContacts', 'viewModels/address', 'spinner', 'js/ext/extendsaveCreditCardWidget_v1','viewModels/address','ccRestClient'],

    // Module Implementation
    function(ko, paymentsViewModel, PubSub, navigation, notifier, CCConstants, ccRestClient, CCi18n, DelegatedAdminContacts, Address, spinner, extenedPaytrace,Address,CCRestClient) {
        // 'use strict';
        var getWidget;
        var orgId = "orgId";
        return {
            paymentsContainer: ko.observable(paymentsViewModel.getInstance()),
            paymentViewModel: ko.observable(null),
            allCreditCards: ko.observableArray(),
            addressvalidationMessage: ko.observable(),
            validAddresses: ko.observableArray([]),
            selectedSavedCardId: ko.observable(),
            selectedBillingAddressId: ko.observable(),
            organizationAddressBook: ko.observableArray(),
            fetchSize: ko.observable(40),
            selectedBillingAddress2Type: ko.observable(),
              selectedpaymentAddress: ko.observable(),
            billingContact: ko.observable(),
            addresses : ko.observableArray([]),
            creditCardAvailable: ko.observable(true),
            shippingAddressBook: ko.observableArray().extend({
                deferred: true
            }),
            defaultBillingAddress : ko.observable(),
            defaultAddress: ko.observable(),
            expiryMMYY: ko.observable(),
            CCNumberEncrypted: ko.observable(),
            cardNumber: ko.observable(),
            CCCVVEncrypted: ko.observable(),
            cardCVV: ko.observable(),
    countriesList: ko.observableArray(),
            expiryMonth: ko.observable(),
            expiryYear: ko.observable(),
            creditCardsArray: ko.observableArray([]),
            creditCardsDetails: ko.observableArray([]),
            userIsAccountAddressManager: ko.observable(false),
            userIsProfileAddressManager: ko.observable(false),
            billingAddressSelected: ko.observable(false),
            editBillingAddress: ko.observable(true),
            editPayUBillingAddress: ko.observable(true),
            editInvoiceBillingAddress: ko.observable(true),
            deleteCreditCardTest: ko.observableArray([]),
            inheritedAddressBook: ko.observableArray(),
            selectedBillingAddressId: ko.observable(),
            defaultBillingAddressType: ko.observable(''),
            offset: ko.observable(0),
            profileOffset: ko.observable(0),
            accountOffset: ko.observable(0),
            limit: ko.observable(40),
            profileAddressBook: ko.observableArray(),
            accountAddressBook: ko.observableArray(),
            stateArray: ko.observableArray([]),
            billingCountries: ko.observableArray([]),
            defaultBillingCountry: ko.observableArray(null),
            totalAccountAddresses: ko.observable(0),
            totalProfileAddresses: ko.observable(0),
            totalInheritedAddresses: ko.observable(0),
            mandatoryFields: ko.observable(false),
            loadMoreProfileAddresses: ko.observable(false),
            billingAddressBackUp: null,
            hasDefaultBillingAddress: ko.observable(false),
            customDefaultBillingAddress: ko.observable(),
            country: ko.observable("US"),
            addressArray: ko.observableArray(['', 'Suite', 'Apartment', 'Building', 'P.O. Box']),

            loadMoreAccountAddresses: ko.observable(false),

            deleteCreditCardDetails: function(value, selfData) {
                var widget = this;
                var self = value;
                var url = 'removeCreditCard';
                var inputData = {};
                
                ccRestClient.request(url, inputData,
                    function(data) {

                        widget.allCreditCards.remove(selfData);
                        spinner.destroy();
                    },
                    function(errorData) {
                        console.log("Card delete failed")
                    },
                value);
                return true;
            },
            
            //karthick added for last 4digit cc number
            formatCardNumber : function(cardNumber) {
            if(cardNumber){
                var formatCardNumber = cardNumber.slice(cardNumber.length - 4);
                console.log(cardNumber.slice(cardNumber.length - 4));
               return formatCardNumber;
            }
          },


            getCreditCardsForProfile: function() {

                var widget = this;


                //  var creditCardsDetails = [];
                var inputData = {
                    "allCards": true,
                    "allGateways": true,
                    "allSites": true
                };
                var url = "listCreditCards";
                var maskedNumberRegex = /\d(?=\d{4})/g;
                var maskedSymbol = "*";
                ccRestClient.request(url, inputData,
                    function(data) {
                        data.creditCards = data.items;
                        for (var i = 0; i < data.creditCards.length; i++) {
                            var creditCard = widget.paymentsContainer().createPaymentGroup(
                                CCConstants.CARD_PAYMENT_TYPE);
                            creditCard.populateData(data.creditCards[i]);
                            creditCard.isSavedCard(true);
                            widget.creditCardsDetails.push(creditCard);
                        }

                        console.log("Credit Cards: : ", widget.creditCardsDetails);

                    },
                    function(data) {
                        console.log("Error while retrieving the credit cards");
                    });


                var request = {
                    "profileId": widget.user().id()
                };



                $.ajax({
                    url: '/ccstorex/custom/v1/creditCard',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(request)
                }).done(function(obj) {
                    if (obj.body.creditCards.length > 0) {
                        //  widget.mediaArray(obj);
                        widget.creditCardsArray(obj.body.creditCards);
                        console.log(widget.creditCardsArray())
                        widget.assignCreditCardDetails()
                    } else {
                        widget.creditCardAvailable(false)
                        widget.creditCardsArray([]);
                    }
                }).fail(function(error) {
                    console.log("error", error)
                });




            },


            autoSubmitForm: function() {
                var widget = this;
                console.log("inside");

                $("#cardNumber").blur(function() {
                    if (this.value) {
                        widget.mandatoryFields(false);

                        $("#cardNumber").css('border', '2px solid #d3d3d3');
                    }
                });

                $("#expiryMMYYYY").blur(function() {
                    if (this.value) {
                        widget.mandatoryFields(false);
                        $("#expiryMMYYYY").css('border', '2px solid #d3d3d3');
                    }
                });

                $("#cardCVV").blur(function() {
                    if (this.value) {
                        widget.mandatoryFields(false);
                        $("#cardCVV").css('border', '2px solid #d3d3d3');
                    }
                });


                if (getWidget.expiryMMYY()) {
                    var monthYY = getWidget.expiryMMYY().split('/');
                    widget.expiryMonth(monthYY[0]);
                    widget.expiryYear(monthYY[1]);

                }

                if (widget.paymentViewModel().cardNumber() && widget.paymentViewModel().cardCVV()) {
                    var encyptedArray = paytrace.submitEncrypted("#myform1");


                    $.each(encyptedArray, function(index, value) {
                        console.log(index + ' : ' + value.number + ': ' + value.encrypted);

                        if (value.number.length > 5) {
                            widget.CCNumberEncrypted(value.encrypted);
                            widget.cardNumber(value.number);
                        } else {
                            widget.CCCVVEncrypted(value.encrypted);
                            widget.cardCVV(value.number);

                        }
                    });


                }

                return true;
            },

            assignCreditCardDetails: function() {
                var widget = this;

                console.log(widget.creditCardsArray(), "widget.creditCardsArray");

                for (var i = 0; i < widget.creditCardsArray().length; i++) {
                    var creditCard = widget.paymentsContainer().createPaymentGroup(
                        CCConstants.CARD_PAYMENT_TYPE);
                    creditCard.populateData(widget.creditCardsArray()[i]);
                    creditCard.isSavedCard(true);

                    widget.allCreditCards.push(creditCard);
                }

                console.log("Credit Cards: : ", widget.allCreditCards());

            

                if (widget.creditCardsArray().length > 0) {
                    widget.resetSelectedSavedCardId();
                    widget.allCreditCards()[0].amount.subscribe(function(newVal) {
                        console.log(newVal);
                    });
                }
                
                 for(var i=0; i< widget.allCreditCards().length;i++){
                    for (var j=0; j< widget.creditCardsDetails().length; j++){
                    // console.log(widget.creditCardsDetails()[j].isDefault())
                    
                    if(widget.creditCardsDetails()[j].isDefault() && widget.creditCardsDetails()[j].repositoryId() == widget.allCreditCards()[i].id() ){
                        // console.log(widget.creditCardsDetails()[j])
                        widget.allCreditCards()[i].setAsDefault(true)
                        
                    }
                    }
                }
            },
            
            beforeAppear: function(page) {
                var widget = this;
                widget.orderDefaultSavedCardId = null;
                widget.allCreditCards.removeAll();
                widget.getCreditCardsForProfile();
                //   widget.assignCreditCardDetails();
                if (widget.allCreditCards().length > 0) {
                    widget.creditCardAvailable(false)
                }
/*                if(widget.user().parentOrganization){
                    console.log("B2B");
                  widget.loadOrganizationAddresses();
                }else{
                    console.log("B2C");
                widget.setDefaultAddressFromDynamicProperties();
                }
*/                
                

                widget.listingViewModel().clearOnLoad = true;
                widget.listingViewModel().orgValue = widget.user().currentOrganization() ? widget.user().currentOrganization().repositoryId : null;
                widget.listingViewModel().load(1, 1);
                // widget.getCreditCardsForProfile();
                widget.addCardToPaymentViewModel();

                paytrace.setKeyAjax('/file/v2139865766673691953/thirdparty/.well-known/public_key.pem');

                if (widget.user().isB2BUser()) {
                    widget.userIsAccountAddressManager(widget.user().isAccountAddressManager() || widget.user().isDelegatedAdmin());
                    widget.userIsProfileAddressManager(widget.user().isProfileAddressManager());
                    //  getWidget.billingAddressBackUp.stateList(getWidget.stateArray())

                    widget.reloadAddressInfo();

                    widget.editBillingAddress(false);
                    widget.editPayUBillingAddress(false);
                    widget.editInvoiceBillingAddress(false);

                }


                if (widget.user().updatedShippingAddressBook && !widget.user().isB2BUser()) {
                    for (var i = 0; i < widget.user().updatedShippingAddressBook.length; i++) {
                        if (widget.user().updatedShippingAddressBook[i].isDefaultAddress) {
                            widget.paymentViewModel().billingAddress().copyFrom(widget.user().updatedShippingAddressBook[i], widget.billingCountries());
                            
                            
/*                             if((widget.paymentViewModel().billingAddress().address2 !== null)){
                                      if((widget.paymentViewModel().billingAddress().address2().toLowerCase().indexOf("suite") !== -1)){
                                   widget.selectedBillingAddress2Type(widget.paymentViewModel().billingAddress().address2().substring(0,5));
                                   widget.paymentViewModel().billingAddress().address2(widget.paymentViewModel().billingAddress().address2().substring(6,widget.paymentViewModel().billingAddress().address2.length));    
                                }else  if((widget.paymentViewModel().billingAddress().address2().toLowerCase().indexOf("apartment") !== -1)){
                                    console.log(widget.paymentViewModel().billingAddress().address2().substring(0,10));
                                   widget.selectedBillingAddress2Type(widget.paymentViewModel().billingAddress().address2().substring(0,10));
                                   widget.paymentViewModel().billingAddress().address2(widget.paymentViewModel().billingAddress().address2().substring(10,widget.paymentViewModel().billingAddress().address2().length));    
                                }else  if((widget.paymentViewModel().billingAddress().address2().toLowerCase().indexOf("building") !== -1)){
                                   widget.selectedBillingAddress2Type(widget.paymentViewModel().billingAddress().address2().substring(0,8));
                                  widget.paymentViewModel().billingAddress().address2(widget.paymentViewModel().billingAddress().address2().substring(9,widget.paymentViewModel().billingAddress().address2.length));    
                                }else  if((widget.paymentViewModel().billingAddress().address2().toLowerCase().indexOf("p.o.") !== -1)){
                                   widget.selectedBillingAddress2Type(widget.paymentViewModel().billingAddress().address2().substring(0,8));
                                   widget.paymentViewModel().billingAddress().address2(widget.paymentViewModel().billingAddress().address2().substring(9,widget.paymentViewModel().billingAddress().address2.length));    
                                }else{
                                    widget.selectedBillingAddress2Type("");
                                    widget.paymentViewModel().billingAddress().address2(widget.paymentViewModel().billingAddress().address2());
                                }
                        }else{
                
                                widget.selectedBillingAddress2Type("");
                                  widget.paymentViewModel().billingAddress().address2("");
                
                            
                        }
*/                            
                            break;
                        }
                    }
                }
                   
            },
                fetchCountryandStateName: function(countryCode, stateCode) {
     var widget = this;
     var country = null;
     var countryAndStateName = {};
      for (var i = 0; i < widget.countriesList().length;i++) {
        if (countryCode === widget.countriesList()[i].countryCode) {
          country = widget.countriesList()[i];
          countryAndStateName.country = widget.countriesList()[i].displayName;
          break;
        }
      }
      if (country.regions && country.regions.length > 0) {
        for (var j = 0; j < country.regions.length; j++) {
           if (stateCode === country.regions[j].abbreviation) {
             countryAndStateName.state = country.regions[j].displayName;
             break;
           }
        }
      }
      return countryAndStateName;
    },
            
            
                loadOrganizationAddresses: function() {
      var widget = this;
      var data,input = {};       
      var url = CCConstants.END_POINT_GET_ADDRESSES;
      var url2= CCConstants.END_POINT_LIST_ADDRESSES;
      var orgId =(CCRestClient.profileType === CCConstants.PROFILE_TYPE_AGENT)? widget.organizationFilter() : widget.user().currentOrganization().repositoryId;
      
      input["orgId"]=orgId;
      input[CCConstants.OFFSET] = widget.accountOffset();
      input[CCConstants.LIMIT] = widget.limit();
      var index=0;
      CCRestClient.request(url, input, widget.fetchAddressesSuccess.bind(widget), widget.fetchAddressesFailure.bind(widget));
      CCRestClient.request(url2, input, widget.loadOrganizationAddressesSuccess.bind(widget),widget.fetchAddressesFailure.bind(widget));
    },
    
        loadOrganizationAddressesSuccess: function(data){
      var widget = this;

/*        //widget.secondaryAddresses.push(data.items);
        if (!(CCRestClient.profileType === CCConstants.PROFILE_TYPE_AGENT))  {
          for (var iter = 0;iter <data.items.length; iter++){
            data.items[iter].isInherited = false;
          }
          widget.allAddresses.push(data.items);
//           widget.secondaryAddresses(widget.secondaryAddresses().concat(data.items));
        } else {
          if (widget.secondaryAddresses().length === 0) {
            if(data.items.length>0){
              for(var iter = 0;iter <data.items.length; iter++){
                data.items[iter].isInherited = false;
                var fullDisplayNameOfcountryAndState = widget.fetchCountryandStateName(data.items[iter].address.country, data.items[iter].address.state);
                data.items[iter].address.displayCountryName = fullDisplayNameOfcountryAndState.country;
                data.items[iter].address.displayStateName = fullDisplayNameOfcountryAndState.state? fullDisplayNameOfcountryAndState.state : " ";
            }
            widget.allAddresses.push(data.items);
            widget.secondaryAddresses(widget.secondaryAddresses().concat(data.items));
         widget.secondaryAddresses1(widget.secondaryAddresses().concat(data.items));
          }
        }
      }*/
        //widget.setDefaultAdresses();  
/*        widget.accountOffset(data.offset + data.items.length);
        widget.totalAccountAddresses(data.total);
        if (widget.totalAccountAddresses() > widget.accountOffset()){
          widget.showLoadMoreAccountAddress(true);              
      } else {
          widget.showLoadMoreAccountAddress(false);
          widget.accountOffset(0);
      }*/
    },
         fetchAddressesSuccess: function(pResponse) {
       var widget = this;
       var fullDisplayNameOfcountryAndState = null;
       if (widget.user().isB2BUser() && pResponse.billingAddress){
         fullDisplayNameOfcountryAndState = widget.fetchCountryandStateName(pResponse.billingAddress.country, pResponse.billingAddress.state);
         pResponse.billingAddress.displayCountryName = fullDisplayNameOfcountryAndState.country;
         pResponse.billingAddress.displayStateName = fullDisplayNameOfcountryAndState.state? fullDisplayNameOfcountryAndState.state : " ";
         widget.defaultBillingAddress(pResponse.billingAddress);
       } else {
         widget.defaultBillingAddress(null);
       }

       if(widget.defaultBillingAddress() && widget.defaultBillingAddress().repositoryId){
         CCRestClient.request(CCConstants.END_POINT_GET_ADDRESS,null,
           function(data){
             var fullDisplayNameOfcountryAndState = widget.fetchCountryandStateName(data.address.country, data.address.state);
             data.address.displayCountryName = fullDisplayNameOfcountryAndState.country;
             data.address.displayStateName = fullDisplayNameOfcountryAndState.state? fullDisplayNameOfcountryAndState.state : " ";
             if(data.address.isInherited){
               data["isInherited"]=true;
             }else{
               data["isInherited"]=false; 
             } 
             if(widget.addresses().length<2)
             {
               data.address.isDefaultBillingAddress = true;
               widget.addresses.push(data);  
               widget.addresses.valueHasMutated();
//               widget.checkSameDefaultAddress();
             }             
             
             
             for(var i=0;i<widget.addresses().length;i++){
                 if(widget.addresses()[i].address.isDefaultBillingAddress){
                     
                     
                     if(widget.addresses()[i].address.address2)
                     
                     
                 if([null,undefined,""].indexOf(widget.addresses()[i].address.address2) == -1){
                      if((widget.addresses()[i].address.address2.toLowerCase().indexOf("suite") !== -1)){
                          
                   getWidget.selectedBillingAddress2Type(widget.addresses()[i].address.address2.substring(0,5));
                   
                   widget.addresses()[i].address.address2=widget.addresses()[i].address.address2.substring(6,widget.addresses()[i].address.address2.length);    
                   
                }else  if((widget.addresses()[i].address.address2.toLowerCase().indexOf("apartment") !== -1)){
                    
                   getWidget.selectedBillingAddress2Type(widget.addresses()[i].address.address2.substring(0,9));
                   
                   widget.addresses()[i].address.address2=widget.addresses()[i].address.address2.substring(10,widget.addresses()[i].address.address2.length);    
                   
                }else  if((widget.addresses()[i].address.address2.toLowerCase().indexOf("building") !== -1)){
                    
                   getWidget.selectedBillingAddress2Type(widget.addresses()[i].address.address2.substring(0,8));
                   
                   widget.addresses()[i].address.address2=widget.addresses()[i].address.address2.substring(9,widget.addresses()[i].address.address2.length);    
                   
                }else  if((widget.addresses()[i].address.address2.toLowerCase().indexOf("p.o.") !== -1)){
                   getWidget.selectedBillingAddress2Type(widget.addresses()[i].address.address2.substring(0,8));
                   widget.addresses()[i].address.address2=widget.addresses()[i].address.address2.substring(9,widget.addresses()[i].address.address2.length);    
                }else{
                    getWidget.selectedBillingAddress2Type("");
                   widget.addresses()[i].address.address2=widget.addresses()[i].address.address2;
                }
        }else{
                getWidget.selectedBillingAddress2Type("");
                widget.addresses()[i].address.address2="";
        }
                     
                     
    for(var k=0;k<getWidget.addressBookArray().length;k++){
        if(getWidget.addressBookArray()[k].repositoryId == widget.addresses()[i].address.repositoryId ){
            getWidget.selectedpaymentAddress(getWidget.addressBookArray()[k])
        }
    }
                     
                     
    widget.customDefaultBillingAddress(widget.addresses()[i].address)

 var request = {
                    "address1":  widget.customDefaultBillingAddress().address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + widget.customDefaultBillingAddress().address2,
                                        "city": widget.customDefaultBillingAddress().city,
                                        "state": widget.customDefaultBillingAddress().state,
                                        "postalCode": widget.customDefaultBillingAddress().postalCode,
                                        "country": widget.customDefaultBillingAddress().country
                                    };
                    
                                    
getWidget.addressValidationRequest=request;

    
    
                     
                 }
             }
             
           }, function(){}, 
           widget.defaultBillingAddress().repositoryId);      
       }
       if(widget.user().isB2BUser() && pResponse.shippingAddress) {
         var fullDisplayNameOfcountryAndState = widget.fetchCountryandStateName(pResponse.shippingAddress.country, pResponse.shippingAddress.state);
         pResponse.shippingAddress.displayCountryName = fullDisplayNameOfcountryAndState.country;
         pResponse.shippingAddress.displayStateName = fullDisplayNameOfcountryAndState.state? fullDisplayNameOfcountryAndState.state : " ";
//         widget.defaultShippingAddress(pResponse.shippingAddress);
       } else {
//         widget.defaultShippingAddress(null);
       }
/*       if(widget.defaultShippingAddress() && widget.defaultShippingAddress().repositoryId)
       {
         CCRestClient.request(CCConstants.END_POINT_GET_ADDRESS,null,  
           function(data){
             var fullDisplayNameOfcountryAndState = widget.fetchCountryandStateName(data.address.country, data.address.state);
             data.address.displayCountryName = fullDisplayNameOfcountryAndState.country;
             data.address.displayStateName = fullDisplayNameOfcountryAndState.state ? fullDisplayNameOfcountryAndState.state : " ";
             if(data.address.isInherited){
               data["isInherited"]=true;
             }else{
               data["isInherited"]=false; 
             }
             if(widget.addresses().length<2)
             {
               data.address.isDefaultShippingAddress = true;
               widget.user().primaryShippingAddress(data.address);
               widget.addresses.push(data);
               widget.addresses.valueHasMutated();
               widget.checkSameDefaultAddress();
             }
           }, 
           function(){}, 
           widget.defaultShippingAddress().repositoryId); 
       }*/
/*       widget.replaceAllAddress2NullStringWithNull(pResponse.secondaryAddresses);
       widget.setDefaultAdresses();*/
     },
        fetchAddressesFailure: function(pError) {
    
    },
    
    

            /**
             * Repopulate this form with up to date info from the User view model.
             */
            reloadAddressInfo: function() {
                var widget = this;
                console.log("reload")
                if (widget.user().loggedIn() === true && widget.user().organizationAddressBook &&
                    widget.user().organizationAddressBook.length > 0) {
                    var organizationAddresses = [];
                    widget.selectedBillingAddressId('');
                    console.log(widget.user().organizationAddressBook, "widget.user().organizationAddressBook")
                    for (var k = 0; k < widget.user().organizationAddressBook.length; k++) {
                        var organizationAddress = new Address('user-saved-shipping-address', widget.ErrorMsg, widget, widget
                            .billingCountries(), widget.defaultBillingCountry());
                        organizationAddress.stateList.push(widget.stateArray());
                                    console.log("illiiii")
                        organizationAddress.copyFrom(widget.user().organizationAddressBook[k], widget.billingCountries());

                        // Save shipping address JS object to Address object.
                        organizationAddress.resetModified();

                        organizationAddresses.push(organizationAddress);
                        if ((widget.user().contactBillingAddress && widget.user().contactBillingAddress.repositoryId === widget
                                .user().organizationAddressBook[k].repositoryId)) {
                            widget.billingAddressBackUp = organizationAddress;
                            widget.billingAddressSelected(true);
                            widget.selectedBillingAddressId(widget.user().organizationAddressBook[k].repositoryId);
                            widget.hasDefaultBillingAddress(true);
                        }
                    }
                    if (widget.billingAddressBackUp === null && widget.user().contactBillingAddress !== null) {
                        organizationAddress.copyFrom(widget.user().contactBillingAddress, widget
                            .billingCountries());
                        widget.billingAddressBackUp = organizationAddress;

                        widget.billingAddressSelected(true);
                        widget.selectedBillingAddressId(organizationAddress.repositoryId);
                        widget.hasDefaultBillingAddress(true);
                        ccRestClient.request(CCConstants.END_POINT_GET_ADDRESS, null, function(data) {
                            widget.defaultShippingAddressType(data.addressType);
                            widget.order().shippingAddress().type(data.addressType);
                            widget.shippingAddressBackUp.type(data.addressType);
                        }, function() {}, organizationAddress.repositoryId);
                    }
                    widget.organizationAddressBook(organizationAddresses);

                    var index = 0;
                    // reset all offsets so the addresses are loaded from 0.
                    widget.offset(0);
                    widget.profileOffset(0);
                    widget.accountOffset(0);
                    // clear all the address lists before reloading them.
                    widget.inheritedAddressBook.removeAll();
                    widget.profileAddressBook.removeAll();
                    widget.accountAddressBook.removeAll();
                    // methods to load address lists
                    widget.loadAccountAddresses();
                    widget.loadInheritedAddressess();
                    widget.loadProfileAddresses();

                }

            },
              setSelectedAddress: function() {
                getWidget.closesuggesionmodal();
                var request = {};
                getWidget.customDefaultBillingAddress().address1=getWidget.validAddresses()[0].line1
                
                if (getWidget.validAddresses()[0].line2 !== "") {
                    
                getWidget.customDefaultBillingAddress().address2=getWidget.validAddresses()[0].line2
                    
                                                if([null,undefined,""].indexOf(getWidget.customDefaultBillingAddress().address2) == -1){
                      if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("suite") !== -1)){
                          
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,5));    
                   getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(5, getWidget.customDefaultBillingAddress().address2.length);
                   
                   
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("apartment") !== -1)){
                    
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,9));    
                  getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(9,getWidget.customDefaultBillingAddress().address2.length);

                   
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("building") !== -1)){
                    
                    
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,8));    
                   getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(8,getWidget.customDefaultBillingAddress().address2.length);

                  
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("p.o.") !== -1)){
                    

                   
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,8));    
                   getWidget.customDefaultBillingAddress().address2=custAddress.address2.substring(8,getWidget.customDefaultBillingAddress().address2.length);
                   
                }else{

                   getWidget.selectedBillingAddress2Type("");
            //getWidget.customDefaultBillingAddress()(custAddress.address2());        
                }
        }else{

                getWidget.customDefaultBillingAddress().address2="";
                   getWidget.selectedBillingAddress2Type("");
        }
                    
                    
                    
                    
                    
                }
                
          getWidget.customDefaultBillingAddress().postalCode=getWidget.validAddresses()[0].postalCode
          getWidget.customDefaultBillingAddress().city=getWidget.validAddresses()[0].city
          getWidget.customDefaultBillingAddress().country=getWidget.validAddresses()[0].country
          getWidget.customDefaultBillingAddress().state=getWidget.validAddresses()[0].region        
          getWidget.customDefaultBillingAddress().selectedState=getWidget.validAddresses()[0].region
    
var dataa=getWidget.customDefaultBillingAddress();
getWidget.customDefaultBillingAddress(dataa)

var request

if(getWidget.user().parentOrganization){
  request = {
                    "address1": dataa.address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + dataa.address2,
                                        "city": dataa.city,
                                        "state": dataa.state,
                                        "postalCode": dataa.postalCode,
                                        "country": dataa.country
                                    };    
}else{
      request = {
                    "address1": dataa.address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + dataa.address2(),
                                        "city": dataa.city,
                                        "state": dataa.state,
                                        "postalCode": dataa.postalCode,
                                        "country": dataa.country
                                    };
}

getWidget.addressValidationRequest=request;


            },
            selectedAddress: function(type, event, data) {
                if (type === "Billing") {
//                       getWidget.customDefaultBillingAddress(getWidget.paymentViewModel().billingAddress())



getWidget.customDefaultBillingAddress(JSON.parse(ko.toJSON(getWidget.selectedpaymentAddress())))


getWidget.customDefaultBillingAddress().address2=getWidget.selectedpaymentAddress().address2();

                            if([null,undefined,""].indexOf(getWidget.customDefaultBillingAddress().address2) == -1){
                      if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("suite") !== -1)){
                          
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,5));    
                   getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(5, getWidget.customDefaultBillingAddress().address2.length);
                   
                   
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("apartment") !== -1)){
                    
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,9));    
                  getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(9,getWidget.customDefaultBillingAddress().address2.length);

                   
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("building") !== -1)){
                    
                    
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,8));    
                   getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(8,getWidget.customDefaultBillingAddress().address2.length);

                  
                }else  if((getWidget.customDefaultBillingAddress().address2.toLowerCase().indexOf("p.o.") !== -1)){
                    

                   
                   getWidget.selectedBillingAddress2Type(getWidget.customDefaultBillingAddress().address2.substring(0,8));    
                   getWidget.customDefaultBillingAddress().address2=getWidget.customDefaultBillingAddress().address2.substring(8,getWidget.customDefaultBillingAddress().address2.length);
                   
                }else{

                   getWidget.selectedBillingAddress2Type("");
//                   getWidget.customDefaultBillingAddress().address2
            //getWidget.customDefaultBillingAddress()(custAddress.address2());        
                }
        }else{

                getWidget.customDefaultBillingAddress().address2="";
                   getWidget.selectedBillingAddress2Type("");
        }
        
        
        
var addressNames=Object.keys(getWidget.user().secondaryAddresses);

for(var i=0;i<addressNames.length;i++){
    if(getWidget.user().secondaryAddresses[Object.keys(getWidget.user().secondaryAddresses)[i]].repositoryId() == getWidget.customDefaultBillingAddress().repositoryId ){
        getWidget.defaultBillingAddressType(addressNames[i]);
        break;
    }else{
        getWidget.defaultBillingAddressType("");
    }
}
        var daa= getWidget.customDefaultBillingAddress();
         getWidget.customDefaultBillingAddress(daa);
        

         var request = {
                    "address1": daa.address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + daa.address2,
                                        "city": daa.city,
                                        "state": daa.state,
                                        "postalCode": daa.postalCode,
                                        "country": daa.country
                                    };
getWidget.addressValidationRequest=request;
        
//                    if (getWidget.paymentViewModel().billingAddress().companyName() === "Add New Address") {
  //                      getWidget.paymentViewModel().billingAddress().companyName('')

    //                }
                }

            },
            
            onLoad: function(widget) {
                getWidget = widget;


      
                var queryParams = {};
                queryParams[CCConstants.REGIONS] = true;
                ccRestClient.request(CCConstants.LIST_COUNTRIES, queryParams, function(data) {
                    for (var i = 0; i < data.length; i++) {

                        if (data[i].countryCode == 'US') {
                            var country = data[i];
                            var countryArray = [];
                            countryArray[0] = country;
                            self.countryData = countryArray;
                            //self.countryData = country;
                            var states = country.regions;
                            widget.billingCountries([country]);

                            for (var k = 0; k < states.length; k++) {
                                widget.stateArray.push(states[k]);
                                if (!widget.user().isB2BUser()) {
                                    widget.paymentViewModel().billingAddress().stateList(widget.stateArray());
                                }
                            }
                            for (var i = 0; i < widget.organizationAddressBook().length; i++) {
                                widget.organizationAddressBook()[i].stateList(states);
                            }
                  widget.countriesList(widget.billingCountries());
                  
                                  if(widget.user().parentOrganization){
                    console.log("B2B");
                  widget.loadOrganizationAddresses();
                }else{
                    console.log("B2C");
                widget.setDefaultAddressFromDynamicProperties();
                }
                
                            break;
                        }
                    }
                });




                widget.listingViewModel = ko.observable();
                widget.listingViewModel(new DelegatedAdminContacts());
                widget.listingViewModel().fetchByRepositoryId = true;
                widget.listingViewModel().itemsPerPage = widget.fetchSize();
                widget.listingViewModel().blockSize = widget.fetchSize();
                widget.paymentViewModel(widget.paymentsContainer().createPaymentGroup(CCConstants.CARD_PAYMENT_TYPE));

                widget.paymentViewModel().billingAddress(new Address('creditCard-billing-address', widget.ErrorMsg, widget, widget.billingCountries(), widget.defaultBillingCountry()));
                var address = new Address('creditCard-billing-address', widget.ErrorMsg, widget, widget.billingCountries(), widget.defaultBillingCountry());
                        address.state('');
                        address.companyName("Add New Address");
                // setTimeout(function(){
                widget.addressBookArray = ko.computed(function() {
                    if (widget.user().isB2BUser() && widget.user().organizationAddressBook) {
                        
                        for (var i = 0; i < widget.user().organizationAddressBook.length; i++) {
                            var addr = widget.user().organizationAddressBook[i];
                            if (widget.selectedBillingAddressId() === addr.repositoryId) {
                                   widget.defaultAddress(new Address('creditCard-billing-address', widget.ErrorMsg, widget, widget.billingCountries(), widget.defaultBillingCountry()));
                                widget.defaultAddress().copyFrom(widget.user().organizationAddressBook[i], widget.billingCountries());
                            }
                            else{
                                 widget.paymentViewModel().billingAddress().copyFrom(widget.user().contactBillingAddress, widget.billingCountries());

                            }
                            
                        }
            
                        var exist=false;
                        for(var i=0;i<widget.organizationAddressBook().length;i++){
                            if(widget.organizationAddressBook()[i].repositoryId == ""){
                                exist=true;
                            }
                        }
                        if(!exist){
                        widget.organizationAddressBook.push(address);
                        }
                        
                        // widget.reloadAddressInfoForB2BUser();
                        return widget.organizationAddressBook();
                    }
                });
                // }, 100)



                widget.editCreditCard = function(data) {
                    console.log(data)
                    $('#noCreditCards').css('display', 'none');
                    $('#creditCardList').css('display', 'none');
                    $('#addCreditCards').css('display', 'block');
                    $('#cardNumber, #expiryMMYYYY, #cardCVV, #savedAddress,#selectedContact,#streetAddress,#selectedCity,#selectedState,#selectedPostal,#selectedCountry, #address2').attr('disabled', 'disabled')
                    widget.paymentViewModel().cardNumber(data.creditCardNumber());
                    widget.paymentViewModel().cardNumber(data.creditCardNumber());
                    var monthYear = data.expirationMonth() + '/' + data.expirationYear()
                    $('#expiryMMYYYY').val(monthYear);
                    widget.paymentViewModel().billingAddress().address1(data.billingAddress().address1());
                    widget.paymentViewModel().billingAddress().address2(data.billingAddress().address2());

                    widget.paymentViewModel().billingAddress().postalCode(data.billingAddress().postalCode());
                    widget.paymentViewModel().billingAddress().city(data.billingAddress().city());
                    widget.paymentViewModel().billingAddress().state(data.billingAddress().state());


                };

                widget.deleteCreditCard = function() {
                        var self = this
                        var token = self.token();
                        var id = self.id();
                        token = token.split('-')[1];
                        
                        var orderRefreshIndicatorOptions = {
                                    parent: '#main',
                                    posTop: '20em',
                                    posLeft: '50%'
                                }
                                $('#main').addClass('loadingIndicator');
                                $('#main').css('position', 'relative');
                                spinner.create(orderRefreshIndicatorOptions);
                                
                        for (var i = 0; i < getWidget.creditCardsDetails().length; i++) {
                            if (getWidget.creditCardsDetails()[i].repositoryId() == self.id()) {
                                getWidget.deleteCreditCardDetails(getWidget.creditCardsDetails()[i].repositoryId(),self);
                                getWidget.deleteCardDetailsFromPaytrace(token)
                                
                            }
                        }




                    },
                    
                    widget.makeAsDefault = function(self){
                       
                           var request = {
                                  "setAsDefault": true
                                }

                           var url = "updateCreditCard";

                            ccRestClient.request(url, request, function(obj) {
                                        console.log("DATA ", obj);
                                        self.setAsDefault(true);
                                    }, function(error) {
                                        console.log("error ", error);
                                    }, self.id());
                                
                        return true;
                    }


                    widget.deleteCardDetailsFromPaytrace = function(token) {
                        var payload = {
                            'userId': token
                        }

                        $.ajax({
                            url: '/ccstorex/custom/v1/deleteUserPaytrace',
                            method: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify(payload)
                        }).done(function(obj) {
                            if(obj.response_code == 162){
                                 console.log("Success : ",obj)
                            }else{
                                console.log("error occured")
                            }
                            
                        }).fail(function(error) {
                            console.log("error", error)
                        });


                    },

                    widget.loadProfileAddresses = function() {
                        // Fetch Inherited Addresses
                        var url = CCConstants.END_POINT_LIST_PROFILE_ADDRESSES;
                        var input = {};
                        input[CCConstants.OFFSET] = widget.profileOffset();
                        input[CCConstants.LIMIT] = widget.limit();
                        ccRestClient.request(url, input, function(data) { // Success Call
                            // back
                            if (data.items && data.items.length > 0) {
                                widget.createAddresses('profile-addresses', data, widget.profileAddressBook);
                                widget.profileOffset(data.offset + data.items.length);
                                widget.totalProfileAddresses(data.total);
                                if (widget.totalProfileAddresses() > widget.profileOffset())
                                    widget.loadMoreProfileAddresses(true);
                                else {
                                    widget.loadMoreProfileAddresses(false);
                                    widget.profileOffset(0);
                                }
                            }

                        }, function(pError) { // Error Call back
                            console.log("1")
                            notifier.sendError(widget.WIDGET_ID, pError.message, true);
                        });
                    };
                    
                widget.resetSelectedSavedCardId = function() {
                    widget.selectedSavedCardId(null);
                    for (var i = 0; i < widget.allCreditCards().length; i++) {
                        widget.allCreditCards()[i].resetCardCvv();
                        widget.allCreditCards()[i].cardCVV.isModified(false);
                        if (widget.orderDefaultSavedCardId ==
                            widget.allCreditCards()[i].id()) {
                            widget.selectedSavedCardId(widget.orderDefaultSavedCardId);
                            break;
                        }
                    }
                    if (widget.selectedSavedCardId() == null) {
                        for (var i = 0; i < widget.creditCardsDetails().length; i++) {
                            if (widget.creditCardsDetails()[i].isDefault() == true) {
                                widget.deleteCreditCardTest(widget.creditCardsDetails()[i]);
                                console.log(widget.deleteCreditCardTest())
                                widget.selectedSavedCardId(widget.creditCardsDetails()[i].savedCardId());
                                break;
                            }
                        }
                    }
                    if (widget.selectedSavedCardId() == null &&
                        widget.allCreditCards().length > 0) {
                        widget.selectedSavedCardId(widget.allCreditCards()[0].savedCardId());
                    }
                };

                 
                widget.delegatedAdminContactsListGrid = ko.computed(function() {
                    var numElements, start, end, width;
                    var rows = [];
                    var orders;
                    var startPosition, endPosition;
                    // Get the orders in the current page
                    startPosition = (widget.listingViewModel().currentPage() - 1) * widget.listingViewModel().itemsPerPage;
                    endPosition = startPosition + parseInt(widget.listingViewModel().itemsPerPage, 10);
                    orders = widget.listingViewModel().data();

                    if (!orders) {
                        return;
                    }
                    numElements = orders.length;
                    width = parseInt(widget.listingViewModel().itemsPerRow(), 10);
                    start = 0;
                    end = start + width;
                    while (end <= numElements) {
                        rows.push(orders.slice(start, end));
                        start = end;
                        end += width;
                    }
                    if (end > numElements && start < numElements) {
                        rows.push(orders.slice(start, numElements));
                    }
                    //Generating localized roleString for each user
                    /**if(rows.length >= 0) {
                      var rowsLength = rows.length;
                      for(var row = 0; row < rowsLength; row++) {
                        rows[row][0]["roleString"] = widget.getRoleString(rows[row][0]["roles"]);
                      }
                    }**/
                    return orders;
                }, widget);




                /**
                 * method to load local addresses of an account
                 */
                widget.loadAccountAddresses = function() {
                    // Fetch Inherited Addresses
                    var input = {};
                    var url = CCConstants.END_POINT_LIST_ADDRESSES;
                    input[orgId] = widget.user().currentOrganization().repositoryId;
                    input[CCConstants.OFFSET] = widget.accountOffset();
                    input[CCConstants.LIMIT] = widget.limit();
                    // Fetch Account Addresses
                    ccRestClient.request(url, input, function(data) { // Success Call
                        // back
                        if (data.items && data.items.length > 0) {
                            widget.createAddresses('account-addresses', data, widget.accountAddressBook);
                            widget.accountOffset(data.offset + data.items.length);
                            widget.totalAccountAddresses(data.total);
                            if (widget.totalAccountAddresses() > widget.accountOffset()) {
                                widget.loadMoreAccountAddresses(true);
                            } else {
                                widget.loadMoreAccountAddresses(false);
                                widget.accountOffset(0);
                            }
                            if (data.derivedBillingAddressType !== "null") {
                                widget.defaultBillingAddressType(data.derivedBillingAddressType);
                                widget.billingAddressBackUp.type(data.derivedBillingAddressType);
                            }
                        }
                    }, function(pError) { // Error Call back
                        notifier.sendError(widget.WIDGET_ID, pError.message, true);
                    });
                };

                /**
                 * Custom method to create addresses from the data in server response
                 * and adding to the list provided in parameters to the method.
                 */

                widget.saveCreditCard = function() {

                        var widget = this;
                        widget.validateMandatoryFields();

                        var val = widget.validateMandatoryFields();
                        console.log(val)
                        // Build the request data
                        var customer_id;
                        var customer;
                        if (val) {
                            
                             var todayDate = new Date();
                            var todayDateWithMonthTime = (todayDate.getMonth()+1).toString();
                            todayDateWithMonthTime += todayDate.getDate().toString();
                            todayDateWithMonthTime += todayDate.getHours().toString();
                            todayDateWithMonthTime += todayDate.getMinutes().toString();
                            todayDateWithMonthTime += todayDate.getSeconds().toString();

                                customer_id = getWidget.user().id() + '_' +todayDateWithMonthTime
                                var orderRefreshIndicatorOptions = {
                                    parent: '#main',
                                    posTop: '20em',
                                    posLeft: '50%'
                                }
                                $('#main').addClass('loadingIndicator');
                                $('#main').css('position', 'relative');
                                spinner.create(orderRefreshIndicatorOptions);

                                var selectedContact;
                                if (widget.user().isB2BUser()) {
                                    selectedContact = $("#selectedContact option:selected").text();
                                } else {
                                    selectedContact = document.getElementById("savedContact").value;

                                }

                                var address = document.getElementById("streetAddress").value;
                                var address2 = document.getElementById("CC-splitpayments-cc-baddress2").value;
                                var address2_no = document.getElementById("address2").value;
                                var city = document.getElementById("selectedCity").value;
                                var state = document.getElementById("selectedState").value;
                                var zip = document.getElementById("selectedPostal").value;
                                var nameonCard;

                                //   var phoneNumber = document.getElementById("phoneNumber").value;

                                var request_data = {
                                    "customer_id": customer_id,
                                    "credit_card": {
                                        "encrypted_number": getWidget.CCNumberEncrypted(),
                                        "expiration_month": getWidget.expiryMonth(),
                                        "expiration_year": getWidget.expiryYear()
                                    },
                                    "integrator_id": "91543646T5Kq",
                                    "billing_address": {
                                        "name": selectedContact,
                                        "street_address": address,
                                        "street_address2": address2 +" "+ address2_no,
                                        "city": city,
                                        "state": state,
                                        "zip": zip
                                    }
                                };
                                console.log(request_data, "Before sending the details");

                                $.ajax({
                                    url: '/ccstorex/custom/v1/saveCard',
                                    method: 'POST',
                                    contentType: 'application/json',
                                    data: JSON.stringify(request_data)
                                }).done(function(obj) {
                                    console.log("Success : ", obj);
                                    customer = obj.customers[0];
                                    console.log(customer)
                                    if (customer.credit_card.expiration_month < 10) {
                                        customer.credit_card.expiration_month = '0' + customer.credit_card.expiration_month;
                                    }
                                    console.log(customer.billing_address.name.split(' ')[1], "last Name value")
                                    var lastName;
                                    if(!customer.billing_address.name.split(' ')[1]){
                                        lastName = selectedContact
                                    }else{
                                        lastName = customer.billing_address.name.split(' ')[1];
                                    }
                                    //karthick added for getting card type 28/06/2021
                                     var cardType = widget.getCardType(getWidget.cardNumber());
                                     console.log("cardTypeeeee",cardType);
                                    var request = {
                                        "cardCVV": getWidget.cardCVV(),
                                        "nameOnCard": customer.billing_address.name,
                                        "customProperties": {

                                            "customer_id": customer.customer_id
                                        },
                                        "expiryMonth": customer.credit_card.expiration_month + '', //customer.credit_card.expiration_month,
                                        "cardType": cardType,
                                        "expiryYear": '20' + customer.credit_card.expiration_year, //'20' + customer.credit_card.expiration_year,
                                        "billingAddress": {
                                            "lastName": lastName, //customer.billing_address.name.split(' ')[1],
                                            "country": "US",
                                            "city": customer.billing_address.city, //customer.billing_address.city,
                                            "address1": customer.billing_address.street_address, //customer.billing_address.street_address,
                                            "address2": customer.billing_address.street_address2, //customer.billing_address.street_address,
                                            "postalCode": customer.billing_address.zip, // customer.billing_address.zip,
                                            "county": "",
                                            "selectedCountry": "US",
                                            "firstName": customer.billing_address.name.split(' ')[0],
                                            "phoneNumber": "212-555-1977",
                                            "state": customer.billing_address.state, //customer.billing_address.state,
                                            "selectedState": customer.billing_address.state,
                                            "email": "kim@example.com",
                                            "state_ISOCode": "US-NY"
                                        },
                                        "cardNumber": getWidget.cardNumber(),
                                        "setAsDefault": true
                                    };

                                    console.log(request);
                                    var url = "addCreditCard";

                                    ccRestClient.request(url, request, function(obj) {
                                        console.log("DATA ", obj);
                                        location.reload();
                                    }, function(error) {
                                        console.log("error ", error);
                                    });
                                }).fail(function(error) {
                                    console.log("error", error)
                                });

                            
                        }



                    },
                    
                    //karthick added for getting card type 28/06/2021
                    
                    widget.getCardType =  function(number) {
                console.log(number);
                var re = new RegExp("^4");
                if (number.match(re) !== null)
                    return "visa";

                // Mastercard 
                // Updated for Mastercard 2017 BINs expansion
                var mastercardRegEx = /^(?:5[1-5][0-9]{14})$/;
                if (mastercardRegEx.test(number))
                    return "mastercard";

                // AMEX
                re = new RegExp("^3[47]");
                if (number.match(re) !== null)
                    return "amex";

                // Discover
                re = new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)");
                if (number.match(re) !== null)
                    return "discover";

                // Diners
                re = new RegExp("^36");
                if (number.match(re) !== null)
                    return "Diners";

                // Diners - Carte Blanche
                re = new RegExp("^30[0-5]");
                if (number.match(re) !== null)
                    return "Diners - Carte Blanche";

                // JCB
                re = new RegExp("^35(2[89]|[3-8][0-9])");
                if (number.match(re) !== null)
                    return "JCB";

                // Visa Electron
                re = new RegExp("^(4026|417500|4508|4844|491(3|7))");
                if (number.match(re) !== null)
                    return "Visa Electron";

                return "";
            },

                    widget.createAddresses = function(id, data, addresses) {
                        // console.trace();
                        for (var i = 0; i < data.items.length; i++) {


                            var address = new Address(id, widget.ErrorMsg, widget, widget.billingCountries(), widget.defaultBillingCountry());
                            address.copyFrom(data.items[i].address, widget.billingCountries());
                            if (address.country()) {
                                address[CCConstants.PARAMETERS_TYPE](data.items[i].addressType);
                                address.resetModified();
                                addresses.push(address);
                            }
                        }
                        return addresses;
                    };

                /**
                 * method to load inherited addresses of an account
                 */
                widget.loadInheritedAddressess = function() {
                    // Fetch Inherited Addresses
                    var url = CCConstants.END_POINT_LIST_ADDRESSES;
                    var input = {};
                    input[orgId] = widget.user().currentOrganization().repositoryId;
                    input[CCConstants.INCLUDE] = CCConstants.END_POINT_INHERITED_ADDRESSES;
                    input[CCConstants.OFFSET] = widget.offset();
                    input[CCConstants.LIMIT] = widget.limit();
                    ccRestClient.request(url, input, function(data) { // Success Call
                        // back
                        if (data.items && data.items.length > 0) {
                            widget.createAddresses('inherited-addresses', data, widget.inheritedAddressBook);
                            widget.offset(data.offset + data.items.length);
                            widget.totalInheritedAddresses(data.total);
                            if (widget.totalInheritedAddresses() > widget.offset())
                                widget.showLoadMore(true);
                            else {
                                widget.showLoadMore(false);
                                widget.offset(0);
                            }
                        }
                    }, function(pError) { // Error Call back
                        console.log("1")
                        notifier.sendError(widget.WIDGET_ID, pError.message, true);
                    });
                };

                widget.selectedContact = function(data, type, paymentType) {
                    $('#selectedContact').css("border", "1.5px solid #d3d3d3")
                    $('#selectedContact-label').css('color', "black")

                    if (type === "Billing") {
                        if (paymentType === "Card") {
                            widget.paymentViewModel().billingAddress().firstName(widget.billingContact().firstName);
                            widget.paymentViewModel().billingAddress().lastName(widget.billingContact().lastName);
                        }
                    }
                };


                widget.addCardToPaymentViewModel = function() {
                    for (var i = 0; i < widget.allCreditCards().length; i++) {
                        if (widget.selectedSavedCardId() == widget.allCreditCards()[i].savedCardId()) {
                            var newCard = widget.paymentsContainer().createPaymentGroup(
                                CCConstants.CARD_PAYMENT_TYPE)
                            newCard.populateData(ko.mapping.toJS(widget.allCreditCards()[i]));
                            newCard.cardCVV(widget.allCreditCards()[i].cardCVV());
                            newCard.isSavedCard(true);
                            if (widget.allCreditCards()[i].cardCVV() === undefined) {
                                widget.allCreditCards()[i].cardCVV.isModified(true);
                            }
                            console.log(newCard)
                            widget.paymentViewModel(newCard);
                        }
                    }
                };
            },


            openAddCreditCard: function() {
                $('#noCreditCards').css('display', 'none');
                $('#creditCardList').css('display', 'none');
                $('#addCreditCards').css('display', 'block');


            },

            validateMandatoryFields: function() {
                var widget = this;
                console.log(widget.paymentViewModel().cardNumber(), "inside");
                console.log(widget.expiryMMYY(), "inside")
                var valid = true;
                if ([null, undefined, ''].indexOf(widget.paymentViewModel().cardCVV()) !== -1) {
                    widget.mandatoryFields(true);
                    document.getElementById("cardCVV").style = "border: 2px solid #f33";
                    document.getElementById("cardCVV-label").style = "color:#f33";
                }
                if ([null, undefined, ''].indexOf(widget.paymentViewModel().cardNumber()) !== -1) {
                    widget.mandatoryFields(true);
                    document.getElementById("cardNumber").style = "border: 2px solid #f33";
                    document.getElementById("cardNumber-label").style = "color:#f33";
                }

                if ($('#expiryMMYYYY').length) {
                    if ([null, undefined, ''].indexOf(widget.expiryMMYY()) !== -1) {
                        widget.mandatoryFields(true);
                        document.getElementById("expiryMMYYYY").style = "border: 2px solid #f33";
                        document.getElementById("expiryMMYY-label").style = "color:#f33";
                    }
                }


                if ([null, undefined, ''].indexOf(widget.paymentViewModel().billingAddress().postalCode()) !== -1) {
                    widget.mandatoryFields(true);
                    document.getElementById("selectedPostal").style = "border: 2px solid #f33";
                    document.getElementById("selectedPostal-label").style = "color:#f33";
                }


                if (([null, undefined, ''].indexOf(widget.paymentViewModel().billingAddress().address1()) !== -1)) {
                    widget.mandatoryFields(true);
                    document.getElementById("streetAddress").style = "border: 2px solid #f33";
                    document.getElementById("streetAddress-label").style = "color:#f33";
                }

                if (([null, undefined, ''].indexOf(widget.paymentViewModel().billingAddress().city()) !== -1)) {
                    widget.mandatoryFields(true);
                    document.getElementById("selectedCity").style = "border: 2px solid #f33";
                    document.getElementById("selectedCity-label").style = "color:#f33";
                }

                if ([null, undefined, ''].indexOf(widget.paymentViewModel().billingAddress().selectedCountry()) !== -1) {
                    widget.mandatoryFields(true);
                    document.getElementById("selectedCountry").style = "border: 2px solid #f33";
                    document.getElementById("selectedCountry-label").style = "color:#f33";
                }

                if ([null, undefined, ''].indexOf(widget.billingContact()) !== -1) {
                    if (document.getElementById("selectedContact")) {
                        widget.mandatoryFields(true);
                        document.getElementById("selectedContact").style = "border: 2px solid #f33";
                        document.getElementById("selectedContact-label").style = "color:#f33";
                    }

                }
                if ([null, undefined, ''].indexOf(widget.user().firstName()) !== -1) {
                    widget.mandatoryFields(true);
                    document.getElementById("savedContact").style = "border: 2px solid #f33";
                    document.getElementById("savedContact-label").style = "color:#f33";
                }




                if (widget.mandatoryFields()) {
                    return false;
                }
                return true;

            },

            validateAddress: function(event, data) {
                if (event !== undefined) {
                    console.log(event.type);
                    //karthick added for tab out address validation
                    if(event.keyCode == 9 || 'blur' === event.type || 'focus' === event.type){
                    /*if ('click' === event.type || 'change' === event.type || 'mouseout' === event.type) {*/
                        console.log("inside validate adress")
                        var orderRefreshIndicatorOptions = {
                            parent: '#main',
                            posTop: '20em',
                            posLeft: '50%'
                        }
                        // $('#main').addClass('loadingIndicator');
                        // $('#main').css('position', 'relative');
                        // spinner.create(orderRefreshIndicatorOptions);

                        var address = getWidget.paymentViewModel().billingAddress();

                        if (getWidget.paymentViewModel().billingAddress().firstName() == '') {
                            getWidget.paymentViewModel().billingAddress().firstName('hrllo');
                        }
                        if (getWidget.paymentViewModel().billingAddress().lastName() == '') {
                            getWidget.paymentViewModel().billingAddress().lastName("test");
                        }
                        if (getWidget.paymentViewModel().billingAddress().phoneNumber() == '') {
                            getWidget.paymentViewModel().billingAddress().phoneNumber("9999999999")
                        }


                        $('#selectedCity').blur(function() {
                            if (this.value) {
                                $('#selectedCity').css('border', "2px solid #d3d3d3");
                                $('#selectedCity-label').css('color', "black");
                            }

                        });

                        $('#selectedState').blur(function() {
                            if (this.value) {
                                $('#selectedState').css("border", "1.5px solid #d3d3d3")
                                $('#selectedState-label').css('color', "black")
                            }

                        });




                        $('#streetAddress').blur(function() {
                            if (this.value) {
                                $('#streetAddress').css('border', "2px solid #d3d3d3")
                                $('#streetAddress-label').css('color', "black")
                            }

                        })

                        $('#selectedPostal').blur(function() {
                            if (this.value) {
                                $('#selectedPostal').css('border', "2px solid #d3d3d3")
                                $('#selectedPostal-label').css('color', "black")
                            }

                        })

                        spinner.destroy();
                        var isAddressValid = false;

                        if ((data.address1 && data.city && data.postalCode && data.country && data.state)) {

                            if (address.validateForShippingMethod()) {
                                var request = {};
                                if (address) {


/*         if(getWidget.user().parentOrganization){
                    console.log("B2B");
 request = {
                    "address1":  getWidget.customDefaultBillingAddress().address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + getWidget.customDefaultBillingAddress().address2,
                                        "city": getWidget.customDefaultBillingAddress().city,
                                        "state": getWidget.customDefaultBillingAddress().state,
                                        "postalCode": getWidget.customDefaultBillingAddress().postalCode,
                                        "country": getWidget.customDefaultBillingAddress().country
                                    };
                }else{
                    console.log("B2C");

                        
                    }
*/

                    if(getWidget.customDefaultBillingAddress().address1 != undefined){

if(typeof(getWidget.customDefaultBillingAddress().address1) == "function"){
 request = {
                    "address1":  getWidget.customDefaultBillingAddress().address1(),
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + getWidget.customDefaultBillingAddress().address2(),
                                        "city": getWidget.customDefaultBillingAddress().city(),
                                        "state": getWidget.customDefaultBillingAddress().state(),
                                        "postalCode": getWidget.customDefaultBillingAddress().postalCode(),
                                        "country": getWidget.customDefaultBillingAddress().country()
                                    };    
}else{
     if(getWidget.user().parentOrganization){
              request = {
                    "address1":  getWidget.customDefaultBillingAddress().address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + getWidget.customDefaultBillingAddress().address2,
                                        "city": getWidget.customDefaultBillingAddress().city,
                                        "state": getWidget.customDefaultBillingAddress().state,
                                        "postalCode": getWidget.customDefaultBillingAddress().postalCode,
                                        "country": getWidget.customDefaultBillingAddress().country
                                    };
     }else{
     request = {
                    "address1":  getWidget.customDefaultBillingAddress().address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + getWidget.customDefaultBillingAddress().address2(),
                                        "city": getWidget.customDefaultBillingAddress().city,
                                        "state": getWidget.customDefaultBillingAddress().state,
                                        "postalCode": getWidget.customDefaultBillingAddress().postalCode,
                                        "country": getWidget.customDefaultBillingAddress().country
                                    };         
     }

}

                }else{
                     request = {
                    "address1":  getWidget.customDefaultBillingAddress().address1,
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + getWidget.customDefaultBillingAddress().address2,
                                        "city": getWidget.customDefaultBillingAddress().city,
                                        "state": getWidget.customDefaultBillingAddress().state,
                                        "postalCode": getWidget.customDefaultBillingAddress().postalCode,
                                        "country": getWidget.customDefaultBillingAddress().country
                                    };

                }


//karthick added for address validation check
    /*                    if ([null, undefined, ''].indexOf(request.address1()) == -1 &&
[null, undefined, ''].indexOf(request.city()) == -1 &&
[null, undefined, ''].indexOf(request.postalCode()) == -1 &&
[null, undefined, ''].indexOf(request.country()) == -1 &&
[null, undefined, ''].indexOf(request.state()) == -1) {*/

                                    var settings = {
                                        "url": "/ccstorex/custom/v1/addressValidation",
                                        "method": "POST",
                                        "data": JSON.stringify(request),
                                        "async": false,
                                        "contentType": "application/json"
                                    };
                                    var matched = false;
                               // }

                                    if (JSON.stringify(getWidget.addressValidationRequest) !== JSON.stringify(request)) {
                                        matched = true;
                                    } else {
                                        $('#main').removeClass('loadingIndicator');
                                        spinner.destroy();
                                    }
                                    console.log(matched)
                                    if (matched) {
                                        getWidget.addressValidationRequest = request;
                                        $.ajax(settings).done(function(response) {
                                            $('#main').removeClass('loadingIndicator');
                                            spinner.destroy();
                                            console.log("Response :: ", response);
                                            if (response) {
                                                if (response.validatedAddresses) {
                                                    console.log("Under valid ADDRESS");
                                                    if (response.hasOwnProperty('messages')) {
                                                        getWidget.addressvalidationMessage(response.messages[0].summary);
                                                        getWidget.validAddresses([]);
                                                        $('#CC-addressSuggestionMessagePane').show();
                                                    } else {
                                                        if (response.validatedAddresses.length > 0) {
                                                            //spinner.destroy();
                                                            console.log("Under valid ADDRESS LENGTH");
                                                            getWidget.addressvalidationMessage("");
                                                            getWidget.validAddresses(response.validatedAddresses);
                                                            $('#CC-addressSuggestionMessagePane').show();
                                                        }
                                                    }
                                                }
                                            }
                                        })
                                    } //end of checking two requests
                                    else {
                                        console.log("already have");

                                    }
                                }


                                return isAddressValid;
                                //		}
                            } else {
                                $('#main').removeClass('loadingIndicator');
                                spinner.destroy();
                            }
                        } else {
                            $('#main').removeClass('loadingIndicator');
                            spinner.destroy();
                        }
                    }
                }
                return true;
            },
            
            
            setDefaultAddressFromDynamicProperties: function() {
                var widget = this;
                /* widget.customDefaultShippingAddress = ko.computed(function() {
          var dynamicProperties=widget.user().dynamicProperties();
         
             for(var i=0;i<dynamicProperties.length;i++){
            if(dynamicProperties[i].id()=='default_shippingAddress_data'){
              var address=widget.getAddressFromDynamicProperty(dynamicProperties,'default_shippingAddress_data');
               return address;
               
            }
             }
        
       });
        widget.customDefaultBillingAddress = ko.computed(function() {
          var dynamicProperties=widget.user().dynamicProperties();
         
             for(var i=0;i<dynamicProperties.length;i++){
            if(dynamicProperties[i].id()=='default_billingAddress_data'){
              var address=widget.getAddressFromDynamicProperty(dynamicProperties,'default_billingAddress_data');
               return address;
              
            }
             }
        
       });*/

//			        widget.customDefaultBillingAddress(widget.user().dynamicProperties()[i].value())
                var dynamicProperties = widget.user().dynamicProperties();
                for (var i = 0; i < dynamicProperties.length; i++) {
                    
                    if (dynamicProperties[i].id() == "default_billingAddress_data") {
                        var defaultShippingAddress = dynamicProperties[i].value();
                        var replaced = defaultShippingAddress.replace(/=/g, '":"');
                        var replace = replaced.replace(/,/g, '", "');
                        var len = replace.length;
                        var x = replace.substring(0, len - 1) + '"' + replace.substring(len - 1);
                        var y = x.substring(0, 1) + '"' + x.substring(1, len + 1);
                        var a = JSON.parse(y);
                        var firstName = a[" firstName"];
                        var lastName = a[" lastName"];
                        var address1 = a[" address1"];
                        var address2 = a[" address2"];
                        var address3 = a[" address3"];
                        var alias = a[" alias"];
                        var addressLine_4 = a[" addressLine_4"];
                        var custom_email = a[" custom_email"];
                        var phoneNumber = a[" phoneNumber"];
                        var postalCode = a[" postalCode"];
                        var city = a[" city"];
                        var state = a[" selectedState"];
                        var addr = new Address('user-shipping-address', widget.ErrorMsg, widget, widget.billingCountries(), "US");
                        var mapping = {
                            'include': ["address1", "address2", "address3", "addressLine_4", "alias", "city", "companyName", "country", "countryName",
                                "county", "faxNumber", "firstName", "isDefaultAddress", "jobTitle", "lastName", "middleName",
                                "phoneNumber", "postalCode", "prefix", "suffix", "regionName", "state", "stateList",
                                "selectedState", "selectedCountry", "isDefaultBillingAddress", "isDefaultShippingAddress", "isDefaultAddress", "toJSON", "state_ISOCode", "type",
                                "invalidTracker", "'saveToAccount", "saveAddressTo", "dynamicPropertyMetaInfo"
                            ]
                        };

                        var newAddress = ko.mapping.toJS(addr, mapping);
                        newAddress['address1'] = address1;
                        newAddress['custom_email'] = custom_email;
                        newAddress['firstName'] = firstName;
                        newAddress['lastName'] = lastName;
                        newAddress['address2'] = address2;
                        newAddress['address3'] = address3;
                        newAddress['alias'] = alias;
                        newAddress['phoneNumber'] = phoneNumber;
                        newAddress['custom_email'] = custom_email;
                        newAddress['postalCode'] = postalCode;
                        if (addressLine_4 != null) {
                            newAddress['addressLine_4'] = addressLine_4;
                        }

                        newAddress['city'] = city;
                        newAddress['state'] = state;


                        var newAddressJSON = ko.mapping.toJS(newAddress, mapping);
                        var custAddress = ko.mapping.fromJS(newAddressJSON);

                        /*if(dynamicProperties[i].id()=='default_contactAddress_data'){
                            widget.customDefaultContactAddress(custAddress);
                        }*/

//widget.selectedBillingAddress2Type(custAddress.address2())

                            if([null,undefined,""].indexOf(custAddress.address2()) == -1){
                      if((custAddress.address2().toLowerCase().indexOf("suite") !== -1)){
                          
                   widget.selectedBillingAddress2Type(custAddress.address2().substring(0,5));    
                   custAddress.address2(custAddress.address2().substring(5,custAddress.address2().length));
                   
                   
                }else  if((custAddress.address2().toLowerCase().indexOf("apartment") !== -1)){
                    
                   widget.selectedBillingAddress2Type(custAddress.address2().substring(0,9));    
                  custAddress.address2(custAddress.address2().substring(9,custAddress.address2().length));

                   
                }else  if((custAddress.address2().toLowerCase().indexOf("building") !== -1)){
                    
                    
                   widget.selectedBillingAddress2Type(custAddress.address2().substring(0,8));    
                   custAddress.address2(custAddress.address2().substring(8,custAddress.address2().length));

                  
                }else  if((custAddress.address2().toLowerCase().indexOf("p.o.") !== -1)){
                    

                   
                   widget.selectedBillingAddress2Type(custAddress.address2().substring(0,8));    
                   custAddress.address2(custAddress.address2().substring(8,custAddress.address2().length));
                   
                }else{

                   widget.selectedBillingAddress2Type("");
                    custAddress.address2(custAddress.address2());        
                }
        }else{

                custAddress.address2("");
                   widget.selectedBillingAddress2Type("");
        }




 var request = {
                    "address1": custAddress.address1(),
                                        "address2": getWidget.selectedBillingAddress2Type() + " " + custAddress.address2(),
                                        "city": custAddress.city(),
                                        "state": custAddress.state(),
                                        "postalCode": custAddress.postalCode(),
                                        "country": custAddress.country()
                                    };
widget.addressValidationRequest=request;

                            widget.customDefaultBillingAddress(custAddress);
                            
                            
                            


                    }
                }
            },
            
            
            closesuggesionmodal: function() {
                $('#CC-addressSuggestionMessagePane').hide();

                return true;
            },
            backToMyaccount: function() {
                var widget = this;
                
                if($('#noCreditCards').css('display') == 'block'){
                    navigation.goTo("/Myaccount")
                }
                if($('#noCreditCards').css('display') == 'none' && widget.allCreditCards().length  == 0){
                    $('#noCreditCards').css('display', 'block');
                    // $('#creditCardList').css('display', 'none');
                    $('#addCreditCards').css('display', 'none');
                }else{
                    //  $('#noCreditCards').css('display', 'block');
                    $('#creditCardList').css('display', 'block');
                    $('#addCreditCards').css('display', 'none');
                }
                
                
            },



        }




    });