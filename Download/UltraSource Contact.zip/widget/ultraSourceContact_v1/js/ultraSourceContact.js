/**
 * @fileoverview Shopping Cart Summary Widget.
 * 
 */
define(
    //-------------------------------------------------------------------
    // DEPENDENCIES
    //-------------------------------------------------------------------
    ['knockout', 'pubsub','navigation', 'viewModels/giftProductListingViewModel', 'ccConstants', 'notifier',
        'CCi18n', 'jquery', 'viewModels/integrationViewModel', 'viewModels/inventoryViewModel','spinner','viewModels/address','ccRestClient', '//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js'
    ],

    //-------------------------------------------------------------------
    // MODULE DEFINITION
    //-------------------------------------------------------------------
    function(ko, pubsub,navigation, giftProductListingViewModel, CCConstants, notifier, CCi18n, $, integrationViewModel, Inventory,spinner,Address,ccRestClient) {

        "use strict";
        var getWidget;


        return {

            // This will hold the data displayed in gift selection modal

            isEmptyName: ko.observable(false),
            companyName:ko.observable(),
            			primaryBusinessArray: ko.observableArray([]),
			secondaryBusinessArray: ko.observableArray([]),
						employeeArray: ko.observableArray([]),
									revenueArray: ko.observableArray([]),
						
									noOfEmployees: ko.observable(),
           userName : ko.observable(""),
            customerId : ko.observable(""),
            name : ko.observable(""),
            email : ko.observable(""),
            homeNumber : ko.observable(""),
            password : ko.observable("**********"),
            currentPassword:ko.observable(),
            newPassword:ko.observable(),
            confirmNewPassword:ko.observable(),
            mobileNumber:ko.observable(),
            preFix:ko.observable(),
            firstName:ko.observable(),
            lastName:ko.observable(),
            faxNumber:ko.observable(),
            4: ko.observable(),
            roleSelected: ko.observable(),
            receiveMails: ko.observable(),
            receiveEmails: ko.observable(),
            receiveTexts: ko.observable(),
            selectedTitle: ko.observable(),
			titleArray: ko.observableArray([]),
			rolesArray: ko.observableArray([]),
			
			annualRevenue: ko.observable(),
			secondaryBusiness: ko.observable(),
			primaryBusiness: ko.observable(),
            emptyNameErrorMessage: ko.observable("Please enter name"),

            onLoad: function(widget) {
                var self = this;
                getWidget = widget;
    				widget.primaryBusiness.subscribe(function (newValue) {
					widget.secondaryBusinessArray([]);
					if (newValue === "Meat & Meat Products" || newValue === "Poultry & Poultry Products") {
						widget.secondaryBusinessArray.push('Harvest/Slaughter', 'Further Processing', 'Custom Slaughter/Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Fish & Fish Products" || newValue === "Bread & Bakery" || newValue === "Snacks - Candy/Nut/Other" || newValue === "Restaurants & Country Clubs" || newValue === "Grocery Store" || newValue === "Pet Food") {
						widget.secondaryBusinessArray.push('Harvest/Slaughter', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Dairy & Dairy Products") {
						widget.secondaryBusinessArray.push('Production', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Farms - General/Crop" || newValue === "Fruits & Vegetables") {
						widget.secondaryBusinessArray.push('Production', 'Harvest', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Schools - Elementary/Secondary/College" || newValue === "Medical - Offices/Hospitals/Manufacturers" || newValue === "Correctional Institutions" || newValue === "Other") {
						widget.secondaryBusinessArray([]);

					}
				});
				self.titleArray.push('', 'Mr.', 'Mrs.', 'Ms.','Miss.','Dr.');
				self.rolesArray.push('Engineering', 'Finance/Legal', 'Maintenance', 'Management', 'OHSE', 'Operations/Production', 'Other', 'Purchasing', 'Sales');
				
				self.employeeArray.push(' 1 - 10', ' 11 - 25', ' 26 - 50', ' 51 - 100', ' 51 - 100', ' 151 - 200', ' 251 - 500', ' 500+');
				self.revenueArray.push('$0-$500k', '$500k-$1M', '$1M-$2.5M', '$2.5M-$5M', '$5M-$10M', '$10M-$25M', '$25M-$50M', '$50M+');
				self.primaryBusinessArray.push('Meat & Meat Products', 'Poultry & Poultry Products', 'Fish & Fish Products', 'Dairy & Dairy Products', 'Farms - General/Crop', 'Fruits & Vegetables', 'Bread & Bakery', 'Snacks - Candy/Nut/Other', 'Restaurants & Country Clubs', 'Grocery Store', 'Pet Food', 'Schools - Elementary/Secondary/College', 'Medical - Offices/Hospitals/Manufacturers', 'Correctional Institutions', 'Other');
/*
if(getWidget.user()){
if ([null, undefined, ''].indexOf(getWidget.user().parentOrganization) !== -1) {  //individual user
    
$('#myaccount-preview-individual').show();

}
else{   //business or company

if(getWidget.user().parentOrganization.org_type){

if(getWidget.user().parentOrganization.org_type()==="Business"){    //business user
    $('#myaccount-preview-business').show();

    document.getElementById("myaccount-preview-business").style.display = "block";
    
}
else if(getWidget.user().parentOrganization.org_type()==="Company"){    //company user
    $('#myaccount-preview-company').show();
}
else{
}
}else{

$('#myaccount-preview-individual').hide();

$('#myaccount-preview-business').hide();


$('#myaccount-preview-company').hide();

$('#myaccount-manage-info-business').hide();

$('#myaccount-manage-info-individual').hide();

$('#myaccount-manage-info-company').hide();

$('#myaccount-manage-company-info').hide();
}
}  //end of business or company
    
}   //end of checking having user
*/

            },
        
			validatingData: function (data, event,user) {
				var self = data;
				  var label;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        console.log("data is null");	
    				
				        if(user==="business"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else{}
				        



				    }else{
				        console.log("data is not null");
				        
            				  
				        if(user==="business"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else{}
				    }
				}
				return true;
        			},
        			
        			validatingPassword: function (data, event,user) {
        			    
	    				var self = data;
	    				 var label;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        console.log("data is null");	
    				   
				        if(user==="business"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else{}
				        
				    }else{
				        console.log("data is not null");
				        if(user==="business"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else{}
				        
				    }
				}
				return true;
				
        			    
        			},
        			
        			validatePassword: function (data, event) {
				if (event.target.value === "" || event.target.value === null) {
//					getWidget.isInvalidHomePhoneNumber1(true);
//					getWidget.isInvalidHomePhoneNumber(false);
				} else {

				    
				    
				}
        			},
        				validateHomePhoneNumber: function (data, event,user) {
        				    				    var label;
				if (event.target.value === "" || event.target.value === null) {
				        if(user==="business"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else{}
				        
				} else {

					var number = ("" + event.target.value).replace(/\D/g, '');
					var token = number.match(/^(\d{3})(\d{3})(\d{4})$/);

					if (token !== null) {     //correct mobile number



				        if(user==="business"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        }else{}					
					    
					    
					    
					    
					    
					} else {    //invalid mobile number



				        if(user==="business"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else if(user==="company"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        
				        }else if(user==="individual"){
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        }else{}

					}
				}
			},
			
			
			 redirectToMyAccount: function(){
			     
			     navigation.goTo('/myaccount');
			     
                // console.log("RFQ PAGE");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/myaccount');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
			
			
       /* redirectToMyAccount: function(){
            if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                   navigation.goTo('/myaccount');
                }else{
                    $('#LoginModal').modal('show');
                }
                
            

            },*/
            
            
            redirectTocontactform: function(){
                  // navigation.goTo('/contactform');
                   window.location.href = '/contactform'
            },
            
             redirectTocontactus: function(){
                    navigation.goTo('/contactus');
            },
            
             redirectTohome: function(){
                    navigation.goTo('/home');
            },
            
            
           
        redirectToRegistration: function(){
                    navigation.goTo('/registration');
            },
        redirectToLogin: function(){
                    navigation.goTo('/login');
            },
          redirectToFaq: function(){
                    navigation.goTo('/faqs');
            },        
                  redirectToRegister: function(){
                    navigation.goTo('/registration');
            },
            
           
          redirectToAddresses: function(){
              
              navigation.goTo('/addressBook');
               
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/addressBook');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
            
          redirectToOrderHistory: function(){
              
              navigation.goTo('/orderhistory');
          
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/orderhistory');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
                      
            redirectToOrderStatus: function(){
                
                navigation.goTo('/recentOrders');
                
                // console.log("RFQ PAGE");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/recentOrders');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
                      
            redirectToTrackingInfo: function(){
                
                navigation.goTo('/faqs#shipping-questions');
                
                // console.log("RFQ PAGE");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/faqs#shipping-questions');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
            
            redirectToProfile: function(){
                      
                navigation.goTo('/profile');
                
                // console.log("RFQ PAGE");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/profile');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
            },
                  
            redirectToResetPassword: function(){
                
                navigation.goTo('/profile');

                //   console.log("RFQ PAGE");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/profile');
                // }else{
                //     $('#LoginModal').modal('show');
                //     console.log("false logged out");
                // }
                
            },
            

    
            redirectToRfq: function(){
                console.log("RFQ PAGE");
                
                navigation.goTo('/equipment_rfq');
                 
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     navigation.goTo('/equipment_rfq');
                // }else{
                //     $('#myModal').modal('show');
                //     console.log("false logged out");
                // }
                
                

            },
            
            
            redirectToeqSpecialist: function(){
                
                window.location.href = '/eqSpecialist';
                
                // console.log("");
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                //     window.location.href = '/eqSpecialist';
                //     //navigation.goTo('/eqSpecialist');
                // }else{
                //     $('#myModal').modal('show');
                //     console.log("false logged out");
                // }
                
                

            },
            
            
             redirectsupplieseqSpecialist: function(){
                 
                 navigation.goTo('/suppliesspecialist');
                 
                //   if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     console.log("false logged in");
                // navigation.goTo('/suppliesspecialist');
                //   }
                //   else{
                //     $('#myModal').modal('show');
                //     console.log("false logged out");
                // }
                  
            },
            
            
            
            
            
            redirectToParts: function() {
                
                navigation.goTo('/contactparts');
                
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     navigation.goTo('/contactparts');
                // }else{
                //     $('#LoginModal').modal('show');
                // }
            },
            redirectToService: function(){
                
                navigation.goTo('/contactservice');
                
                // if(getWidget.user().loggedIn()||getWidget.user().isUserSessionExpired()){
                //     navigation.goTo('/contactservice');
                // }else{
                //     $('#LoginModal').modal('show');
                // }
//   navigation.goTo('/login');
            },


        };
    }
);