/**
 * @fileoverview Checkout Address Book Widget.
 */
/*global $ */
/*global define */
define(

  //-------------------------------------------------------------------
  // DEPENDENCIES
  //-------------------------------------------------------------------
  ['knockout', 'viewModels/address', 'ccConstants', 'pubsub',
    'koValidate', 'notifier', 'ccKoValidateRules', 'storeKoExtensions',
    'spinner', 'navigation', 'storageApi', 'CCi18n',
    'viewModels/shippingMethodItemViewModel', 'ccRestClient', 'viewModels/inventoryViewModel','viewModels/delegatedAdminContacts',
    'pageLayout/shippingmethods'
  ],

  //-------------------------------------------------------------------
  // MODULE DEFINITION
  //-------------------------------------------------------------------

  function(ko, Address, CCConstants, pubsub, koValidate, notifier,
    rules, storeKoExtensions, spinner, navigation, storageApi, CCi18n,
    ShippingMethodItemViewModel, ccRestClient, Inventory, DelegatedAdminContacts, ShippingMethodsViewModel) {

    "use strict";
    var orgId = "orgId";
    var getWidget;

    return {
          addressExisted: ko.observable(false),
          sampleData: ko.observable(''),
   allAddressesCheck: ko.observableArray([]),
      newShippingAddress: ko.observable(),
	  accountNumber: ko.observable(''),      
	  collect: ko.observable('off'),
	  shipComplete: ko.observable(''),
	  estimatedDate: ko.observable(''),
	  selectedCarrier: ko.observable(''),
	carriersArrayId:ko.observableArray([]),  
	carriersArray:ko.observableArray([]),
	  collectEnables: ko.observable(true),
      // Switch between view and 'edit' views
      isUsingSavedAddress: ko.observable(false),
      addressSetAfterWebCheckout: ko.observable(false),
      addressSetAfterOrderLoad: ko.observable(false),
      shippingAddressBook: ko.observableArray().extend({ deferred: true }),
      currentShippingGroupShippingAddress:{},
      currentShippingGroupShippingMethod: [],
      shippingGroupForAddressBook: "",
      selectedAddress: ko.observable(),
      defaultBillingAddress: ko.observable(),
      shippingOptions:  ko.observableArray(),
      selectedShippingAddressType: ko.observable(),
      stores : ko.observableArray(),
      validAddresses: ko.observableArray([]),
      addressvalidationMessage: ko.observable(),
      shippingMethodsNewlyLoaded: ko.observable(true),
      globalInventoryStatus : ko.observable(),
      storeSearchText: ko.observable(),
      selectedShippingAddress2Type: ko.observable(),
       fetchSize: ko.observable(40),
      reloadShippingMethods:      ko.observable(false),
      skipShipMethodNotification: ko.observable(false),
      skipSpinner                  : ko.observable(false),
      selectedShippingValue:      ko.observable(),
      selectedShippingOption:     ko.observable(),
      selectedShippingCost:       ko.observable(0),
      collectSelectedArray : ko.observableArray([]),
      //selectedShipping:          ko.observable(""),
      shippingContact: ko.observable(),
      billingContact: ko.observable(),
      mainContact: ko.observable(),
      selectedShippingName:       ko.observable(),
       isCartPriceUpdated:         ko.observable(false),
      removeAdjacentShippingAmount : ko.observable(false),
      shippingMethodsLoaded        : ko.observable(false),
      addressArray:                 ko.observableArray([]),
      addressTypeArray:             ko.observableArray([]),
      // -1 -> Some thing went wrong in either fetching locatins / stock status of a sku.
      // -2 -> No Stores found for given string.
      // 0  -> Everything went well. Got stock status of given sku across requested locatins.
      storeLookupStatus : ko.observable(0),
      callInProgress: {},
      previousShippingAddress: {},
      useAsBillingAddress: ko.observable(false),

      //B2B props
      totalInheritedAddresses: ko.observable(0),
      totalProfileAddresses: ko.observable(0),
      totalAccountAddresses: ko.observable(0),
      showLoadMore: ko.observable(false),
      loadMoreProfileAddresses: ko.observable(false),
      loadMoreAccountAddresses: ko.observable(false),
      organizationAddressBook: ko.observableArray(),
      profileAddressBook: ko.observableArray(),
      inheritedAddressBook: ko.observableArray(),
      accountAddressBook: ko.observableArray(),
      selectedBillingAddressId: ko.observable(),
      selectedShippingAddressId: ko.observable(),
      defaultShippingAddressType: ko.observable(),
      hasDefaultShippingAddress: ko.observable(false),
      offset: ko.observable(0),
      limit: ko.observable(4),
      userIsAccountAddressManager: ko.observable(false),
      userIsProfileAddressManager: ko.observable(false),
      editShippingAddress: ko.observable(false),
      editBillingAddress:ko.observable(false),
      addShippingAddressTo: ko.observable(null),
      addBillingAddressTo: ko.observable(null),
      shippingAddressBackUp: null,
      profileOffset: ko.observable(0),
      accountOffset: ko.observable(0),
      elementIdForModal: null,
      dataForModal: null,
      currentShippingAddressSelection: ko.observable(CCConstants.ACCOUNT_ADDRESSES_TYPE),



      // Spinner resources
      shippingAddressIndicator: '#CC-Checkout-Shipping-Methods',
      shippingAddressIndicatorOptions: {
        parent: '#CC-Checkout-Shipping-Methods',
        posTop: '50px',
        posLeft: '30%'
      },
      opDynamicProperty: ko.observable(),
      destroySpinner: function() {
        var widget = this;
        $(widget.shippingAddressIndicator).removeClass('loadingIndicator');
        spinner.destroyWithoutDelay(widget.shippingAddressIndicator);
      },

      /*
      * In case when cart.associateShippingGroupsToItems() is called it associates the shippingGroup items which has detailedItemPriceInfo as object.
      * But in other scenario the detailedItemPriceInfo is set as observableArray. So when detailedItemPriceInfo is used in template we are not sure detailedItemPriceInfo to be an object
      * or an observableArray, so to get the value we have this method which would return the value both from the object as well as the observableArray.
      */
      getDetailedPrice: function(pData) {
        var detailedPrice = "";
        if(ko.isObservable(pData.detailedItemPriceInfo)) {
          if(pData.detailedItemPriceInfo().length){
            detailedPrice =  pData.detailedItemPriceInfo()[0].detailedUnitPrice;
          }
        }else {
          if(pData.detailedItemPriceInfo.length){
            detailedPrice =  pData.detailedItemPriceInfo[0].detailedUnitPrice;
          }
        }
        return detailedPrice;
      },

        yellowFadeIn: function(element, index, data) {
            $(element).filter("select")
                      .animate({ backgroundColor: 'yellow' }, 200)
                      .animate({ backgroundColor: 'white' }, 800);
        },
      /**
       * Repopulate this form with up to date info from the User view model for B2C users.
       */
      reloadAddressInfoForB2CUser: function () {

        var widget = this;

        if (widget.shippingCountriesPriceListGroup().length == 0) {
          widget.destroySpinner();
          $.Topic(pubsub.topicNames.NO_SHIPPING_METHODS).publish();
        }

        widget.isUsingSavedAddress(false);

        // Should always use registered shopper's saved shipping address book if set
        var eventToFire = pubsub.topicNames.VERIFY_SHIPPING_METHODS;
        if (widget.user().loggedIn() === true) {
         if(widget.user().updatedShippingAddressBook && widget.user().updatedShippingAddressBook.length > 0) {
          var shippingAddresses = [];
          var shippingAddressesAll = [];
          for (var k = 0; k < widget.user().updatedShippingAddressBook.length; k++) {
            var shippingAddress = new Address('user-saved-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
            shippingAddress.countriesList(widget.shippingCountriesPriceListGroup());
            shippingAddress.copyFrom(widget.user().updatedShippingAddressBook[k], widget.shippingCountriesPriceListGroup());
            // Save shipping address JS object to Address object.
            shippingAddress.resetModified();

            if (shippingAddress.isValid()) {
              shippingAddresses.push(shippingAddress);
            }
            if (shippingAddress.isDefaultAddress() && !widget.addressSetAfterWebCheckout() &&
                !widget.addressSetAfterOrderLoad() && shippingAddress.isValid()) {
              widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
            }
            widget.addressSetAfterWebCheckout(false);
            widget.addressSetAfterOrderLoad(false);

            //Preserve existing logic to save all the addresses to user().shippingAddressBook, irrespective of their validness
            var shippingAddressValidOrInValid = new Address('user-saved-shipping-address', widget.ErrorMsg, widget, widget.shippingCountries(), widget.defaultShippingCountry());
            shippingAddressValidOrInValid.countriesList(widget.shippingCountries());
            shippingAddressValidOrInValid.copyFrom(widget.user().updatedShippingAddressBook[k], widget.shippingCountries());
            shippingAddressesAll.push(shippingAddressValidOrInValid);
          }
          widget.shippingAddressBook(shippingAddresses);
          widget.user().shippingAddressBook(shippingAddressesAll);
          widget.user().resetShippingAddressBookModified();

          eventToFire = pubsub.topicNames.POPULATE_SHIPPING_METHODS;
          if (!widget.order().isPaypalVerified() && shippingAddresses.length > 0) {
            widget.isUsingSavedAddress(true);
          }
        } else {
          widget.shippingAddressBook([]);
          widget.user().shippingAddressBook([]);
        }
        }

      },

      /**
       * Repopulate this form with up to date info from the User view model for B2B users.
       */

      reloadAddressInfoForB2BUser: function () {

        var widget = this;

        if (widget.shippingCountriesPriceListGroup().length == 0) {
          widget.destroySpinner();
          $.Topic(pubsub.topicNames.NO_SHIPPING_METHODS).publish();
        }
        if (widget.user().loggedIn() === true) {
         var organizationAddresses = [];
         if(widget.user().organizationAddressBook && widget.user().organizationAddressBook.length > 0) {
          widget.selectedBillingAddressId('');
          widget.selectedShippingAddressId('');
          for (var k = 0; k < widget.user().organizationAddressBook.length; k++) {
            var organizationAddress = new Address('user-saved-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
            organizationAddress.countriesList(widget.shippingCountriesPriceListGroup());
            organizationAddress.copyFrom(widget.user().organizationAddressBook[k], widget.shippingCountriesPriceListGroup());
            // Save shipping address JS object to Address object.
            organizationAddress.resetModified();

            organizationAddresses.push(organizationAddress);
            if ((widget.user().contactShippingAddress && widget.user().contactShippingAddress.repositoryId ===  widget.user().organizationAddressBook[k].repositoryId)
                && !widget.addressSetAfterWebCheckout() && !widget.addressSetAfterOrderLoad()) {
              widget.order().shippingAddress().copyFrom(organizationAddress.toJSON(), widget.shippingCountriesPriceListGroup());
              widget.selectedShippingAddressId(widget.user().organizationAddressBook[k].repositoryId);
              widget.hasDefaultShippingAddress(true);
            }
            widget.addressSetAfterWebCheckout(false);
            widget.addressSetAfterOrderLoad(false);
           }
         }
          widget.organizationAddressBook(organizationAddresses);
          var index = 0;
          //reset all offsets so the addresses are loaded from 0.
          widget.offset(0);
          widget.profileOffset(0);
          widget.accountOffset(0);
          //clear all the address lists before reloading them.
          widget.inheritedAddressBook.removeAll();
          widget.profileAddressBook.removeAll();
          widget.accountAddressBook.removeAll();
          //methods to load address lists
          widget.loadAccountAddresses();
          widget.loadInheritedAddressess();
          widget.loadProfileAddresses();
        }
     },

      initResourceDependents: function() {
        var widget = this;
        // Message to be displayed in the Message Panel if an error occurs
        widget.ErrorMsg = widget.translate('checkoutErrorMsg');

        widget.newShippingAddress(new Address('new-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry()));

        widget.order().billingAddress.extend({
          propertyWatch: widget.order().billingAddress()
        });
        widget.order().shippingAddress.extend({
          propertyWatch: widget.order().shippingAddress()
        });

        widget.order().billingAddress(new Address('checkout-billing-address', widget.ErrorMsg, widget, widget.billingCountries(), widget.defaultBillingCountry()));
        widget.order().shippingAddress(new Address('checkout-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry()));
        /**
         * @function
         * @name isValid
         * Determine whether or not the current widget object is valid
         * based on the validity of its component parts. This will not
         * cause error messages to be displayed for any observable values
         * that are unchanged and have never received focus on the
         * related form field(s).
         * @return boolean result of validity test
         */
        widget.isValid = function() {
          this.order().errorFlag = false;
          widget.order().validateShippingGroupRelationships();
          return !this.order().errorFlag;
        };

        /**
         * @function
         * @name validateNow
         * Force all relevant member observables to perform their
         * validation now & display the errors (if any)
         */
        widget.validateNow = function() {
          return (widget.isValid());
        };

        /**
         * Callback function for use in widget stacks.
         * Triggers internal widget validation.
         * @return true if we think we are OK, false o/w.
         */
        widget.validate = function() {
          return widget.validateNow();
        };

        if(widget.user().isB2BUser()) {
          widget.initResourceDependentsForB2BUser();
        }
      },

      /**
       * Set the dependencies for the widget.
       */
      initResourceDependentsForB2BUser: function() {
        var widget = this;
         /**
          * method to load inherited addresses of an account
          */
           widget.loadInheritedAddressess = function () {
           //Fetch Inherited Addresses
             var url = CCConstants.END_POINT_LIST_ADDRESSES;
             var input = {};
             input[orgId] = widget.user().currentOrganization().repositoryId;
               input[CCConstants.INCLUDE] = CCConstants.END_POINT_INHERITED_ADDRESSES;
               input[CCConstants.OFFSET] = widget.offset();
               input[CCConstants.LIMIT] = widget.limit();
               ccRestClient.request(url,input,
                function(data) {        //Success Call back
                    if(data.items && data.items.length>0){
                      widget.createAddresses('inherited-addresses', data, widget.inheritedAddressBook);
                      widget.offset(data.offset + data.items.length);
                      widget.totalInheritedAddresses(data.total);
                      if (widget.totalInheritedAddresses() > widget.offset())
                        widget.showLoadMore(true);
                      else{
                         widget.showLoadMore(false);
                         widget.offset(0);
                      }
                    }
             },function(pError){      // Error Call back
             console.log("banth")
                  notifier.sendError(widget.WIDGET_ID, pError.message, true);
              });
            };

          /**
           * method to load profile addresses of the logged in user
           */
          widget.loadProfileAddresses = function () {
             //Fetch Inherited Addresses
            var url = CCConstants.END_POINT_LIST_PROFILE_ADDRESSES;
            var input = {};
            input[CCConstants.OFFSET] = widget.profileOffset();
            input[CCConstants.LIMIT] = widget.limit();
            ccRestClient.request(url,input,
              function(data) {        //Success Call back
                if(data.items && data.items.length>0){
                  widget.createAddresses('profile-addresses', data, widget.profileAddressBook);
                 widget.profileOffset(data.offset + data.items.length);
                 widget.totalProfileAddresses(data.total);
                 if (widget.totalProfileAddresses() > widget.profileOffset())
                   widget.loadMoreProfileAddresses(true);
                 else{
                   widget.loadMoreProfileAddresses(false);
                   widget.profileOffset(0);
                  }
                }

                },function(pError){ 
                    console.log("banth")// Error Call back
                  notifier.sendError(widget.WIDGET_ID, pError.message, true);
               });
            };
        
            /**
             * method to load local addresses of an account
             */
            widget.loadAccountAddresses = function () {
              //Fetch Inherited Addresses
               var input={};
              var url = CCConstants.END_POINT_LIST_ADDRESSES;
              input[orgId] = widget.user().currentOrganization().repositoryId;
              input[CCConstants.OFFSET] = widget.accountOffset();
              input[CCConstants.LIMIT] = widget.limit();
              //Fetch Account Addresses
              ccRestClient.request(url,input,
                function(data) {        //Success Call back
                  if(data.items && data.items.length>0){
                    widget.createAddresses('account-addresses', data, widget.accountAddressBook);
                    widget.accountOffset(data.offset + data.items.length);
                    widget.totalAccountAddresses(data.total);
                    if (widget.totalAccountAddresses() > widget.accountOffset()){
                      widget.loadMoreAccountAddresses(true);
                    }else{
                      widget.loadMoreAccountAddresses(false);
                      widget.accountOffset(0);
                    }
                    if(data.derivedShippingAddressType !== "null" ){
                       widget.defaultShippingAddressType(data.derivedShippingAddressType);
                     }
                  }
                },function(pError){    // Error Call back
                console.log("banth")
                    notifier.sendError(widget.WIDGET_ID, pError.message, true);
               });
             };


            /**
             * Custom method to create addresses from the data in server response and adding to the
             * list provided in parameters to the method.
             */
            widget.createAddresses = function(id, data, addresses){
              for (var i=0; i< data.items.length; i++){
                 var address = new Address(id,widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
                 address.copyFrom(data.items[i].address, widget.shippingCountriesPriceListGroup());
                 address[CCConstants.PARAMETERS_TYPE](data.items[i].addressType);
                 address.resetModified();
                 addresses.push(address);
               }
              return addresses;
            };
       },

      /**
       * Called before the widget appears every time.
       */
      beforeAppear: function (page) {
        var widget = this;
        if(!widget.user().loggedIn())
        {
            navigation.goTo('/login');
        }
        
          var status1;
           var status;
                   for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "account_number"){
                                   status1=widget.cart().dynamicProperties()[i].value() 
                                }
                              if(widget.cart().dynamicProperties()[i].id() == "ship_complete"){
                                   status=widget.cart().dynamicProperties()[i].value() 
                                }
                    }
                if([null,undefined,""].indexOf(status1) == -1){
                    widget.accountNumber(status1)                
                }
                if([null,undefined,""].indexOf(status) == -1){
                   widget.shipComplete(status);                   
                }
      
 
    
        widget.mainContact.subscribe(function(newValue){
            if([null,undefined,''].indexOf(newValue) == -1){
        widget.order().shippingAddress().x_main_contact(newValue.repositoryId)
            }
        });
        widget.billingContact.subscribe(function(newValue){
            if([null,undefined,''].indexOf(newValue) == -1){
        widget.order().shippingAddress().x_billing_contact(newValue.repositoryId)
            }
        }); 
        widget.shippingContact.subscribe(function(newValue){
            if([null,undefined,''].indexOf(newValue) == -1){
        widget.order().shippingAddress().x_shipping_contact(newValue.repositoryId)
            }
        });        
        
                widget.addressExisted.subscribe(function(newValue){
    if(newValue){
        $('#CC-companyAddressAlreadyRegistered-Modal').show();
    }else{
        $('#CC-companyAddressAlreadyRegistered-Modal').hide();
    }
})


        //widget.cart().isSplitShipping(true);
        widget.listingViewModel().clearOnLoad = true;
        widget.listingViewModel().orgValue = widget.user().currentOrganization() ? widget.user().currentOrganization().repositoryId : null;
        widget.listingViewModel().load(1, 1);
        console.log("Items ::: ",widget.listingViewModel().data())
        widget.userIsAccountAddressManager(widget.user().isAccountAddressManager() || widget.user().isDelegatedAdmin());
        widget.userIsProfileAddressManager(widget.user().isProfileAddressManager());
        if (widget.user().isB2BUser()) {
          widget.reloadAddressInfoForB2BUser();
        } else if (!widget.user().isB2BUser()) {
          widget.reloadAddressInfoForB2CUser();
        }
        if (widget.order().isPaypalVerified()) {
          // On successful return from paypal site
          widget.createSpinner();
          // Fetches the data to populate the checkout widgets
          widget.order().getOrder();
        } else if (!(widget.cart().currentOrderState() == 'PENDING_PAYMENT' || widget.cart().currentOrderState() == 'PENDING_PAYMENT_TEMPLATE')) {
          if (widget.cart().hasShippingInformation()) {
            widget.createSpinner();
            var sgrs = widget.cart().createShippingGroups();
            var inStore = true;
            /**for (var i=0; i<sgrs.length; i++) {
              if (sgrs[i].type != CCConstants.INSTORE_PICKUP) {
                inStore = false;
                break;
              }
            }
            if (inStore) {
              widget.priceSplitShippingCartForCheckout();
            }**/
          }
        }
        /**ko.utils.arrayForEach(widget.cart().items(), function(item) {
          ko.utils.arrayForEach(item.shippingGroupRelationships(), function(sgr) {
            if (sgr.isPickupInStore()) {
              sgr.populateUserDetails(widget.user());
            }
          })
        });**/
        if(widget.shippingOptions().length >0)
        {
            for(var i=0;i<widget.shippingOptions().length;i++)
            {
                if(widget.shippingOptions()[i].displayName === localStorage.getItem('shippingMethod-name'))
                {
                  var radios = $("#shippingOptions input:radio");
                      for(var i = 0; i < radios.length; i++){
                        if(radios[i].parentElement.firstElementChild.innerText ==  localStorage.getItem('shippingMethod-name')){
                          radios[i].checked = true;
                            widget.selectedShippingValue(widget.shippingOptions()[i].repositoryId);
                        }
                      }
                    
                }
            }
        }else{
            widget.displayShippingMethodsDropdown();
            
              setTimeout(function() {
                if(widget.user().isB2BUser()){   //b2b user
 if( widget.user().isDelegatedAdmin() ){
      if(widget.user().organizations()[0].shippingAddress.postalCode()  ){
           console.log('b2b admin ')
              for(var i=0;i<widget.addressBookArray().length;i++){
if(widget.addressBookArray()[i].repositoryId == widget.user().organizations()[0].shippingAddress.repositoryId() ){
    widget.order().shippingAddress(widget.addressBookArray()[i])
}
}        

//                     widget.shippingAddress().postalCode(widget.user().organizations()[0].shippingAddress.postalCode().slice(0, 5))
 //                     widget.displayShippingMethodsDropdown1(widget.shippingAddress())
                }
 }else{
      if(widget.user().contactShippingAddress ){
           console.log('b2b buyer ')
           for(var i=0;i<widget.addressBookArray().length;i++){
if(widget.addressBookArray()[i].repositoryId == widget.user().contactShippingAddress.repositoryId ){
    widget.order().shippingAddress(widget.addressBookArray()[i])
}
}
   //                  widget.shippingAddress().postalCode(widget.user().contactShippingAddress.postalCode.slice(0, 5))
    //                  widget.displayShippingMethodsDropdown1(widget.shippingAddress())
                }
 }
                }else{   //b2c user
                 if(widget.user().shippingAddress.postalCode()){
                      console.log('b2c  ')
                      
                                    for(var i=0;i<widget.addressBookArray().length;i++){
if(widget.addressBookArray()[i].repositoryId ==widget.user().shippingAddress.repositoryId() ){
    widget.order().shippingAddress(widget.addressBookArray()[i])
}
}  
                      
      //               widget.shippingAddress().postalCode(widget.user().shippingAddress.postalCode().slice(0, 5))
        //              widget.displayShippingMethodsDropdown1(widget.shippingAddress())
                }
                }
                }, 2000);
                
                
        }
        
       /* if(localStorage.getItem('shippingMethod-name') == "collect"){
         widget.collect("on");   
        }*/
        widget.selectedShipping();
        
        
widget.order().shippingAddress().repositoryId
        setTimeout(function(){ 
            
            for(var i=0;i<widget.delegatedAdminContactsListGrid().length;i++){
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_main_contact()){
                    widget.mainContact(widget.delegatedAdminContactsListGrid()[i])
                }
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_billing_contact()){
                    widget.billingContact(widget.delegatedAdminContactsListGrid()[i])
                }
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_shipping_contact()){
                    widget.shippingContact(widget.delegatedAdminContactsListGrid()[i])
                }

            }
            
            
            console.log(widget.delegatedAdminContactsListGrid())
            console.log(widget.order().shippingAddress().repositoryId)            
        }, 2000);

        
        
      },

      // end initResourceDependents
      resourcesLoaded: function(widget) {
        widget.initResourceDependents();
      },

      setExpandedFlag : function(element, data) {
        if (data.expanded()) {
          data.expanded(false);
        } else {
          data.expanded(true);
        }
      },
      	validateAddress: function (event) {
      	  try{
      	      
      	 
      	  
      	  
				if (event !== undefined) {
				     if (event.keyCode == 9) {
//					if ('click' === event.type  || 'change' === event.type || 'mouseout' === event.type || event.keyCode == 9) {
			 		var orderRefreshIndicatorOptions = {
											parent: '#addNewAddressModal',
											posTop: '20em',
											posLeft: '50%'
											}
											
						var address = getWidget.newShippingAddress();
						var isAddressValid = false;
						if ([null, undefined, ''].indexOf(address.address1()) == -1 &&
[null, undefined, ''].indexOf(address.city()) == -1 &&
[null, undefined, ''].indexOf(address.postalCode()) == -1 &&
[null, undefined, ''].indexOf(address.country()) == -1 &&
[null, undefined, ''].indexOf(address.state()) == -1) {
						    
						    
						    
							if (address.validateForShippingMethod()) {
							
								var data = {};
//                                            $('#addNewAddressModal .modal-content').addClass('loadingIndicator');
//											$('#addNewAddressModal .modal-content').css('position', 'relative');
//											spinner.create(orderRefreshIndicatorOptions);								
											if (address) {
									
							         data={
                                "address1": address.address1(),
                                "address2": getWidget.selectedShippingAddressType()+" "+address.address2(),
                                "city":address.city(),
                                "state":address.selectedState(),
                                "postalCode":address.postalCode(),
                                "country":address.selectedCountry()
                                 }
                                    var flag=getWidget.addressExisted();
                                     for(var i=0;i<getWidget.allAddressesCheck().length;i++){
            	if (JSON.stringify(getWidget.allAddressesCheck()[i]).toLowerCase().replaceAll(" ","") === JSON.stringify(data).toLowerCase().replaceAll(" ","")) {
            	  /*  if(!flag){
                    	    getWidget.addressExisted(true)
            	    }*/
            	      flag=true
                    	    	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
//                    	     $('#CC-companyAddressAlreadyRegistered-Modal').show();
                    	    break;
            	}else{
            	     flag=false;
  //          	     $('#CC-companyAddressAlreadyRegistered-Modal').hide();
//                      	    getWidget.addressExisted(false)
            	    
            	}
                }   //end of for loop
                
                  if(getWidget.addressExisted() !== flag ){
                    	    getWidget.addressExisted(flag)
            	              }
            	              
											
											
											
											
											
											
											
										}
										if(!getWidget.addressExisted()){
										var settings = {
											"url": "/ccstorex/custom/v1/addressValidation",
											"method": "POST",
											"data": JSON.stringify(data),
											"async": false,
											"contentType": "application/json"
										};
										
			            	if (JSON.stringify(getWidget.sampleData()).toLowerCase().replaceAll(" ","") !== JSON.stringify(data).toLowerCase().replaceAll(" ","")) {

getWidget.sampleData(data);

											$.ajax(settings).done(function (response) {
											$('#addNewAddressModal .modal-content').removeClass('loadingIndicator');
												spinner.destroy();
												console.log("Response :: ", response);
												if (response) {
													if (response.validatedAddresses) {
														console.log("Under valid ADDRESS");
														if (response.hasOwnProperty('messages')) {
															getWidget.addressvalidationMessage(response.messages[0].summary);
															getWidget.validAddresses([]);
																$('#main').removeClass('loadingIndicator');
												spinner.destroy();
															$('#CC-addressSuggestionMessagePane6').show();
														} else {
															if (response.validatedAddresses.length > 0) {
																//spinner.destroy();
																console.log("Under valid ADDRESS LENGTH");
																getWidget.addressvalidationMessage("");
																getWidget.validAddresses(response.validatedAddresses);
																	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
																$('#CC-addressSuggestionMessagePane6').show();
															}
														}
													}
												}
											})
											
							            	}
										
										

											
							}   //end of checking already exist or not
											
											
									}
									return true;
						//		}
							}else{
							    	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
							}
								return true;
						}
						else
						{
						    	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
						}
					}    
			
			$('#main').removeClass('loadingIndicator');
                                        spinner.destroy();	
                                        
                                        
      	  }catch(err){
      	      	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
      	  }
                                        
                                        
                                        
				return true;
			},     //end of validate address function
			
						closecompanyaddressexistmodal: function () {
				$('#CC-companyAddressAlreadyRegistered-Modal').hide();


				return true;
			},
			
			closesuggesionmodal: function () {
				$('#CC-addressSuggestionMessagePane6').hide();

				return true;
			},
			
			closeModal:function(){
			    	$('#addNewAddressModal').hide();
			    	
			    		$('#main').removeClass('loadingIndicator');
												spinner.destroy();

				return true;
			},
			
			validAddressFields: function (data, event) {
			    try{
			    
				var self = data;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            var label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";
    				        if(event.target.id === "CC-checkoutAddressBook-sstate")
    				        {
    				           $('.boxState').append('<style>.boxState:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>')
    				        }
    				        if(event.target.id === "CC-checkoutAddressBook-typeAddress")
    				        {
    				            $('.boxType').append('<style>.boxType:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    				        }
				        }
				    }
				    else
				    {
				        event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            var label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";
    				        if(event.target.id === "CC-checkoutAddressBook-sstate")
    				        {
    				           $('.boxState').append('<style>.boxState:before{border-right:1px solid #d3d3d3;border-top:1px solid #d3d3d3;border-bottom:1px solid #d3d3d3;}</style>')
    				        }
    				        if(event.target.id === "CC-checkoutAddressBook-typeAddress")
    				        {
    				            $('.boxType').append('<style>.boxType:before{border-right:1px solid #d3d3d3;border-top:1px solid #d3d3d3;border-bottom:1px solid #d3d3d3;}</style>');
    				        }
				        }
				    }
				}
			    }catch(err){
			        	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
			    }
				
				return true;
			},

	setSelectedAddress: function () {
				getWidget.closesuggesionmodal();
                    getWidget.createSpinner();
					getWidget.newShippingAddress().address1(getWidget.validAddresses()[0].line1);
					if (getWidget.validAddresses()[0].line2 !== "") {
						getWidget.newShippingAddress().address2(getWidget.validAddresses()[0].line2);
					}
					getWidget.newShippingAddress().postalCode(getWidget.validAddresses()[0].postalCode);
					getWidget.newShippingAddress().city(getWidget.validAddresses()[0].city);
					getWidget.newShippingAddress().country(getWidget.validAddresses()[0].country);
					getWidget.newShippingAddress().state(getWidget.validAddresses()[0].region);
					getWidget.newShippingAddress().selectedState(getWidget.validAddresses()[0].region);
					getWidget.addShippingAddress();
					
					
	      			         var data={
                                "address1": getWidget.validAddresses()[0].line1,
                                "address2": getWidget.selectedShippingAddressType()+" "+getWidget.newShippingAddress().address2(),
                                "city":getWidget.validAddresses()[0].city,
                                "state":getWidget.validAddresses()[0].region,
                                "postalCode":getWidget.validAddresses()[0].postalCode,
                                "country":getWidget.validAddresses()[0].country
                                 }

                        var flag=getWidget.addressExisted();
                                     for(var i=0;i<getWidget.allAddressesCheck().length;i++){
            	if (JSON.stringify(getWidget.allAddressesCheck()[i]).toLowerCase().replaceAll(" ","") === JSON.stringify(data).toLowerCase().replaceAll(" ","")) {
            	  /*  if(!flag){
                    	    getWidget.addressExisted(true)
            	    }*/
            	      flag=true
                    	    	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
//                    	     $('#CC-companyAddressAlreadyRegistered-Modal').show();
                    	    break;
            	}else{
            	     flag=false;
  //          	     $('#CC-companyAddressAlreadyRegistered-Modal').hide();
//                      	    getWidget.addressExisted(false)
            	    
            	}
                }   //end of for loop
                
                  if(getWidget.addressExisted() !== flag ){
                    	    getWidget.addressExisted(flag)
            	              }

                
                
            
                
                
					
					$('#CC-addressSuggestionMessagePane6').hide();
					
					
						$('#main').removeClass('loadingIndicator');
												spinner.destroy();
												
												
					
//					$('#addNewAddressModal').hide();
			},
			
      /**
        Checkout Customer Details Widget.
        @private
        @name checkout-customer-details
        @property {observable String} checkoutGuest value for the guest checkout radio button
        @property {observable String} checkoutLogin value for the login radio button
        @property {observable String} checkoutOption currently selected checkout option
        @property {observable String} emailAddress Email address entered by user
        @property {observable String} password Either registered or desired user password
        @property {observable String} confirmPassword confirmation of desired password
        @property {observable Boolean} createAccount current value of create account checkbox
        @property {observable Address} billingAddress object representing the customer's
                                       billing address.
        @property {observable Address} shippingAddress object representing the customer's
                                       shipping address.
      */
      onLoad: function(widget) {
          getWidget = widget;
        // set form defaults
        //widget.cart().isSplitShipping(true);
      widget.collectSelectedArray().push({
   "shippingCalculator":"priceRange",
   "eligibleForProductWithSurcharges":true,
   "estimatedDeliveryDateGuaranteed":false,
   "internationalDutiesTaxesFees":0,
   "ranges":[
      {
         "amount":0.00,
         "high":1.7976931348623157e+308,
         "low":0
      }
   ],
   "displayName":"Standard Delivery",
   "taxCode":"GT988",
   "shippingGroupType":"hardgoodShippingGroup",
   "estimatedDeliveryDate":"03-16-2021",
   "enabled":true,
   "deliveryDays":"2",
   
   "repositoryId":"sm50002",
   "carrierId":"ON",
   "__ko_mapping__":{
      "copy":[
         "shippingCalculator",
         "eligibleForProductWithSurcharges",
         "estimatedDeliveryDateGuaranteed",
         "internationalDutiesTaxesFees",
         "ranges",
         "displayName",
         "taxCode",
         "shippingGroupType",
         "estimatedDeliveryDate",
         "enabled",
         "deliveryDays",
         "repositoryId",
         "carrierId"
      ],
      "ignore":[
         
      ],
      "include":[
         "_destroy"
      ],
      "observe":[
         
      ],
      "mappedProperties":{
         
      },
      "copiedProperties":{
         
      }
   }
})
        
        widget.listingViewModel = ko.observable();
        widget.listingViewModel(new DelegatedAdminContacts());
        widget.listingViewModel().fetchByRepositoryId = true;
        widget.listingViewModel().itemsPerPage = widget.fetchSize();
        widget.listingViewModel().blockSize = widget.fetchSize();
        widget.addressArray.push('', 'Suite', 'Apartment', 'Building', 'P.O. Box');
        widget.addressTypeArray.push('', 'Business', 'Residential');
        widget.resetListener = function(obj) {
          widget.shippingAddressBook([]);
        };
        
        
        
        
        
    	
        
                widget.accountNumber.subscribe(function (newValue) {
    	   console.log("collect    "+newValue);
// localStorage.setItem("account_number", newValue) 
 for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "account_number"){
                                   widget.cart().dynamicProperties()[i].value(newValue) 
                                }
                            }
    	});  
    	
    	
        
        widget.selectedCarrier.subscribe(function (newValue) {
//    	   console.log("collect    "+newValue);
    	   if([null,undefined,"","undefined"].indexOf(newValue) == -1){
    	 
    	 
// localStorage.setItem("us_carriers", newValue)
// localStorage.setItem("ship_via", widget.carriersArrayId()[widget.carriersArray().indexOf(newValue)]) 
 
 
 for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "us_carriers"){
                                   widget.cart().dynamicProperties()[i].value(newValue) 
                                }
                                  if(widget.cart().dynamicProperties()[i].id() == "ship_via"){
                                   widget.cart().dynamicProperties()[i].value( widget.carriersArrayId()[widget.carriersArray().indexOf(newValue)]) 
                                }
                            }
 
}
    	});  

           widget.shipComplete.subscribe(function (newValue) {
    	   console.log("collect    "+newValue); 

// localStorage.setItem("ship_complete", newValue) 
 
    for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "ship_complete"){
                                   widget.cart().dynamicProperties()[i].value(newValue) 
                                }
                            }
                            

    	});  
        widget.collect.subscribe(function (newValue) {
    	   console.log("collect    "+newValue); 
    	   if(newValue==="on"){
    	       
    	    //    localStorage.setItem('shipping_method', 'Standard Delivery');
    	        
    	           for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "shipping_method"){
                                   widget.cart().dynamicProperties()[i].value('Standard Delivery') 
                                }
                            }
    	        
        widget.selectedShippingCost("0.00");
    	 widget.selectedShippingValue("co50002")
//                   widget.selectedShippingValue(null);
   	    document.getElementById("shippingOptions-Div1").style.display = "block";
    	/*    $.Topic('CHECKOUT_RESET_SHIPPING_METHOD_COLLECT').publish();*/
    	    widget.collectEnables(false);
    	   }else{
    	        widget.accountNumber('');
    	         widget.selectedCarrier('');
    	       document.getElementById("shippingOptions-Div1").style.display = "none";
    	   }
    	   
    	});
    	
	      $.Topic('resetCollect').subscribe(
	          function(obj) {

	              widget.collect("off");
	               widget.collectEnables(true);
//	              	              console.log("reset the collect object")
	          }
	          
	          );
	          
	            widget.addressBookArray = ko.computed(function() {
	                if(widget.user().isB2BUser() && widget.user().organizationAddressBook)
	                {
	                    //widget.reloadAddressInfoForB2BUser();

   if(widget.organizationAddressBook().length>0){
        widget.allAddressesCheck([])
        for(var i=0;i<widget.organizationAddressBook().length;i++){
            widget.allAddressesCheck().push({
                "address1":widget.organizationAddressBook()[i].address1(),
                "address2":widget.organizationAddressBook()[i].address2(),
                "city":widget.organizationAddressBook()[i].city(),
                "state":widget.organizationAddressBook()[i].selectedState(),
                 "postalCode":widget.organizationAddressBook()[i].postalCode(),
                "country":widget.organizationAddressBook()[i].selectedCountry()
            })
        }
    }
	                    return widget.organizationAddressBook();
	                }
	                else if(!widget.user().isB2BUser() && widget.user().shippingAddressBook())
	                {
	                    
	                       if(widget.shippingAddressBook().length>0){
        widget.allAddressesCheck([])
        for(var i=0;i<widget.shippingAddressBook().length;i++){
            widget.allAddressesCheck().push({
                "address1":widget.shippingAddressBook()[i].address1(),
                "address2":widget.shippingAddressBook()[i].address2(),
                "city":widget.shippingAddressBook()[i].city(),
                "state":widget.shippingAddressBook()[i].selectedState(),
                 "postalCode":widget.shippingAddressBook()[i].postalCode(),
                "country":widget.shippingAddressBook()[i].selectedCountry()
            })
        }
    }
    
    
	                    return widget.shippingAddressBook();
	                }
	            });
        if (widget.user().isB2BUser()) {
          widget.onLoadForB2BUser(widget);
        } else {
          widget.onLoadForB2CUser(widget);
        }
        widget.shippingMethodsLoadedListener = function(obj) {
          notifier.clearError(widget.typeId()+'-shippingMethods');
          if (widget.shippingmethods().shippingOptions().length === 0) {
            widget.handleNoShippingMethods();
          }
          else {
            widget.shippingOptions(widget.shippingmethods().shippingOptions());
            widget.shippingMethodsNewlyLoaded(true);
            widget.skipShipMethodNotification(true);
            widget.selectedShipping();
            if(widget.shippingOptions().length >0)
            {
            
             if(localStorage.getItem('shippingMethod-name') == "collect"){
         widget.collect("on");   
        }
        
            if(widget.shippingOptions()[0].taxCode == "LTL"){
        widget.carriersArray(["Dugan","Estes Express","FedEx","Old Dominion","SAIA","UPS","XPO/Conway"])
        widget.carriersArrayId(["DUGK","ESTC","A01K","ODDC","SAIK","UPSK","C03C"])       
        
          widget.selectedCarrier(localStorage.getItem("ship_via1")) 
            }else{
         widget.carriersArray(["UPS","FedEx"])  
         widget.carriersArrayId(["U01K","F01K"])                   
         
           widget.selectedCarrier(localStorage.getItem("ship_via1")) 
            }


      
/*                        if([null,undefined,""].indexOf(localStorage.getItem('shippingMethod-name')) == -1 ){
   if(localStorage.getItem('shippingMethod-name').includes("Standard")){
              localStorage.setItem("ship_via", 'U01D')   
             }else if(localStorage.getItem('shippingMethod-name').includes("LTL")){
                 localStorage.setItem("ship_via", 'B01D')
             }else if(localStorage.getItem('shippingMethod-name').includes("Two-Day")){
                 localStorage.setItem("ship_via", 'U02D')
             }else if(localStorage.getItem('shippingMethod-name').includes("Next-Day")){
                 localStorage.setItem("ship_via", 'U04D')
             }else if(localStorage.getItem('shippingMethod-name').includes("Free")){
                 localStorage.setItem("ship_via", 'B01D')
             }
			 
                        }*/
                
                for(var i=0;i<widget.shippingOptions().length;i++)
                {
                    if(widget.shippingOptions()[i].displayName === localStorage.getItem('shippingMethod-name'))
                    {
                        
                        
                       // widget.shippingMethodSelected(widget.shippingOptions()[i]);
                    //widget.selectedShipping('on');
                    var radios = $("#shippingOptions input:radio");
                      for(var i = 0; i < radios.length; i++){
                          
                        if(radios[i].parentElement.firstElementChild.innerText ==  localStorage.getItem('shippingMethod-name')){
                          radios[i].checked = true;
                           widget.selectedShippingValue(widget.shippingOptions()[i].repositoryId);
                        }
                      }
                    
                    }
                }
            };
            
            // Set selected shipping option when shipping methods reload to ensure pricing call that can verify
            // if shipping address is valid
              widget.selectedShippingValue(null);
              widget.removeAdjacentShippingAmount(false);
              widget.shippingMethodsLoaded(false);
              widget.isCartPriceUpdated(false);
              // Check the current cart shipping option to see if it been set
              if ((widget.cart) && (widget.cart().shippingMethod() != undefined) && (widget.cart().shippingMethod() !== '') &&
                  (widget.checkIfShippingMethodExists(widget.cart().shippingMethod(), widget.shippingOptions))) {
                widget.selectedShippingValue(widget.cart().shippingMethod());
                widget.destroySpinner();
              }
              //for web checkout error case, use the shipping method selected before going for web checkout
              else if (widget.order().webCheckoutShippingMethodValue) {
                //dont clear the notifier error message
                widget.clearInvalidShippingMethodError = false;
                widget.selectedShippingValue(widget.order().webCheckoutShippingMethodValue);
                widget.order().webCheckoutShippingMethodValue = null;
              }
              // TODO - should we reset the cart shipping method
              // Use the default shipping method from the list
              else if (widget.shippingmethods().defaultShipping() != undefined) {
                // the cart doesn't have a shipping method so set the default shipping method and
                // send a message to say the selected shipping option has been updated.
                widget.selectedShippingValue(widget.shippingmethods().defaultShipping());
                widget.destroySpinner();
              }
            
            
          }
        },
        $.Topic(pubsub.topicNames.ORDER_SUBMISSION_SUCCESS).subscribe(widget.resetListener);
        $.Topic(pubsub.topicNames.LOAD_ORDER_RESET_ADDRESS).subscribe(widget.resetListener);
                $.Topic(pubsub.topicNames.SHIPPING_METHODS_LOADED).subscribe(widget.shippingMethodsLoadedListener);
        $.Topic(pubsub.topicNames.USER_LOGIN_SUCCESSFUL).subscribe(function(){
          widget.priceSplitShippingCartForCheckout();
        });
/*          $.Topic('CHECKOUT_RESET_SHIPPING_METHOD_COLLECT').subscribe(
              function(obj) {
                widget.selectedShippingValue(null);
                widget.selectedShippingOption(null);
                //widget.setupShippingOptions();
                widget.selectedShipping();
              });*/
        widget.checkIfSelectedShipCountryInBillCountries = function() {
          var selectedShipCountryInBillCountries = false;
          if (widget.billingCountries()) {
            for (var i=0; i<widget.billingCountries().length; i++) {
              if (widget.newShippingAddress().selectedCountry() === widget.billingCountries()[i].countryCode) {
                selectedShipCountryInBillCountries = true;
                break;
              }
            }
          }
          return selectedShipCountryInBillCountries;
        }

        $.Topic(pubsub.topicNames.DESTROY_SHIPPING_OPTIONS_SPINNER).subscribe(widget.destroySpinner.bind(widget));

        $.Topic(pubsub.topicNames.GET_INITIAL_ORDER_FAIL).subscribe(function() {
          widget.destroySpinner();
          widget.cart().isPricingRequired(false);
        });

        widget.createSpinner = function() {
          $(widget.shippingAddressIndicator).css('position','relative');
          $(widget.shippingAddressIndicator).addClass('loadingIndicator');
          spinner.create(widget.shippingAddressIndicatorOptions);
        };
             // handles when no shipping methods are available.
        widget.handleNoShippingMethods = function(obj) {
          //widget.noShippingMethods(true);
          //widget.resetShippingOptions();
          widget.destroySpinner();
        };  

        widget.displayShippingMethodsDropdown = function(data, event) {
          var self = this;
         
           
          //if(self.shippingmethods().shippingOptions().length == 0) {
            if (self.order().shippingAddress() && self.order().shippingAddress().validateForShippingMethod()) {
              self.createSpinner();
              // Skip the pricing spinner when the drop down is getting clicked for the first time after address change
            //   self.skipSpinner(true);
              var shippingAddressWithProductIDs = {};
              shippingAddressWithProductIDs[CCConstants.SHIPPING_ADDRESS_FOR_METHODS] = self.order().shippingAddress();
              shippingAddressWithProductIDs[CCConstants.PRODUCT_IDS_FOR_SHIPPING] = self.cart().getProductIdsForItemsInCart();
              self.cart().updateShippingAddress.bind(shippingAddressWithProductIDs)();
              
              /*
              var request={};
              request['items']=this.cart().allItems();
              request['complete']=self.shipComplete();
              
  
              
              
              
  							$.ajax({
							    //http://localhost:3000
								url: '/ccstorex/custom/v1/shippingDate',
								headers: {
									'Content-Type': "application/json"
								},
								method: 'POST',
								processData: false,
								contentType: false,
								data: JSON.stringify( request )
							}).done( function ( response ) {
                                      console.log("Success         "+response);
                                      const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

                                     var dat=new Date(response);
                                     
                                      self.estimatedDate(monthNames[parseInt(("0"+(dat.getMonth()+1)).slice(-2))-1]+", "+("0" + dat.getDate()).slice(-2))
                                      localStorage.setItem("expected_delivery_date", response);
							} ).fail( function ( error ) {
								notifier.sendError( getWidget.WIDGET_ID, "Error while getting expected shipping date", false );
							} );
              */
              
            }
            
            	
	            for(var i=0;i<widget.delegatedAdminContactsListGrid().length;i++){
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_main_contact()){
                    widget.mainContact(widget.delegatedAdminContactsListGrid()[i])
                }
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_billing_contact()){
                    widget.billingContact(widget.delegatedAdminContactsListGrid()[i])
                }
                if(widget.delegatedAdminContactsListGrid()[i].repositoryId == widget.order().shippingAddress().x_shipping_contact()){
                    widget.shippingContact(widget.delegatedAdminContactsListGrid()[i])
                }

            }
            
            
            
            
            
        //  }
          return true;
        };
        widget.selectedShipping = function(){
  /*          if(widget.collect()!="on"){*/
        if(widget.shippingOptions().length >0 ){
            for(var i=0;i<widget.shippingOptions().length;i++)
            {
                if(widget.shippingOptions()[i].displayName === localStorage.getItem('shippingMethod-name'))
                {
                  var radios = $("#shippingOptions input:radio");
                      for(var i = 0; i < radios.length; i++){
                        if(radios[i].parentElement.firstElementChild.innerText ==  localStorage.getItem('shippingMethod-name')){
                          radios[i].checked = true;
                            widget.selectedShippingValue(widget.shippingOptions()[i].repositoryId);
                        }
                      }
                }
            }
            return true;
        }
/*            }
            else{
                    widget.selectedShippingValue(null);
                     return false;
            }
*/      
        };
         widget.delegatedAdminContactsListGrid = ko.computed(function() {
          var numElements, start, end, width;
          var rows = [];
          var orders;
            var startPosition, endPosition;
            // Get the orders in the current page
            startPosition = (widget.listingViewModel().currentPage() - 1) * widget.listingViewModel().itemsPerPage;
            endPosition = startPosition + parseInt(widget.listingViewModel().itemsPerPage,10);
            orders = widget.listingViewModel().data();
          
          if (!orders) {
            return;
          }
          numElements = orders.length;
          width = parseInt(widget.listingViewModel().itemsPerRow(), 10);
          start = 0;
          end = start + width;
          while (end <= numElements) {
            rows.push(orders.slice(start, end));
            start = end;
            end += width;
          }
          if (end > numElements && start < numElements) {
            rows.push(orders.slice(start, numElements));
          }
          //Generating localized roleString for each user
          /**if(rows.length >= 0) {
            var rowsLength = rows.length;
            for(var row = 0; row < rowsLength; row++) {
              rows[row][0]["roleString"] = widget.getRoleString(rows[row][0]["roles"]);
            }
          }**/
          
          if(orders.length>0){
           for(var i=0;i<orders.length;i++){
                if(orders[i].repositoryId == widget.order().shippingAddress().x_main_contact()){
                    widget.mainContact(orders[i])
                }
                if(orders[i].repositoryId == widget.order().shippingAddress().x_billing_contact()){
                    widget.billingContact(orders[i])
                }
                if(orders[i].repositoryId == widget.order().shippingAddress().x_shipping_contact()){
                    widget.shippingContact(orders[i])
                }
                 }
          }
          
          
          return orders;
        }, widget);
        // Sends shipping notification details to the subscribers along with shipping address and shipping options
        widget.sendShippingNotification = function () {
          notifier.clearError(widget.typeId() + '-pricingError');
          if (widget.selectedShippingOption() != undefined 
              && widget.selectedShippingOption() !== ''
              && !widget.skipShipMethodNotification()) {
            $.Topic(pubsub.topicNames.CHECKOUT_SHIPPING_METHOD).publishWith(widget.selectedShippingOption(), [{message: "success"}]);
          }
          widget.skipShipMethodNotification(false);
        };
        
         widget.shippingMethodSelected = function(event,data) {
             if(data === null)
             {
                 return null;
             }else{
             event.target.checked = true;
             console.log("EVENT :: ",event.target)
             
          /*   if(data.displayName == "Standard Delivery"){
              localStorage.setItem("ship_via", 'U01D')   
             }
             else if(data.displayName == "LTL Shipment Percentage"){
                 localStorage.setItem("ship_via", 'B01D')
             }else if(data.displayName == "LTL shipment"){
                 localStorage.setItem("ship_via", 'B01D')
             }else if(data.displayName == "Two-Day Delivery"){
                 localStorage.setItem("ship_via", 'U02D')
             }else if(data.displayName == "Next-Day Delivery"){
                 localStorage.setItem("ship_via", 'U04D')
             }*/
             
               for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "shipping_method"){
                                   widget.cart().dynamicProperties()[i].value(data.displayName) 
                                }
                            }
//              localStorage.setItem('shipping_method', data.displayName);
// localStorage.setItem('shipping_cost', data.internationalDutiesTaxesFees.toFixed(2));
 

                            
 var shipv;
 
if(data.taxCode == 'PAR'  || data.taxCode == 'PERC'){
 if(data.displayName.includes("Standard") || data.displayName.includes("Free") ){
//                   localStorage.setItem("ship_via", 'U01D')   
                   shipv='U01D'
 }else if(data.displayName.includes("Two-Day") ){
  //               localStorage.setItem("ship_via", 'U02D')   
                  shipv='U02D'
 }else if(data.displayName.includes("Next-Day") ){
    //             localStorage.setItem("ship_via", 'U04D')   
                  shipv='U04D'
 }
}else{
//    localStorage.setItem("ship_via", 'B01D')
     shipv='B01D'
}

 for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "shipping_cost"){
                                   widget.cart().dynamicProperties()[i].value(data.internationalDutiesTaxesFees.toFixed(2)) 
                                }
                                 if(widget.cart().dynamicProperties()[i].id() == "ship_via"){
                                   widget.cart().dynamicProperties()[i].value(shipv) 
                                }
}

/*           if([null,undefined,""].indexOf(data.displayName) == -1 ){
   if(data.displayName.includes("Standard")){
              localStorage.setItem("ship_via", 'U01D')   
             }else if(data.displayName.includes("LTL")){
                 localStorage.setItem("ship_via", 'B01D')
             }else if(data.displayName.includes("Two-Day")){
                 localStorage.setItem("ship_via", 'U02D')
             }else if(data.displayName.includes("Next-Day")){
                 localStorage.setItem("ship_via", 'U04D')
             }else if(data.displayName.includes("Free")){
                 localStorage.setItem("ship_via", 'B01D')
             }
			 
                        }
*/                        
             
             
             
             
             
              
             
             
            widget.selectedShippingValue(data.repositoryId);
             widget.selectedShippingCost(data.estimatedCostText());
            console.log(data.estimatedCostText(),"data.estimatedCostText");
            console.log(widget.selectedShippingCost(),"selectedshipping cost");
            $.Topic('resetCollect').publish(widget.selectedShippingCost());
              return true;   
             }
             return true;
        };
         // Handle changes to Selected Shipping option
        widget.selectedShippingValue.subscribe(function (newValue) {
        if(widget.cart().items().length <= 0) {
            widget.displayShippingOptions(false);
            return;
          }
          if (newValue) {
              if(widget.shippingOptions().length>0){
                  const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

                                     var dat=new Date(widget.shippingOptions()[0].estimatedDeliveryDate);
                                     
                                      widget.estimatedDate(monthNames[parseInt(("0"+(dat.getMonth()+1)).slice(-2))-1]+", "+("0" + dat.getDate()).slice(-2))
                                     // localStorage.setItem("expected_delivery_date", widget.shippingOptions()[0].estimatedDeliveryDate);
                                      
             for(var i=0;i<widget.cart().dynamicProperties().length;i++){
                                if(widget.cart().dynamicProperties()[i].id() == "expected_delivery_date"){
                                   widget.cart().dynamicProperties()[i].value(widget.shippingOptions()[0].estimatedDeliveryDate) 
                                }
                            }
                            
              }


              
             if (widget.skipSpinner()) {
                widget.skipSpinner(false);
            } else {
              widget.createSpinner();
            }            
            // clears invalid shipping method error only if user selects any shipping option
            // but not if default shipping method is selected after shipping options reload.
            if (widget.clearInvalidShippingMethodError) {
              notifier.clearError("OrderViewModel");
              widget.clearInvalidShippingMethodError = false;
            }
            
        if(widget.shippingOptions()[0].taxCode == "LTL"){
        widget.carriersArray(["Dugan","Estes Express","FedEx","Old Dominion","SAIA","UPS","XPO/Conway"])
        widget.carriersArrayId(["DUGK","ESTC","A01K","ODDC","SAIK","UPSK","C03C"])       
        
          widget.selectedCarrier(localStorage.getItem("ship_via1")) 
            }else{
         widget.carriersArray(["UPS","FedEx"])  
         widget.carriersArrayId(["U01K","F01K"])                   
         
           widget.selectedCarrier(localStorage.getItem("ship_via1")) 
            }
            // Check to see if selected shipping option is in the list of valid shipping options
            for (var i = 0; i < widget.shippingOptions().length; i++) {
              if (widget.shippingOptions()[i].repositoryId === widget.selectedShippingValue()) {
                  
             
                widget.selectedShippingOption(null);
                widget.selectedShippingOption(widget.shippingOptions()[i]);

                // Request checkout re-pricing as shipping method has changed
                widget.sendShippingNotification();
                if (widget.shippingMethodsLoaded()) {
                   widget.removeAdjacentShippingAmount(true);
                 } else {
                   widget.shippingMethodsLoaded(true);
                   widget.removeAdjacentShippingAmount(false);
                 }
                
                // Housekeeping: reset flags/errors
  /*              if (widget.reloadShippingMethods()) {
                  widget.reloadShippingMethods(false);
                } else {
                  notifier.clearError(widget.typeId()+'-shippingMethods');
                }*/
                break;
              }
            }
/*            if(newValue == "sm50002"){
                var data;
                if(widget.shippingOptions().length>0){
                    data=widget.shippingOptions()[0];
                }
                
                 widget.selectedShippingOption(null);
                widget.selectedShippingOption(data);

                // Request checkout re-pricing as shipping method has changed
                widget.sendShippingNotification();
                if (widget.shippingMethodsLoaded()) {
                   widget.removeAdjacentShippingAmount(true);
                 } else {
                   widget.shippingMethodsLoaded(true);
                   widget.removeAdjacentShippingAmount(false);
                 }
                
                // Housekeeping: reset flags/errors
                if (widget.reloadShippingMethods()) {
                  widget.reloadShippingMethods(false);
                } else {
                  notifier.clearError(widget.typeId()+'-shippingMethods');
                }
                
                
                
            }*/
            
            
            if( widget.cart().currentOrderState()== CCConstants.PENDING_PAYMENT ||  widget.cart().currentOrderState()==CCConstants.PENDING_PAYMENT_TEMPLATE){
              widget.setupShippingOptions();
            }
          }
        });


        widget.canAddShippingGroupRelationship = function (cartItem, shippingGroupRelationship) {
          return ko.pureComputed(function () {
            return cartItem.canAddShippingGroupRelationship(shippingGroupRelationship);
          });
        };

        widget.addShippingGroupRelationship = function (sgr) {
          var cartItem = this;
          this.addShippingGroupRelationship.bind(cartItem, sgr, widget.cart())();
        };

        widget.selectedShippingMethod = function (option, item) {
          if (this.shippingMethod && this.shippingMethod()) {
            widget.currentShippingGroupShippingMethod[this.sgID] = this.shippingMethod();
          }
          if (widget.currentShippingGroupShippingMethod[this.sgID]) {
            var shippingMethodId = widget.currentShippingGroupShippingMethod[this.sgID].value || widget.currentShippingGroupShippingMethod[this.sgID].id
          }
          if (item && widget.currentShippingGroupShippingMethod[this.sgID]) {
            if (shippingMethodId && shippingMethodId == item.id) {
              ko.applyBindingsToNode(option.parentElement, {value: item}, item);
            }
          }
        }

        widget.updateQuantity = function(shippingGroup, cartItem, event, id) {

          if('click' === event.type || ('keypress' === event.type && event.keyCode === 13)) {
            if(shippingGroup.updatableQuantity && shippingGroup.updatableQuantity.isValid()) {
              widget.createSpinner();
              var shippingGroupRelationsQuantitiesSum = cartItem.shippingGroupRelationships().reduce(function (sum, shippingGroupRelationship) {
                return sum += parseFloat(shippingGroupRelationship.updatableQuantity());
              }, 0);
              cartItem.updatableQuantity(shippingGroupRelationsQuantitiesSum);
              $.Topic(pubsub.topicNames.CART_UPDATE_QUANTITY).publishWith(
              cartItem.productData(),[{"message":"success", "commerceItemId": cartItem.commerceItemId, "shippingGroup": shippingGroup}]);

              var button = $('#' + id);
              button.focus();
              button.fadeOut();
            } else {
              //data.updatableQuantity(data.quantity());
            }
          } else {
            this.quantityFocus(cartItem, event);
          }

          return true;
        };

        widget.quantityFocus = function (data, event) {
          var field = $('#' + event.target.id);
          var button = field.siblings("p").children("button");
          button.fadeIn();
        };

        widget.toggleAddressBook = function (toggle, shippingGroupRelationship, event) {
          widget.shippingGroupForAddressBook = shippingGroupRelationship;
          if(event)
            widget.selectedShpgrpElement = event.currentTarget;
          if (widget.user().isB2BUser()) {
            $("#B2BAddressBookModal").modal(toggle);
            $("#B2BAddressBookModal").on("hidden.bs.modal", function () {
                if(widget.selectedShpgrpElement) {
                  widget.selectedShpgrpElement.focus();
                }
            });
          } else {
            $("#B2CAddressBookModal").modal(toggle);
            $("#B2CAddressBookModal").on("hidden.bs.modal", function () {
                if(widget.selectedShpgrpElement) {
                  widget.selectedShpgrpElement.focus();
                }
            });
          }
        }

        widget.openAddAddress = function () {
            if($('#addNewAddressModal').is(':visible')){
                console.log("hhh")
                $("#addNewAddressModal").hide();
            }else{
                console.log("else")
          widget.newShippingAddress(new Address('new-shipping-address', widget.ErrorMsg, widget, widget.shippingCountries(), widget.defaultShippingCountry()));
          widget.addShippingAddressTo("");
          widget.opDynamicProperty("update");
          widget.useAsBillingAddress(false);
          if (widget.user().isB2BUser()) {
            if(widget.userIsProfileAddressManager()){
              widget.addShippingAddressTo(CCConstants.PROFILE_ADDRESSES_TYPE);
            }else if(widget.userIsAccountAddressManager()){
              widget.addShippingAddressTo(CCConstants.ACCOUNT_ADDRESSES_TYPE);
            }
          }

          $("#addNewAddressModal").show();
        }
        
        },
        widget.handleAddNewShippingAddress = function () {
          widget.order().shippingAddress().reset();
          widget.order().shippingAddress().resetModified();
          widget.opDynamicProperty("update");
          widget.isUsingSavedAddress(false);
         // $('#CC-checkoutAddressBook-sfirstname').focus();
          widget.checkIfSelectedShipCountryInBillCountries();
          $.Topic(pubsub.topicNames.ADD_NEW_CHECKOUT_SHIPPING_ADDRESS).publish();
        };


        widget.selectAddress = function (address, sgr, fromView) {
          if (!sgr) {
            sgr = widget.shippingGroupForAddressBook;
          }
          sgr.shippingAddress(address);
          widget.currentShippingGroupShippingMethod[sgr.sgID] = "";
          widget.toggleAddressBook('hide');
        }
             widget.checkIfShippingMethodExists = function(selectedShippingMethod, shippingOptions) {
          return ko.utils.arrayFirst(shippingOptions(), function(shippingOption) {
            return selectedShippingMethod === shippingOption.repositoryId;
          });
        };

        widget.toggleShippingGroup = function (cartItem, shippingGroupRelationship) {
          if (shippingGroupRelationship.isPickupInStore()) {
            widget.handleStoreRemoval(cartItem, shippingGroupRelationship);
          }
        }

        widget.lookupShippingOptions = function () {
          var shippingGroupRelationship = this;

          setTimeout(function () {
            if(shippingGroupRelationship.shippingAddress()){
              ShippingMethodsViewModel.getInstance().loadMultipleShippingOptions(function success (data) {
                for(var index = 0;index < data.items.length; index++){
                  if(data.items[index] !=null && data.items[index].shippingGroupId === shippingGroupRelationship.shippingGroupId){
                    shippingGroupRelationship.shippingOptions(ko.utils.arrayMap(data.items[index].shippingMethods, function (shippingMethod) {
                      var currency = widget.site().selectedPriceListGroup().currency.symbol;
                      var shippingMethodItem = new ShippingMethodItemViewModel(shippingMethod, widget.cart().amount());
                      if (widget.cart().showSecondaryShippingData()) {
                        shippingMethodItem.qualifiedDisplayName =
                          shippingMethodItem.displayName + " (" + widget.cart().secondaryCurrency().symbol + shippingMethodItem.secondaryCurrencyShippingCost() + ")";
                      } else {
                        shippingMethodItem.qualifiedDisplayName =
                          shippingMethodItem.displayName + " (" + currency + shippingMethodItem.estimatedCostText() + ")";
                      }
                      return shippingMethodItem
                    }));
                  break;
                  }
                }
              },
                // Error callback.
                function error (data) {
                  // Default args.
                  data = data || {};

                  console.error("CheckoutAddressBook.loadShippingMethod " + data.message || '- unknown error returned');
                }
              );
            }
          }, 0);
        };

        $.Topic(pubsub.topicNames.CHECKOUT_SHIPPING_GROUP_SHIPPING_ADDRESS_CHANGED).subscribe(widget.lookupShippingOptions);

        widget.getOptionTextForAddress = function (address) {
          if (address.alias || address.firstName) {
            return address.alias() || address.firstName() + ' ' + address.lastName() + ', ' + address.address1() + ', ' +
              address.city();
          } else {
            return address;
          }

        };

        widget.priceSplitShippingCartForCheckout = function () {
          if(navigation.isPathEqualTo(widget.cart().checkoutLink) || navigation.isPathEqualTo(widget.cart().agentMultiShipCheckout)) {
            widget.cart().saveCartCookie();
            if (widget.cart().hasShippingInformation() && widget.cart().currentOrderState() != 'PENDING_PAYMENT' && widget.cart().currentOrderState() != 'PENDING_PAYMENT_TEMPLATE') {
              widget.createSpinner();
            }
            // Only run when split shipping is selected (single shipping has its own repricing mechanisms).
            if (widget.cart().isSplitShipping()) {
              // Reprice cart.
              widget.cart().priceCartForCheckout();
              //destroy the spinner after pricing
              widget.destroySpinner();
            }
          }
        };

        widget.removeShippingGroupRelationShip = function (shippingGroupRelationship) {
          this.removeShippingGroupRelationShip(shippingGroupRelationship);
        };

        widget.openStorePickerModal = function (cartItem, shippingGroupRelationship, event) {
          if (widget.shippingGroupInStorePicker && widget.shippingGroupInStorePicker.catRefId != shippingGroupRelationship.catRefId) {
            widget.stores.removeAll();
            widget.storeLookupStatus(0);
            widget.storeSearchText("");
          }
          widget.shippingGroupInStorePicker = shippingGroupRelationship;
          widget.cartItemInStorePicker = cartItem;
          widget.selectedShpgrpElement = event.currentTarget;
          $("#storePickUpModal").modal("show");
          $('#storePickUpModal').on('shown.bs.modal', function () {
              // get the locator for an input in your modal.
              var storeSearchTextField = $('#CC-storeSelect');
              var storeSearchTextFieldMobile = $('#CC-storeSelect-mobile');
              if(storeSearchTextField) {
                storeSearchTextField.focus();
              } else if(storeSearchTextFieldMobile) {
                storeSearchTextFieldMobile.focus();
              }
            });
            $("#storePickUpModal").on("hidden.bs.modal", function () {
              if(widget.selectedShpgrpElement) {
                widget.selectedShpgrpElement.focus();
              }
            });
        };
        widget.handleKeyPress = function(event) {

          var keyCode = (event.which ? event.which : event.keyCode);
          switch(keyCode) {
            case CCConstants.KEY_CODE_ENTER:
              // Enter key
              widget.showStoreSearchResults();
              $('#storePickUpModal').modal('show');
            }
          return true;
        }

        widget.showStoreSearchResults = function () {

          widget.storeLookupStatus(0);
          var inventory = new Inventory();

          var successCallBack = function(storeInfos) {
            // clear previous search results, if any
            widget.stores.removeAll();
            if(null !== storeInfos && storeInfos.length > 0) {
              for(var index = 0;index < storeInfos.length; index++) {
                widget.stores.push(storeInfos[index]);
              }
            }
          }
          var errorCallBack = function(errorInfo) {
            widget.storeLookupStatus(errorInfo.storeLookupStatus);
          }

          inventory.getLocationInventoryForUserQuery({
            searchText : widget.storeSearchText(),
            noOfStoresToDisplay : widget.noOfStoresToDisplay(),
            siteId : widget.site().siteInfo.id,
            catalogId : widget.user().catalogId(),
            locationType : 'store',
            pickUp : true,
            comparator : 'CO',
            searchableFields : ['city', 'postalCode', 'name'],
            productSkuIds : inventory.getProductSkuIdsInCartItem(widget.cartItemInStorePicker)
          }, successCallBack.bind(widget), errorCallBack.bind(widget));
        }

        /**
         * Performs inventory checks for selected item against selected store / global inventory.
         * @param cartItem
         * @param inventoryDetails
         * @param shippingGroupRelationship
         */
        widget.validateInventoryForShippingGroup = function(cartItem, inventoryDetails, shippingGroupRelationship) {
          var self = widget;
          cartItem = !cartItem ? self.cartItem : cartItem;
          if (!shippingGroupRelationship.getItemQuantityInCart) {
            shippingGroupRelationship.getItemQuantityInCart = widget.cart().getUpdatableItemQuantityInCart.bind(
                widget.cart(), widget.cart().items(), cartItem.productId, cartItem.catRefId, shippingGroupRelationship);
          }
          if (self.cart().isConfigurableItem(cartItem) && cartItem.childItems && cartItem.childItems.length > 0) {
            shippingGroupRelationship.addConfigurableStockValidation(inventoryDetails, self.cart().isPreOrderBackOrderEnabled);
          } else {
            shippingGroupRelationship.addLimitsValidation(cartItem, inventoryDetails, self.cart().isPreOrderBackOrderEnabled);
          }
        }

        widget.handleStoreSelection = function (selectedStore, parent) {
          widget.shippingGroupInStorePicker.shippingAddress(undefined);
          widget.shippingGroupInStorePicker.shippingMethod(undefined);
          widget.shippingGroupInStorePicker.shippingOptions([]);
          widget.shippingGroupInStorePicker.isPickupInStore(true);
          widget.shippingGroupInStorePicker.selectedStore(selectedStore);
          widget.shippingGroupInStorePicker.populateUserDetails(widget.user());

          widget.validateInventoryForShippingGroup(widget.cartItemInStorePicker, selectedStore.inventoryDetails, widget.shippingGroupInStorePicker);
          $("#storePickUpModal").modal("hide");
          widget.priceSplitShippingCartForCheckout();
        }

        /**
         * Handles store removal. Would fetch default global inventory details and does inventory checks.
         * @param cartItem
         * @param shippingGroupRelationship
         */
        widget.handleStoreRemoval = function(cartItem, shippingGroupRelationship) {

          if(null != shippingGroupRelationship) {
            shippingGroupRelationship.selectedStore(null);
            shippingGroupRelationship.isPickupInStore(false);

            // Get back global inventory details when home delivery option is chosen.
            var inventory = new Inventory();
            var successCallBack = function(data) {
              widget.validateInventoryForShippingGroup(cartItem, data,shippingGroupRelationship);
            };
            var errorCallBack = function(errorInfo) {
              console.log("ERROR IN FETCHING INVENTORY DETAILS");
            };
            inventory.getStockStatuses({
              productSkuIds : inventory.getProductSkuIdsInCartItem(cartItem),
              catalogId : widget.user().catalogId()
            }, successCallBack.bind(widget), errorCallBack.bind(widget))
          }
        }

        widget.storeSearchText.extend({
          maxLength: {
            params: 50, message: CCi18n.t('ns.common:resources.maxlengthValidationMsg', {maxLength: 50})
          }
        });
                

      },
      
      
   saveAddress: function (data) {
       var widget=this;
       if(widget.user().isB2BUser()){    //b2b
       
       widget.createNewOrganizationAddress(widget.convertToData());
           
       }else{  // b2c
           
 widget.createNewProfileAddress(widget.convertToData());
 
 
       }  //end of b2c
   },
    createNewOrganizationAddress: function(pData) {
      var widget = this;
      ccRestClient.request(CCConstants.END_POINT_ADD_ADDRESSES, pData, widget.createOrUpdateSuccess.bind(widget), widget.saveFailure.bind(widget));
    },
    
     profileCreateOrUpdateSuccess: function(pResponse) {
      var widget = this;
      widget.closeModal();
      
      
    },
     createOrUpdateSuccess: function(pResponse) {
      var widget = this;
  widget.closeModal();
      
    },

    saveFailure: function(pError) {
      var widget = this;
      notifier.clearError(widget.WIDGET_ID);
      notifier.clearSuccess(widget.WIDGET_ID);
      if (pError.status == CCConstants.HTTP_UNAUTHORIZED_ERROR) {
          widget.user().handleSessionExpired();
          if (navigation.isPathEqualTo(widget.links().profile.route) || navigation.isPathEqualTo(widget.links().accountAddresses.route)) {
            navigation.doLogin(navigation.getPath(), widget.homeRoute);
          }
      }
      else {
              
                
//        notifier.sendError(widget.WIDGET_ID, pError.message ? pError.message : this.translate("organizationAddressUpdateFailureText"), true);
      }
      
      	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
      
    },      
	
   profileAddressSaveFailure: function(pError) {
      var widget = this;
      notifier.clearError(widget.WIDGET_ID);
      notifier.clearSuccess(widget.WIDGET_ID);
      if (pError.status == CCConstants.HTTP_UNAUTHORIZED_ERROR) {
          widget.user().handleSessionExpired();
          if (navigation.isPathEqualTo(widget.links().profile.route) || navigation.isPathEqualTo(widget.links().accountAddresses.route)) {
            navigation.doLogin(navigation.getPath(), widget.homeRoute);
          }
      }
      else {
        notifier.sendError(widget.WIDGET_ID, pError.message ? pError.message : this.translate("organizationAddressUpdateFailureText"), true);
      }
      
      	$('#main').removeClass('loadingIndicator');
												spinner.destroy();
												
    },
         createNewProfileAddress: function(pData) {
      var widget = this;
//      widget.operationPerformedOnAddresses("created");
      //AgentApplication - User id required in agent application
      if (ccRestClient.profileType === CCConstants.PROFILE_TYPE_AGENT) {
        ccRestClient.request(CCConstants.END_POINT_ADD_PROFILE_ADDRESS, pData, widget.profileCreateOrUpdateSuccess.bind(widget), widget.profileAddressSaveFailure.bind(widget), widget.user().id());
      } else {
        ccRestClient.request(CCConstants.END_POINT_ADD_PROFILE_ADDRESS, pData, widget.profileCreateOrUpdateSuccess.bind(widget), widget.profileAddressSaveFailure.bind(widget));
      }
    },
    
    
     convertToData: function(pData) {
      var widget = this;
      var data = {};
      
      
      
      if(getWidget.newShippingAddress().alias()){
      data[CCConstants.ORG_ADDRESS_TYPE] = getWidget.newShippingAddress().alias();          
      }else{
    data[CCConstants.ORG_ADDRESS_TYPE] = "Address"+(widget.user().shippingAddresses().length);
      }

      
      var address = {};
      address[CCConstants.ORG_ADDRESS_1] = getWidget.newShippingAddress().address1();
      if(widget.selectedShippingAddressType() || getWidget.newShippingAddress().address2()) {
        address[CCConstants.ORG_ADDRESS_2] =widget.selectedShippingAddressType()+" "+getWidget.newShippingAddress().address2();
      //  address[CCConstants.ORG_ADDRESS_2] ="";
      }else{
        address[CCConstants.ORG_ADDRESS_2] ="";
      }
      
      address["x_account_type"]=getWidget.newShippingAddress().addressType()

      
      if((getWidget.newShippingAddress().address3() === null || getWidget.newShippingAddress().address3() === undefined || getWidget.newShippingAddress().address3() === "")) {
        address[CCConstants.ORG_ADDRESS_3] ="";
      }else{
        address[CCConstants.ORG_ADDRESS_3] =getWidget.newShippingAddress().address3();
      }
      if((getWidget.newShippingAddress().county() === null || getWidget.newShippingAddress().county() === undefined || getWidget.newShippingAddress().county() === "")) {
        address[CCConstants.ORG_COUNTY] ="";
      }else{
        address[CCConstants.ORG_COUNTY] =getWidget.newShippingAddress().county();
      }
      address[CCConstants.ORG_COUNTRY] = "US";
      
      
                if([null,undefined,""].indexOf(getWidget.user().parentOrganization) == -1){
                            address[CCConstants.ORG_STATE] = getWidget.newShippingAddress().selectedState();
                }else{
      if([null,undefined,""].indexOf(getWidget.newShippingAddress().state())!= -1) {
        address[CCConstants.ORG_STATE] = "";
      } else {
        address[CCConstants.ORG_STATE] = getWidget.newShippingAddress().state();
      }                    
                }
      
      

      
 
      
 //     getWidget.newShippingAddress().state()
      
      if((getWidget.newShippingAddress().firstName() === null || getWidget.newShippingAddress().firstName() === undefined || getWidget.newShippingAddress().firstName() === "")) {
        address[CCConstants.PROFILE_FIRST_NAME]=""
      }else{
        address[CCConstants.PROFILE_FIRST_NAME] = getWidget.newShippingAddress().firstName();
      }
      if((getWidget.newShippingAddress().lastName() === null || getWidget.newShippingAddress().lastName() === undefined || getWidget.newShippingAddress().lastName() === "")) {
        address[CCConstants.PROFILE_LAST_NAME]="";
      }else{
        address[CCConstants.PROFILE_LAST_NAME] = getWidget.newShippingAddress().lastName();
      } 
/*      if((getWidget.newShippingAddress().companyName() === null || getWidget.newShippingAddress().companyName() === undefined || getWidget.newShippingAddress().companyName() === "")){
        address[CCConstants.ORG_COMPANY_NAME] = "";
      }else{*/
          if([null,undefined,""].indexOf(getWidget.user().parentOrganization) == -1){
               address[CCConstants.ORG_COMPANY_NAME] =  getWidget.user().parentOrganization.name();
          }else{
              address[CCConstants.ORG_COMPANY_NAME] = "";
          }

  //      address[CCConstants.ORG_COMPANY_NAME] =  getWidget.newShippingAddress().companyName();
      /*}*/  
      address[CCConstants.ORG_CITY] = getWidget.newShippingAddress().city();
      address[CCConstants.ORG_POSTAL_CODE] = getWidget.newShippingAddress().postalCode();
      if((getWidget.newShippingAddress().phoneNumber() === null || getWidget.newShippingAddress().phoneNumber() === undefined || getWidget.newShippingAddress().phoneNumber() === "")) {
        address[CCConstants.ORG_PHONE_NUMBER] = "";
      }else{
        address[CCConstants.ORG_PHONE_NUMBER] =getWidget.newShippingAddress().phoneNumber();        
      }  
      
      address["special_delivery_instructions"]=getWidget.newShippingAddress().type();
      address["selectedCountry"] = getWidget.newShippingAddress().selectedCountry();
      address[CCConstants.ORG_IS_DEFAULT_BILLING_ADDRESS] = false;
      //For B2C user, make the first address as default shipping address

        address[CCConstants.ORG_IS_DEFAULT_SHIPPING_ADDRESS] = false;

/*      for(var i = 0; i< widget.dynamicProperties().length; i++) {
        if (widget.dynamicProperties()[i].type() === "enum") {
          address[widget.dynamicProperties()[i].id()] = widget.dynamicProperties()[i].values;
        } else {
          address[widget.dynamicProperties()[i].id()] = widget.dynamicProperties()[i].value();
        }
      }*/
          address["isDefaultShippingAddress"]=false
      data[CCConstants.ORG_ADDRESS] = address;
      return data;
    },
    
    
      onLoadForB2CUser: function (widget) {

        // Handle user logging in- reload address details whenever the user profile loads shipping info.
        $.Topic(pubsub.topicNames.USER_LOAD_SHIPPING).subscribe(function(obj) {
          if (navigation.getRelativePath().indexOf(widget.links().profile.route) == -1) {
            widget.reloadAddressInfoForB2CUser();
          }
        });

        // Handle user logging out and taking their saved addresses with them.
        $.Topic(pubsub.topicNames.USER_LOGOUT_SUCCESSFUL).subscribe(function(obj) {
          widget.resetListener();
        });

        widget.addShippingAddress = function () {
          if (widget.user().loggedIn()) {
              if(widget.user().isB2BUser())
              {
                  widget.newShippingAddress().companyName(widget.user().parentOrganization().name());
              }
            widget.newShippingAddress().phoneNumber('9999999999');
            widget.newShippingAddress().firstName(widget.user().firstName());
            widget.newShippingAddress().lastName(widget.user().lastName());
            widget.user().editShippingAddress(widget.newShippingAddress());
            widget.shippingAddressBook.unshift(widget.newShippingAddress());
            // widget.order().shippingAddress().copyFrom(widget.newShippingAddress().toJSON(), widget.shippingCountriesPriceListGroup());
           
            $.Topic(pubsub.topicNames.USER_PROFILE_UPDATE_SUBMIT).publishWith(widget.user(), [{message: "success"}]);
            
          }
          else {
            widget.user().shippingAddressBook.push(widget.newShippingAddress());
            widget.shippingAddressBook.push(widget.newShippingAddress());
          }
           if (widget.useAsBillingAddress() && widget.checkIfSelectedShipCountryInBillCountries()) {
            // Need to inform interested parties that any previous
            // billing address is no longer current
            $.Topic(pubsub.topicNames.CHECKOUT_BILLING_ADDRESS).publishWith(
                widget.newShippingAddress(), [{
                message: "success"
              }]);
          }
          // widget.newShippingAddress().reset();
          $('#addNewAddress').hide();
        //   widget.destroySpinner();
        //   $('#addNewAddressModal').hide();
         
          //widget.selectAddress(widget.newShippingAddress(), widget.shippingGroupForAddressBook);
        };

        widget.shippingAddressDuringPaypalCheckout = function(paypalShippingAddress) {
          var shippingAddress = new Address('user-paypal-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
          if (paypalShippingAddress && (widget.cart().items().length > 0) && widget.order().isPaypalVerified()) {
            // Check if checkout address (without any shipping method) exists in local storage. If exists then ovewrite the PayPal's address with this address
            var checkoutAddressWithoutShippingMethod = storageApi.getInstance().getItem("checkoutAddressWithoutShippingMethod");
            if (checkoutAddressWithoutShippingMethod) {
              paypalShippingAddress = JSON.parse(checkoutAddressWithoutShippingMethod);
              storageApi.getInstance().removeItem("checkoutAddressWithoutShippingMethod");
            }
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(paypalShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          } else if (widget.user().loggedIn() === true && widget.user().updatedShippingAddress && (widget.cart().items().length > 0)) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(widget.user().updatedShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          }
          widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
          widget.cart().shippingAddress(widget.order().shippingAddress());
          $.Topic(pubsub.topicNames.PAYPAL_SHIPPING_ADDRESS_ALTERED).publish();
          widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.PAYPAL_CHECKOUT_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringPaypalCheckout.bind(this));

        widget.shippingAddressDuringWebCheckout = function(webShippingAddress) {
          var shippingAddress = new Address('user-web-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
          if (webShippingAddress && (widget.cart().items().length > 0)) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(webShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          }
          widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
          widget.addressSetAfterWebCheckout(true);
          widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.WEB_CHECKOUT_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringWebCheckout.bind(this));

        widget.shippingAddressDuringLoadOrder = function(loadOrderShippingAddress) {
          var shippingAddress = new Address('loaded-order-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
          if (loadOrderShippingAddress && (widget.cart().items().length > 0)) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(loadOrderShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          }
          widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
          widget.addressSetAfterOrderLoad(true);
          widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.LOADED_ORDER_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringLoadOrder.bind(this));


        $.Topic(pubsub.topicNames.USER_SESSION_EXPIRED).subscribe(function() {
          widget.isUsingSavedAddress(false);
        });
        

      },

      onLoadForB2BUser: function (widget) {
        // widget.shippingAddressSelected(false);
        widget.addShippingAddressTo.subscribe(function(){
          if(widget.addShippingAddressTo()===CCConstants.PROFILE_ADDRESSES_TYPE){
            widget.newShippingAddress().saveToAccount(false);
          }else if(widget.addShippingAddressTo()===CCConstants.ACCOUNT_ADDRESSES_TYPE){
            widget.newShippingAddress().saveToAccount(true);
          }
        });

        widget.confirmUnsavedChangesSelectNewAddress = function(elementId, widget, address, type){
          if(elementId.indexOf("cc-checkout-select-shipping-address-account") > -1){
            widget.currentShippingAddressSelection(CCConstants.ACCOUNT_ADDRESSES_TYPE);
          }else if(elementId.indexOf("cc-checkout-select-shipping-address-profile") > -1){
            widget.currentShippingAddressSelection(CCConstants.PROFILE_ADDRESSES_TYPE);
          }else if(elementId.indexOf("cc-checkout-select-shipping-address-inherit") > -1){
            widget.currentShippingAddressSelection(CCConstants.INHERITED_ADDRESSES);
          }
          if(elementId.indexOf("cc-checkout-select-shipping-address") > -1){
            if (type) {
              address.type(type);
            }
            widget.selectAddress(address);
          }

        };

        widget.addShippingAddress = function(obj){
          var saveToProfileUrl = CCConstants.END_POINT_ADD_PROFILE_ADDRESS;
          var saveToAccountUrl = CCConstants.END_POINT_ADD_ADDRESSES;
          var url;
          if(widget.addShippingAddressTo() !==null){
            var data={};
            var shippingAddressData = widget.newShippingAddress();
            data[CCConstants.ORG_ADDRESS_TYPE] = shippingAddressData.type();
            var address = {};
            address[CCConstants.PROFILE_FIRST_NAME]=widget.user().firstName();
            address[CCConstants.PROFILE_LAST_NAME]=widget.user().lastName();
            address[CCConstants.ORG_ADDRESS_1]= shippingAddressData.address1();
            address[CCConstants.ORG_ADDRESS_2]= shippingAddressData.address2();
            address[CCConstants.ORG_CITY]= shippingAddressData.city();
            if(widget.user().isB2BUser() && widget.user().currentOrganization()){
                address[CCConstants.ORG_COMPANY_NAME]= widget.user().currentOrganization().name;
            }else
            {
                address[CCConstants.ORG_COMPANY_NAME]='';
            }
            address[CCConstants.ORG_COUNTRY]= shippingAddressData.selectedCountry();
            (shippingAddressData.phoneNumber()===''?address[CCConstants.ORG_PHONE_NUMBER]=null:address[CCConstants.ORG_PHONE_NUMBER]= shippingAddressData.phoneNumber());
            address[CCConstants.ORG_POSTAL_CODE]= shippingAddressData.postalCode();
            address[CCConstants.ORG_STATE]= shippingAddressData.selectedState();
            if(ccRestClient.profileType == CCConstants.PROFILE_TYPE_AGENT &&
                shippingAddressData.dynamicProperties && shippingAddressData.dynamicProperties().length > 0){
                  shippingAddressData.dynamicProperties().forEach(function(dynamicProperty){
                    address[dynamicProperty.id()] = dynamicProperty.value();
                  });
            }
            data[CCConstants.ORG_ADDRESS]= address;
            if(widget.addShippingAddressTo()===CCConstants.PROFILE_ADDRESSES_TYPE){
              url = saveToProfileUrl;
            }else{
              url = saveToAccountUrl;
            }
            ccRestClient.request(url, data, widget.addToAddressBook, null);
          }
        }
        
        
        
        widget.selectedContact = function(data,type)
        {
           
            if(type === "Main")
            {
                //widget.order().mainContact(widget.mainContact());
            }
            else if(type === "Shipping"){
                widget.order().shippingAddress().firstName(widget.shippingContact().firstName());
                widget.order().shippingAddress().lastName(widget.shippingContact().lastName());
            }
            else if(type === "Billing"){
                widget.order().billingAddress().firstName(widget.billingContact().firstName());
                widget.order().billingAddress().lastName(widget.billingContact().lastName());
            }
        }
        widget.addToAddressBook = function(data) {
          var addTo = "";
          var id = ""
          if (widget.addShippingAddressTo() == CCConstants.PROFILE_ADDRESSES_TYPE) {
            addTo = widget.profileAddressBook;
            id = "profile-address";
            //widget.selectAddress(widget.newShippingAddress(),widget.profileAddressBook);
          } else if (widget.addShippingAddressTo() == CCConstants.ACCOUNT_ADDRESSES_TYPE) {
            addTo = widget.accountAddressBook;
            id = "account-address"
            var organizationAddress = new Address('user-saved-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
            organizationAddress.countriesList(widget.shippingCountriesPriceListGroup());
            organizationAddress.copyFrom(data.address, widget.shippingCountriesPriceListGroup());
            //// Save shipping address JS object to Address object.
            //organizationAddress.resetModified();
            
            //organizationAddresses.push(organizationAddress);
            widget.organizationAddressBook.unshift(organizationAddress);
            widget.order().shippingAddress(widget.organizationAddressBook()[0]);
            widget.shippingAddressBook.push(widget.organizationAddressBook()[0]);

            //widget.selectAddress(widget.newShippingAddress(),widget.accountAddressBook);
          }

          if (addTo) {
            var data = {items: [data]};
            widget.createAddresses(id, data, addTo);
          }
          if (widget.useAsBillingAddress() && widget.checkIfSelectedShipCountryInBillCountries()) {
            // Need to inform interested parties that any previous
            // billing address is no longer current
            $.Topic(pubsub.topicNames.CHECKOUT_BILLING_ADDRESS).publishWith(
              widget.newShippingAddress(), [{
                message: "success"
              }]);
          }
          $('#addNewAddress').hide();
        }

        widget.shippingAddressDuringPaypalCheckout = function(paypalShippingAddress) {
          var shippingAddress = new Address('user-paypal-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
          if (paypalShippingAddress && (widget.cart().items().length > 0) && widget.order().isPaypalVerified()) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(paypalShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          } else if (widget.user().loggedIn() === true && widget.user().updatedShippingAddress && (widget.cart().items().length > 0)) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(widget.user().updatedShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          }
          widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
          widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.PAYPAL_CHECKOUT_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringPaypalCheckout.bind(this));

        widget.shippingAddressDuringLoadOrder = function(loadOrderShippingAddress) {

            var shippingAddress = new Address('loaded-order-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
            if (loadOrderShippingAddress && (widget.cart().items().length > 0)) {
              // Save shipping address JS object to Address object.
              shippingAddress.copyFrom(loadOrderShippingAddress, widget.shippingCountriesPriceListGroup());
              shippingAddress.resetModified();
            }

            widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
            widget.addressSetAfterOrderLoad(true);
           for (var k = 0; k < widget.organizationAddressBook().length; k++) {
              if(widget.organizationAddressBook()[k].compareTo(widget.order().shippingAddress())){
              widget.selectedShippingAddressId(widget.organizationAddressBook()[k].repositoryId);
              break;
              }
            }

            widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.LOADED_ORDER_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringLoadOrder.bind(this));

        widget.shippingAddressDuringWebCheckout = function(webShippingAddress) {
          var shippingAddress = new Address('user-web-shipping-address', widget.ErrorMsg, widget, widget.shippingCountriesPriceListGroup(), widget.defaultShippingCountry());
          if (webShippingAddress && (widget.cart().items().length > 0)) {
            // Save shipping address JS object to Address object.
            shippingAddress.copyFrom(webShippingAddress, widget.shippingCountriesPriceListGroup());
            shippingAddress.resetModified();
          }
          widget.order().shippingAddress().copyFrom(shippingAddress.toJSON(), widget.shippingCountriesPriceListGroup());
          widget.addressSetAfterWebCheckout(true);
          widget.destroySpinner();
        };

        //$.Topic(pubsub.topicNames.WEB_CHECKOUT_SHIPPING_ADDRESS).subscribe(widget.shippingAddressDuringWebCheckout.bind(this));
      }
    };
  }
);
