/**
 * @fileoverview Shopper Details Widget.
 *
 */
define(
  //-------------------------------------------------------------------
  // DEPENDENCIES
  //-------------------------------------------------------------------
  ['knockout', 'pubsub', 'navigation', 'notifier', 'ccConstants', 'CCi18n', 'swmRestClient','ccPasswordValidator'],
    
  //-------------------------------------------------------------------
  // MODULE DEFINITION
  //-------------------------------------------------------------------
  function (ko, PubSub, navigation, notifier, CCConstants, CCi18n, swmRestClient,CCPasswordValidator) {
  
    "use strict";
         var getWidget;
    return {
      
      WIDGET_ID:        "shopperDetails",
      ignoreBlur:   ko.observable(false),
      interceptedLink: ko.observable(null),
      isUserProfileInvalid: ko.observable(false),
      showSWM : ko.observable(true),
      isProfileLocaleNotInSupportedLocales : ko.observable(),
                  companyName:ko.observable(),
            			primaryBusinessArray: ko.observableArray([]),
			secondaryBusinessArray: ko.observableArray([]),
						employeeArray: ko.observableArray([]),
									revenueArray: ko.observableArray([]),
						
									noOfEmployees: ko.observable(),
           userName : ko.observable(""),
            customerId : ko.observable(""),
            userType : ko.observable(""),
            name : ko.observable(""),
            errormessage : ko.observable(""),
            email : ko.observable(""),
            homeNumber : ko.observable(""),
            password : ko.observable("**********"),
            currentPassword:ko.observable(),
            newPassword:ko.observable(),
            confirmNewPassword:ko.observable(),
            mobileNumber:ko.observable(),
           officeNumber:ko.observable(),
            

            preFix:ko.observable(),
            firstName:ko.observable(),
            lastName:ko.observable(),
            faxNumber:ko.observable(),
            4: ko.observable(),
            roleSelected: ko.observable(),
            receiveMails: ko.observable(),
            receiveEmails: ko.observable(false),
            receiveTexts: ko.observable(),
            receiveCatalogs: ko.observable(),
            selectedTitle: ko.observable(),
            title: ko.observable(),
			titleArray: ko.observableArray([]),
			rolesArray: ko.observableArray([]),
			
			annualRevenue: ko.observable(),
			secondaryBusiness: ko.observable(),
			primaryBusiness: ko.observable(),

      
      beforeAppear: function (page) {
         
        var widget = this;
        
        
         // Is user logged in?
        if (!getWidget.user().loggedIn() || getWidget.user().isUserSessionExpired()){
           
            setTimeout(function(){
                
                 $( document ).ready(function() {
                    $('#LoginModal').modal('show')
                 });
                
            }, 1000);
            
            return;
        }
            
        // Checks whether the user is logged in or not
        // If not the user is taken to the home page
        // and is asked to login.
        if (widget.user().loggedIn() == false) {
//          navigation.doLogin(navigation.getPath(), widget.links().home.route);
        } else if (widget.user().isSessionExpiredDuringSave()) {
          widget.user().isSessionExpiredDuringSave(false);
        } else {
                      //reset all the password detals
          widget.user().resetPassword();
          widget.user().isChangePassword(true);
          
          
          widget.showViewProfile(true);
          notifier.clearError(widget.WIDGET_ID);
          notifier.clearSuccess(widget.WIDGET_ID);
        }
        
        

        
        
        
      },
      
      onLoad: function(widget) {
        var self = this;
        
         getWidget = widget;
         
         // Handle user logout
        $.Topic(PubSub.topicNames.USER_LOGOUT_SUCCESSFUL).subscribe(function(obj) {
          
          setTimeout(function(){
                
                 $( document ).ready(function() {
                    $('#LoginModal').modal('show')
                 });
                
            }, 2000);
            
        });
        
        // Handle session expired
        $.Topic(PubSub.topicNames.USER_SESSION_EXPIRED).subscribe(function(obj) {
          
          setTimeout(function(){
                
                 $( document ).ready(function() {
                    $('#LoginModal').modal('show')
                 });
                
            }, 2000);
            
        });
         

           var len=getWidget.user().dynamicProperties().length;
        
        for(var i=0;i<len;i++){
  
  if(getWidget.user().dynamicProperties()[i].id()=="home_phone_number"){
      getWidget.homeNumber(getWidget.user().dynamicProperties()[i].value());
      
  }
    if(getWidget.user().dynamicProperties()[i].id()=="mobile_number"){
      getWidget.mobileNumber(getWidget.user().dynamicProperties()[i].value());      
  }
    if(getWidget.user().dynamicProperties()[i].id()=="name_title"){
      getWidget.selectedTitle(getWidget.user().dynamicProperties()[i].value());      
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_mailings_special_offers"){
      getWidget.receiveMails(getWidget.user().dynamicProperties()[i].value());      
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_texts"){
      getWidget.receiveTexts(getWidget.user().dynamicProperties()[i].value());      
  }
  if(getWidget.user().dynamicProperties()[i].id()=="receive_catalog"){
      getWidget.receiveCatalogs(getWidget.user().dynamicProperties()[i].value());      
  }
      if(getWidget.user().dynamicProperties()[i].id()=="office_number"){
          getWidget.officeNumber(getWidget.user().dynamicProperties()[i].value());      
//      getWidget.homeNumber(getWidget.user().dynamicProperties()[i].value());      
  }
        if(getWidget.user().dynamicProperties()[i].id()=="fax_number"){
      getWidget.faxNumber(getWidget.user().dynamicProperties()[i].value());      
  }
          if(getWidget.user().dynamicProperties()[i].id()=="org_role"){
      getWidget.roleSelected(getWidget.user().dynamicProperties()[i].value());      
  }
  
          if(getWidget.user().dynamicProperties()[i].id()=="position_title"){
      getWidget.title(getWidget.user().dynamicProperties()[i].value());      
  }  
  
  
  
  
  
  
  
  
  

        }

         
         
         
         
         
         
         
         
         
         
         
    				widget.primaryBusiness.subscribe(function (newValue) {
					widget.secondaryBusinessArray([]);
					if (newValue === "Meat & Meat Products" || newValue === "Poultry & Poultry Products") {
						widget.secondaryBusinessArray.push('Harvest/Slaughter', 'Further Processing', 'Custom Slaughter/Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Fish & Fish Products" || newValue === "Bread & Bakery" || newValue === "Snacks - Candy/Nut/Other" || newValue === "Restaurants & Country Clubs" || newValue === "Grocery Store" || newValue === "Pet Food") {
						widget.secondaryBusinessArray.push('Harvest/Slaughter', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Dairy & Dairy Products") {
						widget.secondaryBusinessArray.push('Production', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Farms - General/Crop" || newValue === "Fruits & Vegetables") {
						widget.secondaryBusinessArray.push('Production', 'Harvest', 'Further Processing', 'Retail', 'Wholesaler', 'Co-Packer', 'Other');
					} else if (newValue === "Schools - Elementary/Secondary/College" || newValue === "Medical - Offices/Hospitals/Manufacturers" || newValue === "Correctional Institutions" || newValue === "Other") {
						widget.secondaryBusinessArray([]);

					}
				});
				self.titleArray.push('', 'Mr.', 'Mrs.', 'Ms.','Miss.','Dr.');
				self.rolesArray.push('Engineering', 'Finance/Legal', 'Maintenance', 'Management', 'OHSE', 'Operations/Production', 'Other', 'Purchasing', 'Sales');
				
				self.employeeArray.push(' 1 - 10', ' 11 - 25', ' 26 - 50', ' 51 - 100', ' 51 - 100', ' 151 - 200', ' 251 - 500', ' 500+');
				self.revenueArray.push('$0-$500k', '$500k-$1M', '$1M-$2.5M', '$2.5M-$5M', '$5M-$10M', '$10M-$25M', '$25M-$50M', '$50M+');
				self.primaryBusinessArray.push('Meat & Meat Products', 'Poultry & Poultry Products', 'Fish & Fish Products', 'Dairy & Dairy Products', 'Farms - General/Crop', 'Fruits & Vegetables', 'Bread & Bakery', 'Snacks - Candy/Nut/Other', 'Restaurants & Country Clubs', 'Grocery Store', 'Pet Food', 'Schools - Elementary/Secondary/College', 'Medical - Offices/Hospitals/Manufacturers', 'Correctional Institutions', 'Other');
				
        
        var isModalVisible = ko.observable(false);
        var clickedElementId = ko.observable(null);
        var isModalSaveClicked = ko.observable(false);
        
        
        
                widget.showViewProfile = function (refreshData) {
          // Fetch data in case it is modified or requested to reload.
          // Change all div tags to view only.
          if(refreshData) {
            widget.user().getCurrentUser(false);
          }
        };

        /**
         * Ignores password validation when the input field is focused.
         */
        widget.passwordFieldFocused = function(data, event) {
          if (this.ignoreBlur && this.ignoreBlur()) {
            return true;
          }
          this.user().ignorePasswordValidation(true);
          this.user().isUserProfileEdited(true);
          return true;
        };

        /**
         * Password is validated when the input field loses focus (blur).
         */
        widget.passwordFieldLostFocus = function(data, event) {
          if (this.ignoreBlur && this.ignoreBlur()) {
            return true;
          }
          this.user().ignorePasswordValidation(false);        
          return true;
        };
        
        widget.inputFieldFocused = function(data, event) {
        	this.user().isUserProfileEdited(true);
        	return true;
        };

        /**
         * Ignores confirm password validation when the input field is focused.
         */
        widget.confirmPwdFieldFocused = function(data, event) {
          if (this.ignoreBlur && this.ignoreBlur()) {
            return true;
          }
          this.user().isUserProfileEdited(true);
          this.user().ignoreConfirmPasswordValidation(true);
          return true;
        };

        /**
         * Confirm password is validated when the input field loses focus (blur).
         */
        widget.confirmPwdFieldLostFocus = function(data, event) {
          if (this.ignoreBlur && this.ignoreBlur()) {
            return true;
          }
          this.user().ignoreConfirmPasswordValidation(false);
          return true;
        };

        /**
         * Ignores the blur function when mouse click is up
         */
        widget.handleMouseUpP = function() {
            this.ignoreBlur(false);
            this.user().ignoreConfirmPasswordValidation(false);
            return true;
          };
          
          /**
           * Ignores the blur function when mouse click is down
           */
          widget.handleMouseDown = function() {
            this.ignoreBlur(true);
            this.user().ignoreConfirmPasswordValidation(true);
            return true;
          };
          
        widget.hideModal = function () {
          if(isModalVisible() || widget.user().isSearchInitiatedWithUnsavedChanges()) {
            $("#CC-customerProfile-modal-2").modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
          }
        };
        
        widget.showModal = function () {
          $("#CC-customerProfile-modal-2").modal('show');
          isModalVisible(true);
        };
        
        // Handle cancel update.
        widget.handleCancelUpdateForUpdatePassword = function () {
          widget.showViewProfile(true);
          widget.user().resetPassword();
          notifier.clearError(widget.WIDGET_ID);
          notifier.clearSuccess(widget.WIDGET_ID);
          widget.hideModal();
          widget.user().isUserProfileEdited(false)
        };
        
        // Discards user changes and navigates to the clicked link.
        widget.handleModalCancelUpdateDiscard = function () {
          widget.handleCancelUpdateForUpdatePassword();
          if ( widget.user().isSearchInitiatedWithUnsavedChanges() ) {
            widget.hideModal();
            widget.user().isSearchInitiatedWithUnsavedChanges(false);
            widget.user().isUserProfileEdited(false);
          }
          else {
          	widget.user().isUserProfileEdited(false);
//            widget.navigateAway();
          }
        };
        
        // Handles User profile update for password change
        widget.handleUpdateProfileForUpdatePassword = function () {
          // Sends message for update
          $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_SUBMIT).publishWith(widget.user(), [{message: "success"}]);
        };
        
        // Handles User profile update for password change and navigates to the clicked link.
        widget.handleModalUpdateProfile = function () {
          isModalSaveClicked(true);
          if ( widget.user().isSearchInitiatedWithUnsavedChanges() ) {
            widget.handleUpdateProfileForUpdatePassword();
            widget.hideModal();
            widget.user().isSearchInitiatedWithUnsavedChanges(false);
            return;
          }
          if (clickedElementId != "CC-loginHeader-myAccount") {
            widget.user().delaySuccessNotification(true);
          }
          widget.handleUpdateProfileForUpdatePassword();
        };
        
        
       // Handles if data does not change. 
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_NOCHANGE).subscribe(function() {
          // Resetting profile.
          widget.showViewProfile(false);
          // Hide the modal.
          widget.hideModal();
        });

        //handle if the user logs in with different user when the session expiry prompts to relogin
        $.Topic(PubSub.topicNames.USER_PROFILE_SESSION_RESET).subscribe(function() {
          // Resetting profile.
          widget.showViewProfile(false);
          // Hide the modal.
          widget.hideModal();
        });
        
        // Handles if data is invalid.
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_INVALID).subscribe(function() {
    //      notifier.sendError(widget.WIDGET_ID, widget.ErrorMsg, true);
          
            getWidget.errormessage(widget.ErrorMsg);
             $('#Error-Modal1').modal('show')
          
          if (isModalSaveClicked()) {
            widget.isUserProfileInvalid(true);
            isModalSaveClicked(false);
          }
          widget.user().delaySuccessNotification(false);
          // Hide the modal.
          widget.hideModal();
        });
        
        // Handles if user profile update is saved.
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_SUCCESSFUL).subscribe(function() {
          widget.showViewProfile(true);
          // Clears error message.
          notifier.clearError(widget.WIDGET_ID);
          notifier.clearSuccess(widget.WIDGET_ID);
          if (!widget.user().delaySuccessNotification()) {
//            notifier.sendSuccess(widget.WIDGET_ID, widget.translate('updateSuccessMsg'), true);
          }
          widget.hideModal();
          widget.user().isUserProfileEdited(false);
          if (isModalSaveClicked()) {
            isModalSaveClicked(false);
//            widget.navigateAway();
          }
          $.Topic(PubSub.topicNames.DISCARD_ADDRESS_CHANGES).publish();
        });
        
        // Handles if user profile update is failed.
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_FAILURE).subscribe(function(data) {
          if (isModalSaveClicked()) {
            widget.isUserProfileInvalid(true);
            isModalSaveClicked(false);
          }
          widget.user().delaySuccessNotification(false);
          // Hide the modal.
          widget.hideModal();
          if (data.status == CCConstants.HTTP_UNAUTHORIZED_ERROR) {
            widget.user().isSessionExpiredDuringSave(true);
//            navigation.doLogin(navigation.getPath());
          } else {
            var msg = widget.passwordErrorMsg;
            notifier.clearError(widget.WIDGET_ID);
            notifier.clearSuccess(widget.WIDGET_ID);
            if (data.errorCode == CCConstants.USER_PROFILE_OLD_PASSWORD_INCORRECT) {
              $('#CC-customerProfile-soldPassword-phone-error-1').css("display", "block");
              $('#CC-customerProfile-soldPassword-phone-error-1').text(data.message);
              $('#CC-customerProfile-soldPassword-phone').addClass("invalid");
              $('#CC-customerProfile-spassword1-error-1').css("display", "block");
              $('#CC-customerProfile-spassword1-error-1').text(data.message);
              $('#CC-customerProfile-soldPassword-1').addClass("invalid");
            } else if (data.errorCode == CCConstants.USER_PROFILE_PASSWORD_POLICIES_ERROR) {
              $('#CC-customerProfile-spassword-error-1').css("display", "block");
              $('#CC-customerProfile-spassword-error-1').text(CCi18n.t('ns.common:resources.passwordPoliciesErrorText'));
              $('#CC-customerProfile-spassword-1').addClass("invalid");
              $('#CC-customerProfile-spassword-embeddedAssistance-1').css("display", "block");
              var embeddedAssistance = CCPasswordValidator.getAllEmbeddedAssistance(widget.passwordPolicies(), true);
              $('#CC-customerProfile-spassword-embeddedAssistance-1').text(embeddedAssistance);
            } else if (data.errorCode === CCConstants.USER_PROFILE_INTERNAL_ERROR) {
              msg = data.message;
              // Reloading user profile and shipping data in edit mode.
              widget.user().getCurrentUser(false);
              widget.reloadShipping();
            } 
             else {
              msg = data.message;
            }
        //    notifier.sendError(widget.WIDGET_ID, msg, true);
            widget.hideModal();
          }
          $.Topic(PubSub.topicNames.DISCARD_ADDRESS_CHANGES).publish();
        });
        
        $.Topic(PubSub.topicNames.UPDATE_USER_LOCALE_NOT_SUPPORTED_ERROR).subscribe(function() {
          widget.isProfileLocaleNotInSupportedLocales(true);
        });
        
        /**
         *  Navigates window location to the interceptedLink OR clicks checkout/logout button explicitly.
         */
        widget.navigateAway = function() {

          if (clickedElementId === "CC-header-checkout" || clickedElementId === "CC-loginHeader-logout" || clickedElementId === "CC-customerAccount-view-orders" 
              || clickedElementId === "CC-header-language-link" || clickedElementId.indexOf("CC-header-languagePicker") != -1) {
            widget.removeEventHandlersForAnchorClick();
            widget.showViewProfile(false);
            // Get the DOM element that was originally clicked.
            var clickedElement = $("#"+clickedElementId).get()[0];
            clickedElement.click();
          } else if (clickedElementId === "CC-loginHeader-myAccount") {
            // Get the DOM element that was originally clicked.
            var clickedElement = $("#"+clickedElementId).get()[0];
            clickedElement.click();
          } else {
            if (!navigation.isPathEqualTo(widget.interceptedLink)) {
//              navigation.goTo(widget.interceptedLink);
              widget.removeEventHandlersForAnchorClick();
            }
          }
        };
        
        // handler for anchor click event.
        var handleUnsavedChanges = function(e, linkData) {
          var usingCCLink = linkData && linkData.usingCCLink;
          
          widget.isProfileLocaleNotInSupportedLocales(false);
          // If URL is changed explicitly from profile.
//          if(!usingCCLink && !navigation.isPathEqualTo(widget.links().profile.route)) {
//            widget.showViewProfile(false);
//            widget.removeEventHandlersForAnchorClick();
//            return true;
//          }
          if (widget.user().loggedIn()) {
            clickedElementId = this.id;
            widget.interceptedLink = e.currentTarget.pathname;
            if (widget.user().isUserProfileEdited()) {
              widget.showModal();
              usingCCLink && (linkData.preventDefault = true);
              return false;
            }
            else {
              widget.showViewProfile(false);
            }
          }
        };
        
        var controlErrorMessageDisplay = function(e) {
          widget.isProfileLocaleNotInSupportedLocales(false);
        };
        
        /**
         *  Adding event handler for anchor click.
         */
        widget.addEventHandlersForAnchorClick = function() {
          $("body").on("click.cc.unsaved","a",handleUnsavedChanges);
          $("body").on("mouseleave", controlErrorMessageDisplay);
        };
        
        /**
         *  removing event handlers explicitly that has been added when anchor links are clicked.
         */
        widget.removeEventHandlersForAnchorClick = function(){
          $("body").off("click.cc.unsaved","a", handleUnsavedChanges);
        };
        
        
        
        
        
        
        
        
        
        
        widget.ErrorMsg = widget.translate('updateErrorMsg');
        widget.passwordErrorMsg = widget.translate('passwordUpdateErrorMsg');
        
        widget.getProfileLocaleDisplayName = function() {
          //Return the display name of profile locale
          for (var i=0; i<widget.user().supportedLocales.length; i++) {
            if (widget.user().locale() === widget.user().supportedLocales[i].name) {
              return widget.user().supportedLocales[i].displayName; 
            }
          }
        };
        
        //returns the edited locale to be displayed in non-edit mode
        widget.getFormattedProfileLocaleDisplayName = function(item) {
          return item.name.toUpperCase() + ' - ' + item.displayName;
        };
        

        /**
         * Ignores the blur function when mouse click is up
         */
        widget.handleMouseUp = function() {
            this.ignoreBlur(false);
            return true;
          };
          
          /**
           * Ignores the blur function when mouse click is down
           */
          widget.handleMouseDown = function() {
            this.ignoreBlur(true);
            return true;
          };
          
        widget.hideModal = function () {
          if(isModalVisible() || widget.user().isSearchInitiatedWithUnsavedChanges()) {
            $("#CC-customerProfile-modal-1").modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
          }
        };
        
        widget.showModal = function () {
          $("#CC-customerProfile-modal-1").modal('show');
          isModalVisible(true);
        };
        
        // Handle cancel update.
        widget.handleCancelUpdateForShopperDetails = function () {
          widget.showViewProfile(true);
          notifier.clearError(widget.WIDGET_ID);
          notifier.clearSuccess(widget.WIDGET_ID);
          widget.hideModal();
          this.user().isUserProfileEdited(false);
        };
        
        // Discards user changes and navigates to the clicked link.
        widget.handleModalCancelUpdateDiscard = function () {
          widget.handleCancelUpdateForShopperDetails();
          if ( widget.user().isSearchInitiatedWithUnsavedChanges() ) {
            widget.hideModal();
            widget.user().isSearchInitiatedWithUnsavedChanges(false);
          }
          else {
            widget.navigateAway();
          }
        };
         
        // Handles User profile update for account details
        widget.handleUpdateProfileForShopperDetails = function () {
            // Sends message for update
            
            if(getWidget.userType==="individual"){
                
                
                
            }
            else if(getWidget.userType==="business"){
                
            }
            else if(getWidget.userType==="distributor"){
                
            }
            else{}
            
            
            



            
        var len=getWidget.user().dynamicProperties().length;
        
        for(var i=0;i<len;i++){
            
        
              if(getWidget.user().dynamicProperties()[i].id()=="home_phone_number"){
//      getWidget.homeNumber(getWidget.user().dynamicProperties[i].value);
      widget.user().dynamicProperties()[i].value(getWidget.homeNumber());
      
  }
  if(getWidget.user().dynamicProperties()[i].id()=="mobile_number"){
//      getWidget.mobileNumber(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.mobileNumber());
  }
    if(getWidget.user().dynamicProperties()[i].id()=="name_title"){
     // getWidget.preFix(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.selectedTitle());
  }
      if(getWidget.user().dynamicProperties()[i].id()=="receive_mailings_special_offers"){
   //   getWidget.receiveMails(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.receiveMails());
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_texts"){
  //    getWidget.receiveTexts(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.receiveTexts());
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_catalog"){
  //    getWidget.receiveTexts(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.receiveCatalogs());
  }
  
  
    if(getWidget.user().dynamicProperties()[i].id()=="office_number"){
 //     getWidget.homeNumber(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.officeNumber());
  }
        if(getWidget.user().dynamicProperties()[i].id()=="fax_number"){
  //    getWidget.faxNumber(getWidget.user().dynamicProperties[i].value);
      widget.user().dynamicProperties()[i].value(getWidget.faxNumber());
  }
  
          if(getWidget.user().dynamicProperties()[i].id()=="org_role"){
               widget.user().dynamicProperties()[i].value(getWidget.roleSelected());
  }
  
            if(getWidget.user().dynamicProperties()[i].id()=="position_title"){
             widget.user().dynamicProperties()[i].value(getWidget.title());
  }  
  
  
  
  
  
  
  
        }
/*    
    if(getWidget.user().dynamicProperties()[i].id()=="name_title"){
     // getWidget.preFix(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.preFix());
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_mailings_special_offers"){
   //   getWidget.receiveMails(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.receiveMails());
  }
    if(getWidget.user().dynamicProperties()[i].id()=="receive_texts"){
  //    getWidget.receiveTexts(getWidget.user().dynamicProperties[i].value);      
      widget.user().dynamicProperties()[i].value(getWidget.receiveTexts());
  }
//      if(getWidget.user().dynamicProperties[i].id=="office_number"){
 //     getWidget.homeNumber(getWidget.user().dynamicProperties[i].value);      
   //   widget.user().dynamicProperties[i].value=getWidget.homeNumber();
 // }
//        if(getWidget.user().dynamicProperties[i].id=="fax_number"){
//      getWidget.faxNumber(getWidget.user().dynamicProperties[i].value);
  //    widget.user().dynamicProperties[i].value=getWidget.homeNumber();
 // }
            
            
        }

            
  */          
            
            
            
            
            
            
            
            
            
            
            $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_SUBMIT).publishWith(widget.user(), [{message: "success"}]);
            
    //        $('#CC-Email-Modal').modal('show')
        };
        
        // Handles User profile update for account details and navigates to the clicked link.
        widget.handleModalUpdateProfile = function () {
          isModalSaveClicked(true);
          if ( widget.user().isSearchInitiatedWithUnsavedChanges() ) {
            widget.handleUpdateProfileForShopperDetails();
            widget.hideModal();
            widget.user().isSearchInitiatedWithUnsavedChanges(false);
            return;
          }
          if (clickedElementId != "CC-loginHeader-myAccount") {
            widget.user().delaySuccessNotification(true);
          }
          widget.handleUpdateProfileForShopperDetails();
        };
        
        
       // Handles if data does not change. 
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_NOCHANGE).subscribe(function() {
          // Resetting profile.
          widget.showViewProfile(false);
          // Hide the modal.
          widget.hideModal();
          widget.user().isUserProfileEdited(false);
        });

        //handle if the user logs in with different user when the session expiry prompts to relogin
        $.Topic(PubSub.topicNames.USER_PROFILE_SESSION_RESET).subscribe(function() {
          // Resetting profile.
          widget.showViewProfile(false);
          // Hide the modal.
          widget.hideModal();
          this.user().isUserProfileEdited(false);
        });
        

        // Handles if user profile update is saved.
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_SUCCESSFUL).subscribe(function() {
          // update user in Social module
        	widget.user().isUserProfileEdited(false);
          if (widget.displaySWM) {
            var successCB = function(result){
              $.Topic(PubSub.topicNames.SOCIAL_SPACE_SELECT).publish();
              $.Topic(PubSub.topicNames.SOCIAL_SPACE_MEMBERS_INFO_CHANGED).publish();
            };
            var errorCB = function(response, status, errorThrown){};
            
            var json = {};
            if (widget.user().emailMarketingMails()) {
              json = {
                firstName : widget.user().firstName()
                , lastName : widget.user().lastName()
              };
            }
            else {
              json = {
	                firstName : widget.user().firstName()
	                , lastName : widget.user().lastName()
	                , notifyCommentFlag : '0'
                  , notifyNewMemberFlag : '0'
	            };
	          }
	          
            swmRestClient.request('PUT', '/swm/rs/v1/sites/{siteid}/users/{userid}', json, successCB, errorCB, {
              "userid" : swmRestClient.apiuserid
            });
          }
          
          widget.showViewProfile(true);
          // Clears error message.
          notifier.clearError(widget.WIDGET_ID);
          notifier.clearSuccess(widget.WIDGET_ID);
          if (!widget.user().delaySuccessNotification()) {
//            notifier.sendSuccess(widget.WIDGET_ID, widget.translate('updateSuccessMsg'), true);
          }
          widget.hideModal();
          if (isModalSaveClicked()) {
            isModalSaveClicked(false);
//            widget.navigateAway();

          }
          $.Topic(PubSub.topicNames.DISCARD_ADDRESS_CHANGES).publish();
          
          
          
          $('#Save-Modal').modal('show');
          
        });
        
        // Handles if user profile update is failed.
        $.Topic(PubSub.topicNames.USER_PROFILE_UPDATE_FAILURE).subscribe(function(data) {
          if (isModalSaveClicked()) {
            widget.isUserProfileInvalid(true);
            isModalSaveClicked(false);
          }
          widget.user().delaySuccessNotification(false);
          // Hide the modal.
          widget.hideModal();
          if (data.status == CCConstants.HTTP_UNAUTHORIZED_ERROR) {
            widget.user().isSessionExpiredDuringSave(true);
//            navigation.doLogin(navigation.getPath());
          } else {
            var msg = widget.passwordErrorMsg;
            notifier.clearError(widget.WIDGET_ID);
            notifier.clearSuccess(widget.WIDGET_ID);
            if (data.errorCode === CCConstants.USER_PROFILE_INTERNAL_ERROR) {
              msg = data.message;
              // Reloading user profile and shipping data in edit mode.
              widget.user().getCurrentUser(false);
            } 
            else {
              msg = data.message;
            }
         getWidget.errormessage(msg);          
             $('#Error-Modal').modal('show')
  
//            notifier.sendError(widget.WIDGET_ID, msg, true);
            widget.hideModal();
          }
          $.Topic(PubSub.topicNames.DISCARD_ADDRESS_CHANGES).publish();
        });
        
        $.Topic(PubSub.topicNames.UPDATE_USER_LOCALE_NOT_SUPPORTED_ERROR).subscribe(function() {
          widget.isProfileLocaleNotInSupportedLocales(true);
        });
        
        /**
         *  Navigates window location to the interceptedLink OR clicks checkout/logout button explicitly.
         */
        widget.navigateAway = function() {

          if (clickedElementId === "CC-header-checkout" || clickedElementId === "CC-loginHeader-logout" || clickedElementId === "CC-customerAccount-view-orders" 
              || clickedElementId === "CC-header-language-link" || clickedElementId.indexOf("CC-header-languagePicker") != -1) {
            widget.removeEventHandlersForAnchorClick();
            widget.showViewProfile(false);
            // Get the DOM element that was originally clicked.
            var clickedElement = $("#"+clickedElementId).get()[0];
            clickedElement.click();
          } else if (clickedElementId === "CC-loginHeader-myAccount") {
            // Get the DOM element that was originally clicked.
            var clickedElement = $("#"+clickedElementId).get()[0];
            clickedElement.click();
          } else {
            if (!navigation.isPathEqualTo(widget.interceptedLink)) {
//              navigation.goTo(widget.interceptedLink);
              widget.removeEventHandlersForAnchorClick();
            }
          }
        };
        
        // handler for anchor click event.
        var handleUnsavedChanges = function(e, linkData) {
          var usingCCLink = linkData && linkData.usingCCLink;
          
          widget.isProfileLocaleNotInSupportedLocales(false);
          // If URL is changed explicitly from profile.
//          if(!usingCCLink && !navigation.isPathEqualTo(widget.links().profile.route)) {
//            widget.showViewProfile(false);
//            widget.removeEventHandlersForAnchorClick();
//            return true;
//          }
          if (widget.user().loggedIn()) {
            clickedElementId = this.id;
            widget.interceptedLink = e.currentTarget.pathname;
            if (widget.user().isUserProfileEdited()) {
              widget.showModal();
              usingCCLink && (linkData.preventDefault = true);
              return false;
            }
            else {
              widget.showViewProfile(false);
            }
          }
        };
        
        var controlErrorMessageDisplay = function(e) {
          widget.isProfileLocaleNotInSupportedLocales(false);
        };
        

        
        /**
         *  Adding event handler for anchor click.
         */
        widget.addEventHandlersForAnchorClick = function() {
          $("body").on("click.cc.unsaved","a",handleUnsavedChanges);
          $("body").on("mouseleave", controlErrorMessageDisplay);
        };
        
        /**
         *  removing event handlers explicitly that has been added when anchor links are clicked.
         */
        widget.removeEventHandlersForAnchorClick = function(){
          $("body").off("click.cc.unsaved","a", handleUnsavedChanges);
        };
      },
      			validatingData: function (data, event,user) {
				var self = data;
				  var label;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        console.log("data is null");	
    				
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }

				        



				    }else{
				        console.log("data is not null");
				        
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

				    }
				}
				return true;
        			},
        			
        			validatingPassword: function (data, event,user) {
        			    
	    				var self = data;
	    				 var label;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        console.log("data is null");	
    				   
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }

				        
				    }else{
				        console.log("data is not null");
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

				    }
				}
				return true;
				
        			    
        			},
        			
        			validatePassword: function (data, event) {
		    				    var label;
				if (event.target.value === "" || event.target.value === null) {
/*
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
*/				        
				} else {

    						event.target.style = "border: 2px solid #d3d3d3";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }
				        
				    
				}
        			},
        				validateHomePhoneNumber: function (data, event,user) {
        				    				    var label;
				if (event.target.value === "" || event.target.value === null) {
				    
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }

				} else {

					var number = ("" + event.target.value).replace(/\D/g, '');
					var token = number.match(/^(\d{3})(\d{3})(\d{4})$/);

					if (token !== null) {     //correct mobile number


				        if(user==="individual"){
				            document.getElementById("CC-userRegistration-homeNumber-individual-error").style = "display:none";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-homeNumber-business-error").style = "display:none";
				        }else{
				            document.getElementById("CC-userRegistration-homeNumber-distributor-error").style = "display:none";
				        }
				        

						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

					    
					    
					    
					    
					} else {    //invalid mobile number



						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }
				        
				        
				        
				        if(user==="individual"){
				            document.getElementById("CC-userRegistration-homeNumber-individual-error").style = "display:block";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-homeNumber-business-error").style = "display:block";
				        }else{
				            document.getElementById("CC-userRegistration-homeNumber-distributor-error").style = "display:block";
				        }
				        
				        
				        
				        
				        
				        
				        
				        


					}
				}
			},
			
			
			
			
			
			        				validateHomePhoneNumber1: function (data, event,user) {
				if (event.target.value === "" || event.target.value === null) {
				    
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

				} else {
				    var label;


						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

	//				getWidget.isInvalidHomePhoneNumber1(false);
					var number = ("" + event.target.value).replace(/\D/g, '');
					var token = number.match(/^(\d{3})(\d{3})(\d{4})$/);

					if (token !== null) {     //correct mobile number


				   if(user==="individual"){
				            document.getElementById("CC-userRegistration-mobileNumber-individual-error").style = "display:none";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-mobileNumber-business-error").style = "display:none";
				        }else{
				            document.getElementById("CC-userRegistration-mobileNumber-distributor-error").style = "display:none";
				        }
				        
				        
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

					    
					} else {    //invalid mobile number
					
					   if(user==="individual"){
				            document.getElementById("CC-userRegistration-mobileNumber-individual-error").style = "display:block";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-mobileNumber-business-error").style = "display:block";
				        }else{
				            document.getElementById("CC-userRegistration-mobileNumber-distributor-error").style = "display:block";
				        }
				        
				        
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }

					}
				}
			},
			      				validateHomePhoneNumber2: function (data, event,user) {
				if (event.target.value === "" || event.target.value === null) {
				    
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

				} else {
				    var label;


						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

	//				getWidget.isInvalidHomePhoneNumber1(false);
					var number = ("" + event.target.value).replace(/\D/g, '');
					var token = number.match(/^(\d{3})(\d{3})(\d{4})$/);

					if (token !== null) {     //correct mobile number

					   if(user==="individual"){
				            document.getElementById("CC-userRegistration-faxNumber-individual-error").style = "display:none";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-faxNumber-business-error").style = "display:none";
				        }else{
				            document.getElementById("CC-userRegistration-faxNumber-distributor-error").style = "display:none";
				        }
				        
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				        
				        }

					    
					} else {    //invalid mobile number
					
					   if(user==="individual"){
				            document.getElementById("CC-userRegistration-faxNumber-individual-error").style = "display:block";
				        }else if(user==="business"){
				            document.getElementById("CC-userRegistration-faxNumber-business-error").style = "display:block";
				        }else{
				            document.getElementById("CC-userRegistration-faxNumber-distributor-error").style = "display:block";
				        }
				        
				        
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";				        
				        }

					}
				}
			},
			
			submitButtonCompanyPassword: function(data,event){  
			    
			    var valid=true;
			     getWidget.userType("business");
			        	if ([null, undefined, ''].indexOf(event.oldPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-currentpassword-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-currentpassword-business").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.newPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-newpassword-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-newpassword-business").style = "border: 2px solid #f33";				        
		        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.confirmPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-confirmnewpassword-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-confirmnewpassword-business").style = "border: 2px solid #f33";				        
		        valid=false;
	}
	
	
				    	if(event.newPassword()!==event.confirmPassword()){
	    getWidget.errormessage("Confirm New Password  Mismatch");          
             $('#Error-Modal').modal('show')

	}else{
			if(valid){
	        document.getElementById("business-save-password").style = "display:none";				        			    
	getWidget.handleModalUpdateProfile();
	}else{
	        document.getElementById("business-save-password").style = "display:block";				        
	}
	}
	
	
			    
			},
			submitButtonCompany: function(data,event){
			    console.log("comapny");
			    var flag=true;
			     getWidget.userType("business");
	
	if ([null, undefined, ''].indexOf(event.firstName()) !== -1) {
    				        document.getElementById("CC-userRegistration-firstname-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-firstname-business").style = "border: 2px solid #f33";				      
    				        flag=false;
	}
		if ([null, undefined, ''].indexOf(event.lastName()) !== -1) {
    				        document.getElementById("CC-userRegistration-lastname-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-lastname-business").style = "border: 2px solid #f33";				        
				        flag=false;
	}
		if ([null, undefined, ''].indexOf(getWidget.officeNumber()) !== -1) {
    				        document.getElementById("CC-userRegistration-homeNumber-business-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-homeNumber-business").style = "border: 2px solid #f33";				        
					        flag=false;
	}
	
			    
			    	if(flag){
	    console.log("updating the profile information");
	        document.getElementById("business-save-profile").style = "display:none";				        
	getWidget.handleUpdateProfileForShopperDetails();
	}else{
	        document.getElementById("business-save-profile").style = "display:block";				        
	}	
	
	
	
	
			    
			},
			
			submitButtonBusinessPassword: function(data,event){  
	var valid=true;		    
			     getWidget.userType("distributor");
    	if ([null, undefined, ''].indexOf(event.oldPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-currentpassword-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-currentpassword-distributor").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.newPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-newpassword-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-newpassword-distributor").style = "border: 2px solid #f33";				        
		        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.confirmPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-confirmnewpassword-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-confirmnewpassword-distributor").style = "border: 2px solid #f33";				        
		        valid=false;
	}
	
	
			    	if(event.newPassword()!==event.confirmPassword()){
	    getWidget.errormessage("Confirm New Password  Mismatch");          
             $('#Error-Modal').modal('show')

	}else{
			if(valid){
	        document.getElementById("distributor-save-password").style = "display:none";
	getWidget.handleModalUpdateProfile();
	}else{
	        document.getElementById("distributor-save-password").style = "display:block";				        
	}
	}	    
			    
			    
			},
			submitButtonBusiness: function(data,event){
			    console.log("business");
			    getWidget.userType("distributor");
	var valid=true;		    
    	if ([null, undefined, ''].indexOf(event.firstName()) !== -1) {
    				        document.getElementById("CC-userRegistration-firstname-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-firstname-distributor").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.lastName()) !== -1) {
    				        document.getElementById("CC-userRegistration-lastname-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-lastname-distributor").style = "border: 2px solid #f33";				       
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(getWidget.homeNumber()) !== -1) {
    				        document.getElementById("CC-userRegistration-homeNumber-distributor-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-homeNumber-distributor").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
			    
			    	if(valid){
	    console.log("updating the profile information");
	        document.getElementById("distributor-save-profile").style = "display:none";

	getWidget.handleUpdateProfileForShopperDetails();
	}else{
	        document.getElementById("distributor-save-profile").style = "display:block";				        
	}
	
			    
			    

			    
			},
			
			submitButtonIndividualPassword: function(data,event){  
			    getWidget.userType("individual");
			    	    var valid=true;
			    			    
			        	if ([null, undefined, ''].indexOf(event.oldPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-currentpassword-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-currentpassword-individual").style = "border: 2px solid #f33";				        
 				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.newPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-newpassword-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-newpassword-individual").style = "border: 2px solid #f33";				        
 				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.confirmPassword()) !== -1) {
    				        document.getElementById("CC-userRegistration-confirmnewpassword-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-confirmnewpassword-individual").style = "border: 2px solid #f33";				        
 				        valid=false;
	}
	
	if(event.newPassword()!==event.confirmPassword()){
	    getWidget.errormessage("Confirm New Password  Mismatch");          
             $('#Error-Modal').modal('show')

	}else{
	
	if(valid){
	     document.getElementById("individual-save-password").style = "display:none";				        	    
	getWidget.handleModalUpdateProfile();
	}else{
	     document.getElementById("individual-save-password").style = "display:block";				        
	}
	}
			},
			submitButtonIndividual: function(data,event){
			    console.log("indiviual");
			    getWidget.userType("individual");
			    var valid=true;
	
	
		    	if ([null, undefined, ''].indexOf(event.firstName()) !== -1) {
    				        document.getElementById("CC-userRegistration-firstname-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-firstname-individual").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(event.lastName()) !== -1) {
    				        document.getElementById("CC-userRegistration-lastname-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-lastname-individual").style = "border: 2px solid #f33";				        
    				        valid=false;
	}
		if ([null, undefined, ''].indexOf(getWidget.homeNumber()) !== -1) {
    				        document.getElementById("CC-userRegistration-homeNumber-individual-label").style = "color:#f33";				        
    				        document.getElementById("CC-userRegistration-homeNumber-individual").style = "border: 2px solid #f33";				        
    				        valid=false;
	}

	
	if(valid){
	    console.log("updating the profile information");
	    document.getElementById("individual-save-profile").style = "display:none";

	getWidget.handleUpdateProfileForShopperDetails("individual");
	}else{
	     document.getElementById("individual-save-profile").style = "display:block";				        
	}
	
	
			    
			},
			
			
            BusinessManageAddress: function(){
                
     //           $('#myaccount-manage-info-business').show();

       //         $('#myaccount-preview-business').hide();
   navigation.goTo('/profile');

            },
           BusinessManageAddressBack: function(){
                
                                navigation.goTo('/myaccount');
//                $('#myaccount-manage-info-business').hide();

  //              $('#myaccount-preview-business').show();


            },
            
        CompanyManageAddress: function(){
                
        //        $('#myaccount-manage-info-company').show();

     //           $('#myaccount-preview-company').hide();
   navigation.goTo('/profile');
                
            },
          CompanyManageAddressBack: function(){
                
//                $('#myaccount-manage-info-company').hide();

  //              $('#myaccount-preview-company').show();
    
                    navigation.goTo('/myaccount');            
//                        navigation.goTo('/profile');

                
            },
            manageCompanyInformation: function(){
     //           $('#myaccount-manage-company-info').show();

           //     $('#myaccount-preview-company').hide();

                   navigation.goTo('/companyupdate');
            },  
            manageCompanyInformationBack: function(){
                $('#myaccount-manage-company-info').hide();

//                $('#myaccount-preview-company').show();
                navigation.goTo('/myaccount');
                
            },  
            IndividualManageAddress: function(){
                
//                $('#myaccount-manage-info-individual').show();
                
  //              $('#myaccount-preview-individual').hide();
  
                
                window.location.href = '/profile';
                
              //  navigation.goTo('/profile');
                
                
                
                
                
            },
            IndividualManageAddressBack: function(){
                
          //      $('#myaccount-manage-info-individual').hide();
                
  
                  navigation.goTo('/myaccount');
        //          $('#myaccount-preview-individual').show();
                
            },
			validatePrimaryBusiness: function(index,event){
			    	if (event !== undefined) {
					if ('click' === event.type || 'keydown' === event.type || 'keypress' === event.type || 'change' === event.type || 'mouseout' === event.type) {
						if ([null,undefined,''].indexOf(getWidget.primaryBusiness()) === -1) {
						    console.log("Inside validatePrimaryBusiness")
						getWidget.isEmptyPrimaryBusiness(false);    
					    }
					    else{
					       getWidget.isEmptyPrimaryBusiness(true); 
					    }
			    	}
			    	}
			},
						submitSelfRegistrationRequest: function (data, event) {
				var self = data;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
				        event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            var label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";

    				        
     				         if(event.target.id === "CC-userBusinessRegistration-primaryBuiness")
    				        {
    				            $('.boxprimarybusiness').append('<style>.boxprimarybusiness:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    				        }
    				         if(event.target.id === "CC-userBusinessRegistration-annualRevenue")
    				        {
    				            $('.boxbusiness').append('<style>.boxbusiness:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    				        }
    				        
    				         if(event.target.id === "CC-userBusinessRegistration-numberOfEmployees")
    				        {
    				            $('.boxbusiness1').append('<style>.boxbusiness1:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    				        }
    				        
    				        
    				        
    				        
    				        
    				        
				        }
				    }
				    else
				    {
				        event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            var label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";

    				         if(event.target.id === "CC-userBusinessRegistration-primaryBuiness")
    				        {
    				            $('.boxprimarybusiness').append('<style>.boxprimarybusiness:before{border-right:1px solid #d3d3d3;border-top:1px solid #d3d3d3;border-bottom:1px solid #d3d3d3;}</style>');
    				        }
    				         if(event.target.id === "CC-userBusinessRegistration-annualRevenue")
    				        {
    				            $('.boxbusiness').append('<style>.boxbusiness:before{border-right:1px solid #d3d3d3;border-top:1px solid #d3d3d3;border-bottom:1px solid #d3d3d3;}</style>');
    				        }
    				        
    				         if(event.target.id === "CC-userBusinessRegistration-numberOfEmployees")
    				        {
    				            $('.boxbusiness1').append('<style>.boxbusiness1:before{border-right:1px solid #d3d3d3;border-top:1px solid #d3d3d3;border-bottom:1px solid #d3d3d3;}</style>');
    				        }
    				        

				        }
				    }
				    /**if([null,undefined,''].indexOf(self.selfRegistrationRequest().profile.firstName()) !== -1 )
		            {
		                
		                document.getElementById("CC-userRegistration-firstname-label").style = "color:#f33";
                        document.getElementById("CC-userRegistration-firstname").style = "border: 2px solid #f33";
		            }else
		            {
		                document.getElementById("CC-userRegistration-firstname-label").style = "color:black"
                        document.getElementById("CC-userRegistration-firstname").style = "border: 2px solid #d3d3d"
		            }
		            if([null,undefined,''].indexOf(self.selfRegistrationRequest().profile.lastName()) !== -1 )
		            {
		                document.getElementById("CC-userRegistration-lastname-label").style = "color:#f33";
                        document.getElementById("CC-userRegistration-lastname").style = "border: 2px solid #f33";
		            }else
		            {
		                document.getElementById("CC-userRegistration-lastname-label").style = "color:black"
                        document.getElementById("CC-userRegistration-lastname").style = "border: 2px solid #d3d3d"
		            }**/
				}
				if ('click' === event.type || (('keydown' === event.type || 'keypress' === event.type) && event.keyCode === 13)) {
					self.selfRegistrationRequest().organization.secondaryAddresses()[0].address.companyName(self.selfRegistrationRequest().name());
					console.log(self.selfRegistrationRequest().organization.secondaryAddresses()[0].address);
					var address = self.selfRegistrationRequest().organization.secondaryAddresses()[0].address;
					if (!self.userFound()) {
						self.selfRegistrationRequest.createSelfRegistrationRequest(self.createOrganizationRequestSuccess.bind(self), self.createOrganizationRequestFailure.bind(self));
					}
				}
				return true;
			},
			
			
			
            validateName: function() {
                var self = this;
                if ([null, undefined, ''].indexOf(self.name()) === -1) {
                    console.log("if");
                    document.getElementById("name-txt").style = "color:black"
                    document.getElementById("name-input").style = "border: 2px solid #d3d3d"
                } else {
                    console.log("else");
                    document.getElementById("name-txt").style = "color:#f33"
                    document.getElementById("name-input").style = "border: 2px solid #f33"
                }
                return true;
            },
            validateCompanyName: function() {
                var self = this;
                if ([null, undefined, ''].indexOf(self.companyName()) === -1) {
                    console.log("if");
                    document.getElementById("company-txt").style = "color:black"
                    document.getElementById("company-input").style = "border: 2px solid #d3d3d"
                } else {
                    console.log("else");
                    document.getElementById("company-txt").style = "color:#f33"
                    document.getElementById("company-input").style = "border: 2px solid #f33"
                }
                return true;
            },



            submitButton: function(data, event) {
                if ([null, undefined, ''].indexOf(getWidget.name()) !== -1 || [null, undefined, ''].indexOf(getWidget.companyName()) !== -1 || [null, undefined, ''].indexOf(getWidget.address1()) !== -1 || [null, undefined, ''].indexOf(getWidget.address2()) !== -1 || [null, undefined, ''].indexOf(getWidget.zipCode()) !== -1 || [null, undefined, ''].indexOf(getWidget.city()) !== -1 || [null, undefined, ''].indexOf(getWidget.state()) !== -1 || [null, undefined, ''].indexOf(getWidget.emailAddress()) !== -1 ||
                    [null, undefined, ''].indexOf(getWidget.phoneNumber()) !== -1 || [null, undefined, ''].indexOf(getWidget.howCanWeHelpYou()) !== -1) {
                        
                    //$("#phone-input").blur()
                   // $("#email-input").blur()
                    $("#how-can").blur()

                    getWidget.submitButtonError(true);
                    if([null, undefined, ''].indexOf(getWidget.name()) !== -1){
                              $("#name-input").blur()
                           //    document.getElementById("name-txt").style = "color:#f33"
                    }
                       if([null, undefined, ''].indexOf(getWidget.companyName()) !== -1){
                       $("#company-input").blur()
                    }
                       if([null, undefined, ''].indexOf(getWidget.address1()) !== -1){
                        $("#address1-input").blur()
                          document.getElementById("address1-txt1").style = "color:#f33"
                           document.getElementById("address1-txt").style = "color:#f33"
                    }
                     if([null, undefined, ''].indexOf(getWidget.address2()) !== -1){
                        $("#address2-input").blur()
                    }
                       if([null, undefined, ''].indexOf(getWidget.zipCode()) !== -1){
                        $("#zip-input").blur()
                    }
                     if([null, undefined, ''].indexOf(getWidget.city()) !== -1){
                          $("#city-input").blur()
                    }
                    
                     if([null, undefined, ''].indexOf(getWidget.state()) !== -1){
                         $("#state-input").blur()
                          document.getElementById("state-input").style = "border: 2px solid #f33"
                           document.getElementById("state-txt").style = "color:#f33"
                    }
                    
                     if([null, undefined, ''].indexOf(getWidget.emailAddress()) !== -1){
                         document.getElementById("email-txt").style = "color:#f33"
                               document.getElementById("email-input").style = "border: 2px solid #f33"
                         
                    }
                      if([null, undefined, ''].indexOf(getWidget.phoneNumber()) !== -1){
                           document.getElementById("phone-input").style = "border: 2px solid #f33"
                           document.getElementById("phone-txt").style = "color:#f33"
                    }
                    
                    
                } else if (getWidget.isInvalidHomePhoneNumber1() || getWidget.isInvalidEmailAddress1()) {} else {


                    console.log("Please fill the required fields above");


                }
                return false;
            },



 			manageInformationIndividual: function (data,event) {
                  document.getElementById("myaccount-preview").style.display = "none";
                  document.getElementById("myaccount-manage-info").style.display = "block";
                    return true;
			},
 			backToMyAccountIndividual: function (data,event) {
                  document.getElementById("myaccount-manage-info").style.display = "none";
                  document.getElementById("myaccount-preview").style.display = "block";
                    return true;
			},
			
			
			
			
 			manageInformationBusiness: function (data,event) {
                  document.getElementById("myaccount-preview").style.display = "none";
                  document.getElementById("myaccount-manage-info").style.display = "block";
                    return true;
			},
 			backToMyAccountBusiness: function (data,event) {
                  document.getElementById("myaccount-manage-info").style.display = "none";
                  document.getElementById("myaccount-preview").style.display = "block";
                    return true;
			},
			
			
			
 			manageInformationCompany: function (data,event) {
                  document.getElementById("myaccount-preview").style.display = "none";
                  document.getElementById("myaccount-manage-info").style.display = "block";
                    return true;
			},
 			backToMyAccountCompany: function (data,event) {
                  document.getElementById("myaccount-manage-info").style.display = "none";
                  document.getElementById("myaccount-preview").style.display = "block";
                    return true;
			},
			
			redirectToRegistration: function(){
                navigation.goTo('/registration');
            },
            
            redirectToLogin: function(){
                return true;
            },
			
			




 			manageInformation: function (data,event) {
                  document.getElementById("myaccount-preview").style.display = "none";
                  document.getElementById("myaccount-manage-info").style.display = "block";
                    return true;
			},
 			backToMyAccount: function (data,event) {
                  document.getElementById("myaccount-manage-info").style.display = "none";
                  document.getElementById("myaccount-preview").style.display = "block";
                    return true;
			},
			
			
			
			updateInformation: function (data,event) {
                       if([null, undefined, ''].indexOf(getWidget.primaryBusiness()) !== -1){

       					$('.boxprimarybusiness').append('<style>.boxprimarybusiness:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    					document.getElementById("CC-userBusinessRegistration-primaryBusiness-label").style = "color:#f33"
                        document.getElementById("CC-userBusinessRegistration-primaryBusiness").style = "border: 2px solid #f33"

                        }


                       if([null, undefined, ''].indexOf(getWidget.noOfEmployees()) !== -1){

       					$('.boxbusiness1').append('<style>.boxbusiness1:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    					document.getElementById("CC-userBusinessRegistration-numberOfEmployees-label").style = "color:#f33"
                        document.getElementById("CC-userBusinessRegistration-numberOfEmployees").style = "border: 2px solid #f33"

                    }
                    
                    
                       if([null, undefined, ''].indexOf(getWidget.annualRevenue()) !== -1){
       					$('.boxbusiness').append('<style>.boxbusiness:before{border-right:2px solid rgb(255, 51, 51);border-top:2px solid rgb(255, 51, 51);border-bottom:2px solid rgb(255, 51, 51);}</style>');
    					document.getElementById("CC-userBusinessRegistration-annualRevenue-label").style = "color:#f33"
                        document.getElementById("CC-userBusinessRegistration-annualRevenue").style = "border: 2px solid #f33"
                    }
                    return true;
			},
    };
  }
);

