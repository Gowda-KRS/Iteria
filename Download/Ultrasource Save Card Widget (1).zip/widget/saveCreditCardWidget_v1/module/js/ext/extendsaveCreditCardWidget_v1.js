paytrace = (function() {
  var pub = null;
  var module = null; // to make hoisting explicit

  module = {
    cloneForm: function(form_element) {
      var $original = $(form_element);
      var $cloned = $original.clone();
      $original.parent().append($cloned.hide());
      
      //get original selects into a jq object
      var $originalSelects = $original.find('select');
      $cloned.find('select').each(function(index, item) {
        //set new select to value of old select
        $(item).val($originalSelects.eq(index).val());       
      });

      //get original textareas into a jq object
      var $originalTextareas = $original.find('textarea');
       
      $cloned.find('textarea').each(function(index, item) {
        //set new textareas to value of old textareas
        $(item).val($originalTextareas.eq(index).val());
      });

      return $cloned;
    },

    setKey: function(public_key_pem) {
        var data = {"code": public_key_pem};
        	var requestPayload = {
						"url": "/ccstorex/custom/v1/payTraceForgeKey",
						"method": "POST",
						"data": JSON.stringify(data),
						"async": false,
						"contentType": "application/json"
					};
					
					$.ajax(requestPayload).done(function (response) {
					
					console.log("Response :: ", response);
					if (response) {
					    pub = response; 
					}
				});
      
      return this;
    },

    setKeyAjax: function(key_url) {
      $.ajax({
        url: key_url,
        dataType: 'text'
      })
      .done(function(public_key_pem) {
        module.setKey(public_key_pem);
      })
      .fail(function(jqXHR, textStatus) {
        throw("AJAX Key request failed: " + textStatus);
      });
    },

    encryptValue: function (data) {
      var result;
      
      var data1 = {"code": data};

      if (!pub) {throw "No public key was provided (PayTrace E2EE).";}
      console.log(pub)
      var encryptedResponse; 
      var requestPayload = {
						"url": "/ccstorex/custom/v1/encryptedValue",
						"method": "POST",
						"data": JSON.stringify(data1),
						"async": false,
						"contentType": "application/json"
					};
					
					$.ajax(requestPayload).done(function (response) {
					
					console.log("Response :: ", response);
					if (response) {
					   encryptedResponse = response; 
					}
				});
				console.log(encryptedResponse)
      
      return encryptedResponse;
    },
    
    submitEncrypted: function (form) {

      // we clone the form for two reasons: first, it allows us to submit a "shadow" form, so that if there's
      // some kind of error and we have to press the "back" button, the original values don't show up as
      // encrypted. Second, by triggering submit() on the "shadow" form and canceling the submit on the "real"
      // form, we make it much more difficult to accidentally submit unencrypted data.
      var $cloned = module.cloneForm(form);
        
        
    var encryptedArray = [];
      $cloned.find('input[type="text"],input[type="password"]').filter('.pt-encrypt').each(function(idx, el) {
          console.log(el.value, "before encrypting")
        el.value1 = module.encryptValue(el.value);
        console.log(el.value, 'encrypted');
        encryptedArray.push({
            number: el.value, 
            encrypted:  el.value1
        });
      });
      console.log(encryptedArray);
    return encryptedArray;
    //   $cloned.submit(); 
    
    // $.Topic("ENCRYPTED_VALUE.memory").publish({encryptedArray}) ;
    },

    hookFormSubmit: function (form) {
      $(form).submit(function (e) { 
        // we submit via javascript, so always cancel the default HTML DOM form handler event
        e.preventDefault();

        module.submitEncrypted(this)
        
        // we should never get here, as submit() should trigger a navigation, but just in case...
        return false;
      });
    }
  };
  
  return module;
})();