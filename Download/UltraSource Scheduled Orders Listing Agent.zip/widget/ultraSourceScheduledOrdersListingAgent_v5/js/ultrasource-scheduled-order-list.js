/**
 * @fileoverview Scheduled Order List Widget.
 *
 */
/*global $ */
/*global define */
define(
  //-------------------------------------------------------------------
  // DEPENDENCIES
  //-------------------------------------------------------------------
  ['knockout', 'pubsub', 'ccLogger', 'notifier', 'ccConstants', 'jquery', 'ccRestClient', 'navigation','spinner', 
      'viewModels/scheduledOrderList'],

  //-------------------------------------------------------------------
  // MODULE DEFINITION
  //-------------------------------------------------------------------
  function (ko, pubsub, log, notifier, CCConstants, $, CCRestClient, navigation,spinner, 
          ScheduledOrderList) {

    "use strict";

    return {
      errorMsg: ko.observable(),
      WIDGET_ID: "ultraSourceScheduleOrderList",
      sortDirections: ko.observable({"createDate":"both","name":"both"}),
      selectedOrderId: ko.observable(),
      contextManager: null,
      subscriptions: [],
      isAgentApplication : window.isAgentApplication,
      listingIndicatorOptions: {
        parent: '#CC-scheduledOrderList',
        posTop: '10%',
        posLeft: '50%'
      },
      homeRoute: "",
      
      onLoad: function (widget) {
        var self = this;
        widget.listingViewModel = ko.observable();
        widget.listingViewModel(new ScheduledOrderList());
        widget.homeRoute = widget.links().home.route;
        if (widget.isAgentApplication) {
          widget.homeRoute = widget.links().agentHome.route;
          widget.contextManager = require("agentViewModels/agent-context-manager").getInstance();
        }
        $.Topic(pubsub.topicNames.PAGE_CHANGED).subscribe(widget.triggerPageChangeEvent.bind(widget));
        // To append locale for scheduled orders link
        widget.detailsLinkWithLocale = ko.computed(function() {
          return navigation.getPathWithLocale('/scheduledOrders/'); 
        }, widget);
        //Create scheduledOrderListGrid computed for the widget
        widget.scheduledOrderListGrid = ko.computed(function() {
          var numElements, start, end, width;
          var rows = [];
          var orders;
          if (($(window)[0].innerWidth || $(window).width()) > CCConstants.VIEWPORT_TABLET_UPPER_WIDTH) {
            var startPosition, endPosition;
            // Get the orders in the current page
            startPosition = (widget.listingViewModel().currentPage() - 1) * widget.listingViewModel().itemsPerPage;
            endPosition = startPosition + widget.listingViewModel().itemsPerPage;
            orders = widget.listingViewModel().data.slice(startPosition, endPosition);
          } else {
            orders = widget.listingViewModel().data();
          }
          if (!orders) {
            return;
          }
          numElements = orders.length;
          width = parseInt(widget.listingViewModel().itemsPerRow(), 10);
          start = 0;
          end = start + width;
          while (end <= numElements) {
            rows.push(orders.slice(start, end));
            start = end;
            end += width;
          }
          if (end > numElements && start < numElements) {
            rows.push(orders.slice(start, numElements));
          }
          return rows;
        }, widget);

        $.Topic(pubsub.topicNames.SCHEDULE_ORDERS_LIST_FAILED).subscribe(function(data) {
          if (this.status == CCConstants.HTTP_UNAUTHORIZED_ERROR) {
            widget.user().handleSessionExpired();
            if (navigation.isPathEqualTo(widget.links().profile.route)) {
              navigation.doLogin(navigation.getPath(), widget.homeRoute);  
            }
          } else {
            notifier.clearError(widget.WIDGET_ID);
            notifier.clearSuccess(widget.WIDGET_ID);
            notifier.sendError(widget.WIDGET_ID, data? data.message :"", true);
            navigation.goTo('/profile');
          }
        });
      },

      clickToSort: function(sortOrder,sortTerm){
        var widget=this;
       widget.sortDirections()[sortTerm]=sortOrder;

       if(sortTerm=="createDate"){
         widget.sortDirections()["name"]="both";
       }else if(sortTerm=="name"){
         widget.sortDirections()["createDate"]="both";
       }
        var sortString=sortTerm+":"+sortOrder;
        widget.listingViewModel().sortProperty=sortString;
        widget.sortDirections.valueHasMutated();
        widget.listingViewModel().refinedFetch();

      },
      getFilteredByOrganization: function(){
        var widget = this;
        widget.populateOrganization();
        widget.listingViewModel().refinedFetch();
      },
      populateOrganization : function () {
        var widget = this;
        if (widget.listingViewModel() && widget.contextManager) {
          widget.listingViewModel().organizationFilter = widget.contextManager.getCurrentOrganizationId();
        }
      },
      clickOrderDetails: function (data, event) {
        var widget = this;
        var link = null;
        if(widget.contextManager && widget.isAgentApplication) {
          link = (widget.links().AgentOrderDetails.route);
          widget.contextManager.setProperty("isScheduledOrder", true);
          widget.user().validateAndRedirectPage(link + "/" + data.id +'?isScheduledOrder=true');
        } else {
          link = this.detailsLinkWithLocale();
          widget.user().validateAndRedirectPage(link + data.id);
        }
        return false;
      },
      beforeAppear: function (page) {
        var widget = this;
        if (widget.user().loggedIn() == false) {
          navigation.doLogin(navigation.getPath(), widget.homeRoute);
        } else {
          widget.listingViewModel().clearOnLoad = true;
          if (widget.contextManager) {
            widget.subscriptions.push(widget.contextManager.currentOrganizationId.subscribe(widget.getFilteredByOrganization.bind(widget)));
            widget.subscriptions.push(widget.contextManager.selectedSite.subscribe(widget.getFilteredByOrganization.bind(widget)));

            widget.populateOrganization();
          }
          widget.listingViewModel().load(1, 1);
        }
      },

      mergeToCart: function (data, event) {
        var widget = this;
        if(data.templateOrderId){
          widget.selectedOrderId(data.templateOrderId);
        }
        widget.cart().mergeCart(true);
        CCRestClient.request(CCConstants.ENDPOINT_GET_ORDER, null,
                function(order) {
          var state = order.state;
          var success = function(){
            widget.user().validateAndRedirectPage(widget.links().cart.route);
          };
          var error = function(errorBlock){
            var errMessages = "";
            var displayName;
            for(var k=0;k<errorBlock.length;k++){
              errMessages = errMessages + "\r\n" + errorBlock[k].errorMessage;
            }
            notifier.sendError("CartViewModel", errMessages, true);
          };
          widget.cart().addItemsToCart(order.order.items, success, error);
          widget.selectedOrderId(null);
        },
        function(data) {
          // If not go 404
          navigation.goTo(widget.contextData.global.links['404'].route);
          widget.cart().mergeCart(false);
          widget.selectedOrderId(null);
        },
        widget.selectedOrderId());
      },

      setSelectedOrderId: function (data, event) {
        this.selectedOrderId(data.templateOrderId);
      },
      triggerPageChangeEvent: function () {
        var widget = this;
        var length = widget.subscriptions.length;
        for (var i =0; i<length; i++){
          widget.subscriptions[i].dispose();
        }
        widget.subscriptions = [];
      }
    };
  });
