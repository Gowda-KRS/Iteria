/**
 * @fileoverview Shopping Cart Summary Widget.
 * 
 */
define(
  //-------------------------------------------------------------------
  // DEPENDENCIES
  //-------------------------------------------------------------------
  ['knockout', 'pubsub','navigation', 'viewModels/giftProductListingViewModel', 'ccConstants', 'notifier',
      'CCi18n', 'jquery', 'viewModels/integrationViewModel', 'viewModels/inventoryViewModel','//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js'],
    
  //-------------------------------------------------------------------
  // MODULE DEFINITION
  //-------------------------------------------------------------------
  function (ko, pubsub, navigation, giftProductListingViewModel, CCConstants, notifier, CCi18n, $, integrationViewModel, Inventory) {
  
    "use strict";
    var getWidget;

    return {

      // This will hold the data displayed in gift selection modal      
      firstName: ko.observable(),
      LasttName: ko.observable(),
       lastName: ko.observable(),
      state: ko.observable(),
      jobTitle:ko.observable(),
      companyName: ko.observable(),
      orderAccountRelated:ko.observable(),
      equipmentPartsService: ko.observable(),
      pleaseIncludeYourComments: ko.observable(),
      preferredContactMethod: ko.observable(),
      revenueArray: ko.observableArray([]),
      primaryBusinessArray: ko.observableArray([]),
      supplyRelatedArray: ko.observableArray([]),
      equipmentAndSupplyRelated: ko.observableArray([]),
      annual_revenue: ko.observable(),
      supplyrelated: ko.observable(),
      primary_business: ko.observable(),
      emailAddress: ko.observable(),
      phoneNumber: ko.observable(),
      submitButtonError:ko.observable(false),
      isEmptyfirstName: ko.observable(false),
            emptyfirstNameErrorMessage: ko.observable("Please enter First name"),
             isEmptystate: ko.observable(false),
            emptystateErrorMessage: ko.observable("Please enter state"),
            isEmptylastName: ko.observable(false),
            emptylastNameErrorMessage: ko.observable("Please enter Last name"),
           
            isInvalidMobilePhoneNumber: ko.observable(false),
            invalidMobilePhoneNumber: ko.observable("Please enter phone number"),
            isEmptyMobilePhoneNumber: ko.observable(false),
            validMobilePhoneNumber: ko.observable("please enter valid phone number"),
             isInvalidEmailAddress1: ko.observable(false),
            invalidEmailAddress2: ko.observable("Please enter valid email address"),
            invalidEmailAddress3: ko.observable("Please enter email address"),
            suppliesRelated:  ko.observableArray(["All Supplies","Clothing","Cutlery","Janitorial & Sanitation","Material Handling","Measuring","Mineral Oil","Packaging","Processing","Safety","Seasoning","Sinks & Wash Stations","Tables & Prep Stations"]),
            selectedSupplies: ko.observable(),
            serviceRelated: ko.observableArray(["All Supplies","Clothing","Cutlery","Janitorial & Sanitation","Material Handling","Measuring","Mineral Oil","Packaging","Processing","Safety","Seasoning","Sinks & Wash Stations","Tables & Prep Stations"]),
            serviceRelatedSelected : ko.observable(),


      onLoad: function(widget) {
        var self = this;
getWidget=widget;
self.primaryBusinessArray.push('Meat & Meat Products', 'Poultry & Poultry Products', 'Fish & Fish Products', 'Dairy & Dairy Products', 'Farms - General/Crop', 'Fruits & Vegetables', 'Bread & Bakery', 'Snacks - Candy/Nut/Other', 'Restaurants & Country Clubs', 'Grocery Store', 'Pet Food', 'Schools - Elementary/Secondary/College', 'Medical - Offices/Hospitals/Manufacturers', 'Correctional Institutions', 'Other');
self.revenueArray.push('$0-$500k', '$500k-$1M', '$1M-$2.5M', '$2.5M-$5M', '$5M-$10M', '$10M-$25M', '$25M-$50M', '$50M+');
self.supplyRelatedArray.push('Clothing','Cutlery','Janitorial & Sanitation','Material Handling','Measuring','Mineral Oil','Packaging','Processing','Safety','Seasoning','Sinks & Wash Stations','Tables & Prep Stations');
self.equipmentAndSupplyRelated.push('Kill Floor','Processing','Vacuum Packaging','Tray Sealing','Rollstock Packaging','Labeling','Labeler Parts','Vacuum packaging parts','Rollstock Packaging Parts','Tray Sealing Parts','Processing Parts','Kill Floor Parts');
      },  //end of onload

validateEmail: function(event) {
    var label;

                if (event.target.value === "" || event.target.value === null) {

                    document.getElementById(event.target.id+"-label").style = "color:#f33"
                    document.getElementById(event.target.id).style = "border: 2px solid #f33"

                } else {

                    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;


                    if (re.test(getWidget.emailAddress())) {

                        document.getElementById(event.target.id+"-label").style = "color:black"
                        document.getElementById(event.target.id+"-error").style = "display:none"
                        document.getElementById(event.target.id).style = "border: 2px solid #d3d3d"
                        

                    } else {
                       
                        document.getElementById(event.target.id+"-label").style = "color:#f33"
                        document.getElementById(event.target.id+"-error").style = "display:block"
                        document.getElementById(event.target.id).style = "border: 2px solid #f33"

                    }
                }
            },


validateMobilePhoneNumber: function(event) {

var label=event.target.id;
                if (event.target.value === "" || event.target.value === null) {
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                } else {
                
                    var number = ("" + event.target.value).replace(/\D/g, '');
                    var token = number.match(/^(\d{3})(\d{3})(\d{4})$/);

                    if (token !== null) {
                   
                        document.getElementById(label+"-label").style = "color:black"
                         document.getElementById(label+"-error").style = "display:none"
                        document.getElementById(label).style = "border: 2px solid #d3d3d"
                    } else {
                                document.getElementById(label+"-label").style = "color:#f33"
                                 document.getElementById(label+"-error").style = "display:block"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    }
                }
            },




validatePhoneNumber: function() {
                var self = this;
                if ([null, undefined, ''].indexOf(self.phoneNumber()) === -1) {
                    console.log("if");
                    document.getElementById(label).style = "color:black"
                    document.getElementById(label).style = "border: 2px solid #d3d3d"
                } else {
                    console.log("else");
                    document.getElementById(label).style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                }
                return true;
            },

 validatefirstName: function(event) {
     				  var label;
				if ('click' === event.type || 'blur' === event.type  || event.keyCode === 9) {
				    if(event.target.value === "")
				    {
	
						event.target.style = "border: 2px solid #f33";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:#f33";
    				         document.getElementById(event.target.id+"-error").style = "color:#f33";
				        }

				    }else{
				        
						event.target.style = "border: 2px solid #d3d3d";
				        if(event.target.id !== null){
				            label = event.target.id + "-label"; 
    				        document.getElementById(label).style = "color:black";				  
    				        document.getElementById(event.target.id+"-error").style = "color:black";				  
				        }

				    }
				}
     
                return true;
            },
            
             validatelastName: function() {
                var self = this;
                if ([null, undefined, ''].indexOf(self.lastName()) === -1) {
                    console.log("if");
                    document.getElementById(label).style = "color:black"
                    document.getElementById(label).style = "border: 2px solid #d3d3d"
                } else {
                    console.log("else");
                    document.getElementById(label).style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                }
                return true;
            },

 validatestate: function(event) {
                var self = this;
                if ([null, undefined, ''].indexOf(self.state()) === -1) {
                    console.log("if");
                    document.getElementById(event.target.id+"-label").style = "color:black"
                    document.getElementById(event.target.id).style = "border: 2px solid #d3d3d"
                } else {
                    console.log("else");
                    document.getElementById(event.target.id+"-label").style = "color:#f33"
                    document.getElementById(event.target.id).style = "border: 2px solid #f33"
                }
                return true;
            },
            
            
            
            	emailAddressFocused: function (data) {
				// $('#CC-userRegistration-emailAddress-error1').hide(); 
				getWidget.isInvalidEmailAddress(false);
				if (getWidget.ignoreBlur && getWidget.ignoreBlur()) {
					return true;
				}
				getWidget.user().ignoreEmailValidation(true);
				return true;
			},
submit: function(){
    var label;
    var flag=false;
          if ([null, undefined, ''].indexOf(getWidget.state()) !== -1) {
              label="CC-Contact-Form-state";
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    flag=true;
            }
          if ([null, undefined, ''].indexOf(getWidget.firstName()) !== -1) {
              label="CC-Contact-Form-firstname";
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    flag=true;
            }
                     if ([null, undefined, ''].indexOf(getWidget.lastName()) !== -1) {
                         label="CC-Contact-Form-lastname";
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    flag=true;
            }
                     if ([null, undefined, ''].indexOf(getWidget.emailAddress()) !== -1) {
                         label="CC-Contact-Form-emailaddress";
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    flag=true;
            }
        if ([null, undefined, ''].indexOf(getWidget.phoneNumber()) !== -1) {
            label="CC-Contact-Form-phonenumber";
                    document.getElementById(label+"-label").style = "color:#f33"
                    document.getElementById(label).style = "border: 2px solid #f33"
                    flag=true;
                }
                
            if(flag){
               getWidget.submitButtonError(true);
            }else{
                getWidget.submitButtonError(false);
                
                var payLoadData = {
  							    "type":"contact_form",
  							    
  							    "firstName" : getWidget.firstName(),
  							    "lastName" : getWidget.lastName(),
  							    "emailAddress" : getWidget.emailAddress(),
  							    "phoneNumber": getWidget.phoneNumber(),
  							    "email":getWidget.emailAddress(),
  							    "jobTitle":getWidget.jobTitle(),
  							    "state":getWidget.state(),
  							    "preferredContactMethod": getWidget.preferredContactMethod(),
  							    "companyName": getWidget.companyName(),
  							    "annual_revenue":getWidget.annual_revenue(),
  							    "primary_business":getWidget.primary_business(),
  							    "orderAccountRelated":getWidget.orderAccountRelated(),
  							    "supplyrelated":getWidget.supplyrelated(),
  							    "equipmentPartsService":getWidget.equipmentPartsService(),
  							    "pleaseIncludeYourComments":getWidget.pleaseIncludeYourComments(),
  							    "selectedSupplies" : getWidget.selectedSupplies(),
  							    "serviceRelatedSelected" : getWidget.serviceRelatedSelected()
							};
							
							console.log(payLoadData);

							$.ajax( {
							    //http://localhost:3000
								url: '/ccstorex/custom/v1/file/sendEmail',
								headers: {
									'Content-Type': "application/json"
								},
								method: 'POST',
								processData: false,
								contentType: false,
								data: JSON.stringify( payLoadData )
							} ).done( function ( response ) {
                            	console.log(response);
                            	$('#Contact-Form').hide();
                            	$('#CC-email').show();
	
	
							} ).fail( function ( error ) {
								notifier.sendError( getWidget.WIDGET_ID, "Unable to send email. Please try after some time", false );
							} );

                
                
                
            }
            
            
            
            
            
},
		
		redirectTosebdusmessage: function(){
                 //   navigation.goTo('/contactform');
                    window.location.href = '/contactform';
		},
		
		redirectTohome: function(){
                    navigation.goTo('/home');
            },


	redirectTocontactUs: function(){
                    navigation.goTo('/contactUs');
            },            


    };
  }
);
